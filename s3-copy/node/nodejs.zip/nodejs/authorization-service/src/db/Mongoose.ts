import * as mongoose from 'mongoose';
import { Utils } from '../utils/Utils';

(<any>mongoose).Promise = global.Promise;

if (process.env.MONGOOSE_DEBUG) {
  mongoose.set('debug', true);
}

let mongoDbUri: string = process.env.AUTHZ_SERVICE_MONGODB_URI;
Utils.validateIsNotNullOrUndefined(mongoDbUri, "Env var AUTHZ_SERVICE_MONGODB_URI");

mongoose.connect(mongoDbUri, {
  useNewUrlParser: true
});

export { mongoose };
