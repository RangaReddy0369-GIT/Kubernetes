export enum PrincipalType {
  USER = "USER",
  USER_GROUP = "USER_GROUP"
}