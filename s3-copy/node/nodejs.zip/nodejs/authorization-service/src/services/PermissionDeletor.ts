import { PermissionService } from "./Permission";
import { PermissionModel } from "../models/Permission";
import { provideSingleton } from "../ioc/ioc";
import { BaseService } from "./Base";

@provideSingleton(PermissionDeletorService)
export class PermissionDeletorService extends BaseService {
  
  public async handlePrincipalDeletion(id: string) {
    await PermissionModel.deleteMany({
      principalId: id
    }).session(this.getSession()).exec();
  }

  public async handleRoleActionDeletion(id: string) {
    await PermissionModel.deleteMany({
      actionRoleId: id
    }).session(this.getSession()).exec();
  }

  protected getParentModel() {
    throw new Error("Method not implemented.");
  }

  protected getParentEntityName(): string {
    throw new Error("Method not implemented.");
  }

  protected getModel() {
    throw new Error("Method not implemented.");
  }

  protected getEntityName(): string {
    throw new Error("Method not implemented.");
  }

  protected getChildModel() {
    throw new Error("Method not implemented.");
  }
  
  protected getChildEntityName(): string {
    throw new Error("Method not implemented.");
  }

}
