import { BaseService } from "./Base";
import { IPermissionModel, PermissionModel } from "../models/Permission";
import { inject } from "inversify";
import { ActionService } from "./Action";
import { RoleService } from "./Role";
import { ErrUtils, ValidationUtils, ProviderFactory, MageHttpClient, Service } from "@edunxtv2/service-util";
import { provideSingleton } from "../ioc/ioc";
import * as _ from 'lodash';
import { RoleActionRelationService } from "./RoleActionRelationship";
import * as matcher from 'matcher';
import { PermissionsQuery, PermissionTicket, PermissionIntermediate, TicketPermission } from "../interfaces/Permission";
import * as jwt from 'jsonwebtoken';

@provideSingleton(PermissionService)
export class PermissionService extends BaseService {

  private privateKey: string;

  private publicKey: string;

  private permissionsExpiryDuration = 1800000;

  constructor(
    @inject(ActionService) private actionService: ActionService,
    @inject(RoleService) private roleService: RoleService,
    @inject(RoleActionRelationService) private roleActionRelationService: RoleActionRelationService
  ) {
    super();
    this.privateKey = ProviderFactory.getSecretsProvider().getSecret(
      "PERMISSIONS_TICKET_PRIVATE_KEY");
    this.publicKey = ProviderFactory.getAttribsProvider().getConfigVar(
      "PERMISSIONS_TICKET_PUBLIC_KEY");

    ValidationUtils.validateStringNotEmpty(this.privateKey, "process.env.PERMISSIONS_TICKET_PRIVATE_KEY");
    ValidationUtils.validateStringNotEmpty(this.publicKey, "process.env.PERMISSIONS_TICKET_PUBLIC_KEY");

    const permissionsExpiryFromEnv = ProviderFactory.getAttribsProvider().
      getConfigVar("PERMISSIONS_TICKET_EXPIRY_DURATION");

    if (permissionsExpiryFromEnv) {
      const expiryInMs: number = parseInt(permissionsExpiryFromEnv);

      if (!isNaN(expiryInMs) && expiryInMs > 60000) {
        this.permissionsExpiryDuration = expiryInMs;
      } else {
        ErrUtils.throwSystemError(`Invalid value ${permissionsExpiryFromEnv} for PERMISSIONS_TICKET_EXPIRY_DURATION`,
          "INVALID_PERMISSIONS_EXPIRY");
      }
    }
  }

  protected getModel() {
    return PermissionModel;
  }

  protected getEntityName(): string {
    return BaseService.ENTITY_PERMISSION
  };

  protected getParentModel() { throw new Error("Method not implemented."); }

  protected getParentEntityName(): string { throw new Error("Method not implemented."); }

  protected getChildModel() { throw new Error("Method not implemented."); }

  protected getChildEntityName(): string { throw new Error("Method not implemented."); }

  public async create(instanceId: string, organizationId: string, principalId: string,
    isUser: boolean, actionRoleId: string, isRole: boolean,
    scopes: string[]): Promise<IPermissionModel> {
    await this.validate(instanceId, organizationId,
      principalId, isUser, actionRoleId, isRole, scopes);

    return await this.createEntity({
      instanceId: instanceId,
      organizationId: organizationId,
      principalId: principalId,
      isUser: isUser,
      actionRoleId: actionRoleId,
      isRole: isRole,
      scopes: scopes
    }, "NA") as IPermissionModel;
  }

  public createPermissionsTicket(permissions: TicketPermission[]) {
    const ticket: PermissionTicket = {
      permissions: permissions,
      expiry: new Date().getTime() + this.permissionsExpiryDuration
    };

    return jwt.sign(ticket, this.privateKey, { algorithm: 'RS256' });
  }

  public async convertToPermissionsForTicket(permissions: PermissionIntermediate[]): Promise<TicketPermission[]> {
    const actionIds: string[] = _.uniq(_.flatten(_.map(permissions, "actionIds")));
    const actionNameToIdmappings: { [s: string]: string } = await this.actionService.fetchActionNamesForIds(actionIds);

    return permissions.map((permissionIn: PermissionIntermediate) => {
      return {
        actionNames: permissionIn.actionIds.map((actionId: string) => {
          return actionNameToIdmappings[actionId];
        }),
        scopes: permissionIn.scopes
      }
    });
  }

  public updateQueryWithResult(permissionQueries: PermissionsQuery[],
    permissions: PermissionIntermediate[], allowAll: boolean) {
    for (let query of permissionQueries) {
      query.allowed = allowAll ? true : this.isAllowed(permissions, query.actionId, query.scope);
    }
  }

  public isAllowed(permissions: PermissionIntermediate[], actionId: string, scope: string) {
    for (let permission of permissions) {
      if (permission.actionIds.indexOf(actionId) !== -1) {
        for (let allowedScope of permission.scopes) {
          if (matcher.isMatch(scope, allowedScope)) {
            return true;
          }
        }
      }
    }

    return false;
  }

  public async determineAllPermissionsForUser(id: string, instanceId: string,
    organizationId: string): Promise<PermissionIntermediate[]> {
    const allPrincipals: string[] = await this.findAllPrincipalsForUser(id);
    const permissions: IPermissionModel[] = await PermissionModel.find({
      principalId: { $in: allPrincipals },
      instanceId: instanceId,
      organizationId: organizationId
    }).session(this.getSession()).exec();

    const roleIds = _.map(_.filter(permissions, { isRole: true }), "actionRoleId");
    const allRoleIds: string[] = [...roleIds];
    const roleToChildRolesMapping: { [s: string]: string[] } =
      await this.roleService.findAllChildren(roleIds);
    allRoleIds.push(..._.uniq(_.flatten(Object.values(roleToChildRolesMapping))));
    const actionIds = _.map(_.filter(permissions, { isRole: false }), "actionRoleId");

    const [roleToActionMapping, actionToChildActionMapping]: { [s: string]: string[] }[] =
      await Promise.all([
        this.roleActionRelationService.findAllChildren(allRoleIds),
        this.actionService.findAllChildren(actionIds)
      ]);

    const allRoleToActionMapping =
      this.replaceChildRolesWithActions(roleToChildRolesMapping, roleToActionMapping);
    const permissionsInt: PermissionIntermediate[] = this.replaceRolesAndActionsWithChildren(
      permissions, allRoleToActionMapping, actionToChildActionMapping);
    
    return this.condensePermissions(permissionsInt);
  }

  private condensePermissions(permissionsIn: PermissionIntermediate[]) {
    const permissions = permissionsIn.map((permissionIn: PermissionIntermediate) => {
      const actionIds: string[] = _.sortBy(_.uniq(permissionIn.actionIds));

      return {
        actionIds: actionIds,
        scopes: _.uniq(permissionIn.scopes),
        actionIdHash: actionIds.join(",")
      }
    });

    return Object.values(_.groupBy(permissions, "actionIdHash")).map((groupedPermissions: any) => {
      return {
        actionIds: groupedPermissions[0].actionIds,
        scopes: _.uniq(_.flatten(_.map(groupedPermissions, "scopes")))
      };
    });
  }

  private replaceRolesAndActionsWithChildren(rawPermissions: IPermissionModel[],
    roleToActionMapping: { [s: string]: string[] },
    actionToChildActionMapping: { [s: string]: string[] }): PermissionIntermediate[] {
    const permissions: PermissionIntermediate[] = [];

    for (let rawPermission of rawPermissions) {
      const permission: any = { scopes: rawPermission.scopes };

      if (rawPermission.isRole) {
        permission.actionIds = roleToActionMapping[rawPermission.actionRoleId];

        if(permission.actionIds.length === 0) {
          continue;
        }
      } else {
        permission.actionIds = actionToChildActionMapping[rawPermission.actionRoleId];
        permission.actionIds.push(rawPermission.actionRoleId);
      }

      permissions.push(permission);
    }

    return permissions;
  }

  private replaceChildRolesWithActions(roleToChildRoleMapping: { [s: string]: string[] },
    roleToActionsMapping: { [s: string]: string[] }) {
    const result: { [s: string]: string[] } = {};

    for (let key in roleToChildRoleMapping) {
      let childRoles: string[] = roleToChildRoleMapping[key];
      childRoles.push(key);
      childRoles = _.uniq(roleToChildRoleMapping[key]);

      const actions: string[] = [];

      for (let childRole of childRoles) {
        actions.push(...roleToActionsMapping[childRole]);
      }

      result[key] = _.uniq(actions);
    }

    return result;
  }

  public async removeScopes(id: string, scopes: string[]) {
    return await this.getModel().updateOne({
      id: id
    }, {
      "$pullAll": {
        scopes: scopes
      }
    }).session(this.getSession()).exec();
  }

  public async addScopes(id: string, scopes: string[]) {
    this.validateEntitiesExist([id], this.getEntityName());

    return await this.getModel().updateOne({
      id: id
    }, {
      "$addToSet": {
        scopes: scopes
      }
    }).session(this.getSession()).exec();
  }

  public async delete(id: string) {
    return await PermissionModel.deleteOne({
      id: id
    }).session(this.getSession()).exec();
  }

  public async deleteForPrincipal(id: string, isUser: boolean) {
    return await PermissionModel.deleteMany({
      principalId: id,
      isUser: isUser
    }).session(this.getSession()).exec();
  }

  private async findAllPrincipalsForUser(userId: string): Promise<string[]> {
    const userGroupIds: string[] = await this.findAllUserGroupIdsForUser(userId);
    const principalIds: string[] = [...userGroupIds];
    principalIds.push(userId);

    return principalIds;
  }

  private async findAllUserGroupIdsForUser(userId: string): Promise<string[]> {
    return await MageHttpClient.call(
      Service.USERGROUP_SERVICE, `/usergroups/user/${userId}?extended=true`, {});
  }

  private async findUserGroup(id: string) {
    return await MageHttpClient.call(Service.USERGROUP_SERVICE, `/usergroups/${id}`, {});
  }

  private async findUser(id: string) {
    return await MageHttpClient.call(Service.USER_SERVICE, `/users/${id}`, {});
  }

  public async validate(instanceId: string, organizationId: string,
    principalId: string, isUser: boolean, actionRoleId: string,
    isRole: boolean, scopes: string[]) {
    const principalPromise: Promise<any> = isUser ? this.findUser(principalId) :
      this.findUserGroup(principalId);
    const roleActionPromise: Promise<any> = isRole ? this.roleService.findById(actionRoleId) :
      this.actionService.findById(actionRoleId);

    const [principal, roleAction] = await Promise.all([principalPromise, roleActionPromise]);
    const principalName: string = isUser ? BaseService.ENTITY_USER : BaseService.ENTITY_USER_GROUP;

    if (!principal) {
      ErrUtils.throwValidationError(`Entity ${principalName} having id ${principalId} does not exist`,
        "PRINCIPAL_DOESNT_EXIST");
    }

    if (!roleAction) {
      const entityName: string = isRole ? BaseService.ENTITY_ROLE : BaseService.ENTITY_ACTION;
      ErrUtils.throwValidationError(`Entity ${entityName} having id ${actionRoleId} does not exist`,
        "ACTION_ROLE_DOESNT_EXIST");
    }

    if (isRole && !isUser) {
      this.validatePrincipalRoleMatch(roleAction, principal, principalName);
    }

    this.validateScopes(scopes);
  }

  private validateScopes(scopes: string[]) {
    ValidationUtils.validateIsNotNullOrUndefined(scopes, "scopes");

    if (scopes.length === 0) {
      ErrUtils.throwValidationError(`scopes cannot be empty`, "EMPTY_SCOPES");
    }

    for (let scope of scopes) {
      if (!scope || scope.trim().length === 0) {
        ErrUtils.throwValidationError(`scope cannot be blank`, "BLANK_SCOPE");
      }
    }
  }

  //TODO: Validate that the principal, role and permission, all belong to the same organization/instance
  //as allowed per the rules. This needs to be done once the user and user group collections are moved
  //out of the authorization service
  private validatePrincipalRoleMatch(role: any, principal: any, principalName: string) {
    if (role.instanceId === "SYSTEM") {
      return;
    }

    if (role.organizationId === "INSTANCE") {
      if (role.instanceId === principal.instanceId) {
        return;
      } else {
        ErrUtils.throwValidationError(`Role ${role.id} (${role.roleId}) cannot be assigned to ${principalName} ${principal.id}`,
          "ROLE_CANNOT_BE_ASSIGNED_TO_PRINCIPAL");
      }
    }

    if (!(role.instanceId === principal.instanceId &&
      role.organizationId === principal.organizationId)) {
      ErrUtils.throwValidationError(`Role ${role.id} (${role.roleId}) cannot be assigned to ${principalName} ${principal.id}`,
        "ROLE_CANNOT_BE_ASSIGNED_TO_PRINCIPAL");
    }
  }

}
