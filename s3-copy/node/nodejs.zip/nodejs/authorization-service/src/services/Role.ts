import { IActionModel } from '../models/Action';
import { provideSingleton } from '../ioc/ioc';
import { BaseService } from './Base';
import { CompositeHierarchyService } from './CompositeHierarchy';
import { ErrUtils } from '@edunxtv2/service-util';
import { PermissionDeletorService } from './PermissionDeletor';
import { inject } from 'inversify';
import { RoleModel } from '../models/Role';

@provideSingleton(RoleService)
export class RoleService extends CompositeHierarchyService {

  constructor(@inject(PermissionDeletorService) private permissionDeletorService: PermissionDeletorService) {
    super();
  }

  protected getChildAttribsName(): string {
    return "childRoleIds";
  }

  protected getEntityAttribName(): string {
    return "roleName";
  }

  protected getModel() {
    return RoleModel;
  }

  protected getChildModel() {
    return RoleModel;
  }

  protected getEntityName(): string {
    return BaseService.ENTITY_ROLE;
  }

  protected getChildEntityName(): string {
    return BaseService.ENTITY_ROLE;
  }

  public async create(roleName: string, description: string,
    instanceId: string, organizationId: string): Promise<IActionModel> {
    const roleModel: any = await this.createEntity({
      roleName: roleName,
      description: description,
      instanceId: instanceId,
      organizationId: organizationId
    }, roleName);

    return roleModel;
  }

  public async delete(id: string): Promise<void> {
    await super.delete(id);
    await this.handleChildDeletion(id);
    await this.permissionDeletorService.handleRoleActionDeletion(id);
  }

  public async findByRoleNames(roleNamesCriteria: { [s: string]: string }[]): Promise<any[]> {
    return await super.findAll({
      filter: { "$or": roleNamesCriteria },
      sortOptions: [ { sortKey: "roleName", sortOrder: 1 } ]
    });
  }

  protected async validate(childIds: string[], parentIds: string[]): Promise<void> {
    const entities: any = await this.validateParentAndChildrenExist(childIds, parentIds);

    for (let parentRole of entities.parentEntities) {
      for (let childRole of entities.childEntities) {
        if (!this.allowedToAddChildToParent(parentRole, childRole)) {
          ErrUtils.throwValidationError(`Not allowed to add role ${childRole.roleName} (${childRole.id}) to role ${parentRole.roleName} (${parentRole.id}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role.`,
            "CHILD_ROLE_ADDITION_NOT_ALLOWED");
        }
      }
    }
  }

  private allowedToAddChildToParent(parentRole: any, childRole: any): boolean {
    if (childRole.instanceId === "SYSTEM") {
      return true;
    }

    if (this.isRoleOfTypeInstance(childRole)) {
      return (parentRole.instanceId === childRole.instanceId);
    }

    return (parentRole.instanceId === childRole.instanceId &&
      parentRole.organizationId === childRole.organizationId);
  }

  isRoleOfTypeInstance(role: any) {
    return role.organizationId === "INSTANCE";
  }

}
