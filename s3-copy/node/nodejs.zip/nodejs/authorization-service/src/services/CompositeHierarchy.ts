import { injectable } from "inversify";
import * as _ from 'lodash';
import { BaseService } from "./Base";
import { QueryCriteria } from "../interfaces/QueryCriteria";
import { Document } from 'mongoose';

@injectable()
export abstract class CompositeHierarchyService extends BaseService {

  protected abstract getChildAttribsName(): string;

  protected abstract getEntityAttribName(): string;

  protected getChildConnectField(): string {
    return this.getChildAttribsName();
  }

  protected abstract async validate(childIds: string[], parentIds: string[]): Promise<void>;

  protected getParentModel(): any {
    return this.getModel();
  }

  protected getParentEntityName(): string {
    return this.getEntityName();
  }

  protected async fetchExistingEntities(entityName: string, ids: string[]):
    Promise<{ [s: string]: boolean }> {
    const model: any = BaseService.MODEL_MAP[entityName];
    const results: { [s: string]: boolean } = {};
    const filter = {
      id: { $in: ids }
    };

    const entities = await model.find(
      filter,
      {
        id: 1
      }).session(this.getSession()).exec();

    for (let entity of entities) {
      results[entity.id] = true;
    }

    return results;
  }

  public async findEntitiesMatchingText(text: string) {
    return this.getModel().find({
      $or: [
        {}
      ]
    }).session(this.getSession()).exec();
  }

  public async findAllChildren(ids: string[]) {
    const children: any[] = await this.getParentModel().aggregate([
      { $match: { id: { $in: ids } } },
      {
        $graphLookup: {
          from: this.getChildModel().modelName,
          startWith: `$${this.getChildAttribsName()}`,
          connectFromField: this.getChildConnectField(),
          connectToField: "id",
          as: "children"
        }
      },
      {
        $project: {
          id: 1,
          "children.id": 1,
          _id: 0
        }
      }
    ]).session(this.getSession()).exec();

    const idToChildrenMapping: { [s: string]: string[] } = {};

    for (let child of children) {
      idToChildrenMapping[child.id] = _.map(child.children, "id");
    }

    return idToChildrenMapping;
  }

  async findChildren(entityId: string, defaultQueryCriteria: QueryCriteria): Promise<Document[]> {
    await this.validateEntitiesExist([entityId], this.getEntityName());

    const entity: Document = await this.findById(entityId);
    const childIds: string[] = entity[this.getChildAttribsName()];

    const queryCriteria: QueryCriteria = _.cloneDeep(defaultQueryCriteria);
    queryCriteria.filter.id = { $in: childIds };

    return await this.findAll(queryCriteria, this.getChildEntityName());
  }

  async findParents(childId: string, defaultQueryCriteria: QueryCriteria) {
    await this.validateEntitiesExist([childId], this.getChildEntityName());

    const queryCriteria: QueryCriteria = _.cloneDeep(defaultQueryCriteria);
    queryCriteria.filter[this.getChildAttribsName()] = childId;

    return await this.findAll(queryCriteria, this.getEntityName());
  }

  async removeChildrenFromParents(parentIds: string[], childIds: string[]) {
    return await this.getModel().updateMany({
      id: { $in: parentIds }
    }, {
      $pullAll: {
        [this.getChildAttribsName()]: childIds
      }
    }).session(this.getSession()).exec();
  }

  async addChildrenToParents(childIds: string[], parentIds: string[]) {
    await this.validate(childIds, parentIds);

    return await this.getModel().updateMany(
      {
        id: { $in: parentIds }
      }, {
      "$addToSet": {
        [this.getChildAttribsName()]: childIds
      }
    }).session(this.getSession()).exec();
  }

  async handleChildDeletion(childId: string) {
    return await this.getModel().updateMany({
      [this.getChildAttribsName()]: childId
    }, {
      $pull: {
        [this.getChildAttribsName()]: childId
      }
    }).session(this.getSession()).exec();
  }

  async delete(entityId: string) {
    await this.getModel().deleteOne(
      { id: entityId }).
      session(this.getSession()).exec();
  }

  public async updateAttributes(id: string, name: string, description: string) {
    await this.validateEntitiesExist([id]);

    const updateObj: any = {};

    if (name && name.trim().length > 0) {
      updateObj[this.getEntityAttribName()] = name.trim();
    }

    if (description && description.trim().length > 0) {
      updateObj.description = description.trim();
    }

    return await this.getModel().findOneAndUpdate({
      id: id
    }, {
      "$set": updateObj
    }).exec();
  }

}
