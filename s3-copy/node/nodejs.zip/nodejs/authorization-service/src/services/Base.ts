import { injectable } from "inversify";
import { Utils } from "../utils/Utils";
import { ActionModel } from "../models/Action";
import { RoleModel } from "../models/Role";
import { QueryCriteria } from "../interfaces/QueryCriteria";
import { TransactionManagerFactory, OrmOdms, ErrUtils } from "@edunxtv2/service-util";
import * as _ from 'lodash';
import { ClientSession, ObjectID } from "mongodb";
import { Document, Model } from 'mongoose';
import * as mongoose from 'mongoose';
import { PermissionModel } from "../models/Permission";

@injectable()
export abstract class BaseService {

  protected static ENTITY_USER: string = "user";

  protected static ENTITY_USER_GROUP: string = "userGroup";

  protected static ENTITY_ROLE: string = "role";

  protected static ENTITY_ACTION: string = "action";

  protected static ENTITY_PERMISSION: string = "permission";

  protected abstract getParentModel(): any;

  protected abstract getParentEntityName(): string;

  protected abstract getModel(): any;

  protected abstract getEntityName(): string;

  protected abstract getChildModel();

  protected abstract getChildEntityName(): string;

  protected static MODEL_MAP: { [s: string]: any } = {
    [BaseService.ENTITY_ROLE]: RoleModel,
    [BaseService.ENTITY_ACTION]: ActionModel,
    [BaseService.ENTITY_PERMISSION]: PermissionModel,
  }

  getEntityModel(entityName: string): any {
    return BaseService.MODEL_MAP[entityName];
  }

  async clearAll(): Promise<any> {
    if (process.env.ALLOW_CLEAR_ALL === "true") {
      await Promise.all([
        ActionModel.deleteMany({}).exec(),
        RoleModel.deleteMany({}).exec(),
        PermissionModel.deleteMany({}).exec()
      ]);
      console.log("Deleted all");
    } else {
      throw Utils.createValidationError(
        `clearAll() not allowed for environment ${process.env.NODE_ENV}`);
    }
  }

  async findAll(criteria: QueryCriteria, entityName: string = null): Promise<Document[]> {
    return await this.find(criteria, entityName || this.getEntityName());
  }

  protected async fetchMissingEntityIds(entityName: string, entityIds: string[]): Promise<string[]> {
    const existingEntities: { [s: string]: boolean } =
      await this.fetchExistingEntities(entityName, entityIds);
    console.log("entityName", entityName);
    console.log("entityIds", entityIds);
    console.log("existingEntities", existingEntities);

    const missingEntities = [];

    for (let entityId of entityIds) {
      if (!existingEntities[entityId]) {
        missingEntities.push(entityId);
      }
    }

    return missingEntities;
  }

  public getSession(): ClientSession {
    return TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE).getTransaction();
  }

  protected async validateEntitiesExist(ids: string[], entityName: string = null): Promise<void> {
    if (!entityName) {
      entityName = this.getEntityName();
    }

    if (!ids || ids.length === 0) {
      return;
    }

    const missingEntityIds: string[] = await this.fetchMissingEntityIds(entityName, ids);
    console.log("*******************************");
    console.log(missingEntityIds);
    console.log("*******************************");

    if (missingEntityIds.length > 0) {
      throw ErrUtils.createValidationError(
        `The following ${entityName} entities were not found in the database: ${missingEntityIds.join(", ")}`,
        "ERROR_CODE_MISSING_ENTITIES");
    }
  }

  protected async fetchExistingEntities(entityName: string, ids: string[]): Promise<{ [s: string]: boolean }> {
    const model: any = BaseService.MODEL_MAP[entityName];
    const results: { [s: string]: boolean } = {};

    const entities = await model.find(
      {
        id: {
          $in: ids
        }
      },
      {
        id: 1
      }).session(this.getSession()).exec();

    for (let entity of entities) {
      results[entity.id] = true;
    }

    return results;
  }

  protected async createEntity(entity: { [s: string]: any }, entityId: string):
    Promise<Document> {
    try {
      return await this.getModel().create([entity], { session: this.getSession() });
    } catch (err) {
      if (err.message.startsWith("E11000 duplicate key error collection")) {
        ErrUtils.throwValidationError(`Entity ${this.getEntityName()} with id ${entityId} already exists`,
          "ENTITY_EXISTS");
      } else {
        throw err;
      }
    }
  }

  protected convertToObjectIds(ids: string[]): mongoose.Types.ObjectId[] {
    return ids.map((id: string) => {
      return mongoose.Types.ObjectId(id);
    });
  }

  protected convertToObjectId(id: string): mongoose.Types.ObjectId {
    return mongoose.Types.ObjectId(id);
  }

  protected async find(criteria: QueryCriteria, entityName: string = null): Promise<Document[]> {
    entityName = entityName ? entityName : this.getEntityName();
    const pipeline: any[] = [];

    if (!criteria.filter) {
      criteria.filter = {};
    }

    pipeline.push({ $match: criteria.filter });

    if (criteria.fields && criteria.fields.length > 0) {
      const fields: { [s: string]: number } = {};
      pipeline.push({ $project: fields });

      for (let field of criteria.fields) {
        fields[field] = 1;
      }
    }

    if (criteria.sortOptions) {
      const sortOptions: { [s: string]: number } = {};
      pipeline.push({ $sort: sortOptions });

      for (let sortOption of criteria.sortOptions) {
        sortOptions[sortOption.sortKey] = sortOption.sortOrder;
      }
    }

    const skip = criteria.skip ? criteria.skip : 0;
    pipeline.push({ $skip: skip });

    const limit = criteria.limit ? criteria.limit : 20;
    pipeline.push({ $limit: limit });

    const model: any = BaseService.MODEL_MAP[entityName];
    const results = await model.aggregate(pipeline).session(this.getSession()).exec();

    return results;
  }

  async findById(id: string, entityName: string = null): Promise<Document> {
    const model: any = entityName ? this.getEntityModel(entityName) : this.getModel();
    return await model.findOne({ id: id });
  }

  protected async commit() {
    await TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE).commit();
  }

  protected async validateParentAndChildrenExist(childEntityIds: string[], parentEntityIds: string[]): Promise<any> {
    const entities: any = await this.fetchChildAndParentEntities(childEntityIds, parentEntityIds);

    this.validateAllEntitiesExist(entities.childEntities, childEntityIds, this.getChildEntityName());
    this.validateAllEntitiesExist(entities.parentEntities, parentEntityIds, this.getParentEntityName());

    return entities;
  }

  protected async validateEntitiesExistAndBelongToSameOrg(childEntityIds: string[],
    parentEntityIds: string[], checkOrgs: boolean = true) {
    const entities: any = await this.validateParentAndChildrenExist(childEntityIds, parentEntityIds);

    if (checkOrgs) {
      this.validateAllEntitiesHaveSameInstanceAndOrg(entities.childEntities, entities.parentEntities);
    }
  }

  async fetchChildAndParentEntities(childEntityIds: string[], parentEntityIds: string[]):
    Promise<{ [s: string]: any }> {
    const [childEntities, parentEntities] = await Promise.all([
      await this.getChildModel().find({
        id: { $in: childEntityIds }
      }).session(this.getSession()).exec(),
      this.getParentModel().find({
        id: { $in: parentEntityIds }
      }).session(this.getSession()).exec()
    ]);

    return {
      childEntities: childEntities,
      parentEntities: parentEntities
    }
  }

  private validateAllEntitiesHaveSameInstanceAndOrg(
    childEntities: any[], parentEntities: any[]): void {
    const allEntitiesStr: any[] = [...childEntities];
    allEntitiesStr.push(...parentEntities);
    const allEntityIds: string[] = _.map([allEntitiesStr], "id");

    allEntitiesStr.forEach((entity: any) => {
      return `${entity.instanceId}&${entity.organizationId}`;
    });

    if (_.uniq(allEntitiesStr).length > 1) {
      ErrUtils.throwValidationError(`${this.getChildEntityName()} and ${this.getParentEntityName()} entities must have the same instance and organization ids. However, that isn't the case for the following entities: ${allEntityIds.join(", ")}`,
        "NON_MATCHING_INSTANCE_ORG_IDS");
    };
  }

  private validateAllEntitiesExist(existingEntities: any[], entityIds: string[], entityName: string): void {
    const existingEntityIds = _.map(existingEntities, "id");
    const missingEntityIds = _.difference(entityIds, existingEntityIds);

    if (missingEntityIds.length > 0) {
      ErrUtils.throwValidationError(
        `The following ${entityName} entities were not found in the database: ${missingEntityIds.join(", ")}`,
        "ERROR_CODE_MISSING_ENTITIES");
    }
  }

}
