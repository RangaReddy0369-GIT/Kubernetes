import { ActionModel, IActionModel } from '../models/Action';
import { provideSingleton } from '../ioc/ioc';
import { BaseService } from './Base';
import { CompositeHierarchyService } from './CompositeHierarchy';
import { RoleActionRelationService } from './RoleActionRelationship';
import { inject } from 'inversify';
import { PermissionDeletorService } from './PermissionDeletor';
import * as _ from 'lodash';

@provideSingleton(ActionService)
export class ActionService extends CompositeHierarchyService {

  constructor(
    @inject(RoleActionRelationService) private roleActionRelationService: RoleActionRelationService,
    @inject(PermissionDeletorService) private permissionDeletorService: PermissionDeletorService
  ) {
    super();
  }

  protected getModel() {
    return ActionModel;
  }

  protected getChildModel() {
    return ActionModel;
  }

  protected getEntityName(): string {
    return BaseService.ENTITY_ACTION;
  }

  protected getChildEntityName(): string {
    return BaseService.ENTITY_ACTION;
  }

  protected getChildAttribsName(): string {
    return "childActionIds";
  }

  protected getEntityAttribName(): string {
    return "actionName";
  }

  public async create(actionName: string, description: string): Promise<IActionModel> {
    const actionModel: any = await this.createEntity({
      actionName: actionName,
      description: description
    }, actionName);

    return actionModel;
  }

  public async delete(id: string): Promise<void> {
    await super.delete(id);
    await this.handleChildDeletion(id);
    await this.roleActionRelationService.handleChildDeletion(id);
    await this.permissionDeletorService.handleRoleActionDeletion(id);
  }

  public async fetchActionNamesForIds(actionIds: string[]) {
    const actions: any[] = await ActionModel.find({
      id: actionIds
    });

    const idToNameMapping: {[s: string]: string} = {};

    for(let action of actions) {
      idToNameMapping[action.id] = action.actionName;
    }

    return idToNameMapping;
  }

  public async fetchActionIdsForNames(actionNames: string[]): Promise<{[s: string]: string}> {
    const nameToIdMapping: {[s: string]: string} = {};
    const actions: any[] = await ActionModel.find({
      actionName: actionNames
    });

    for(let action of actions) {
      nameToIdMapping[action.actionName] = action.id;
    }

    return nameToIdMapping;
  }

  protected async validate(childIds: string[], parentIds: string[]): Promise<void> {
    await this.validateParentAndChildrenExist(childIds, parentIds);
  }

}
