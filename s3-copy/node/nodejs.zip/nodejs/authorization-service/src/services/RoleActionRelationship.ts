import { ActionModel } from '../models/Action';
import { RoleModel } from '../models/Role';
import { provideSingleton } from '../ioc/ioc';
import { BaseService } from './Base';
import { CompositeHierarchyService } from './CompositeHierarchy';
import * as _ from 'lodash';

@provideSingleton(RoleActionRelationService)
export class RoleActionRelationService extends CompositeHierarchyService {

  protected getModel() {
    return RoleModel;
  }

  protected getChildModel() {
    return ActionModel;
  }

  protected getEntityName(): string {
    return BaseService.ENTITY_ROLE;
  }

  protected getChildEntityName(): string {
    return BaseService.ENTITY_ACTION;
  }

  protected getChildAttribsName(): string {
    return "actionIds";
  }

  protected getEntityAttribName(): string {
    return "NA";
  }

  protected getChildConnectField(): string {
    return "childActionIds";
  }

  protected async validate(childIds: string[], parentIds: string[]): Promise<void> {
    await this.validateParentAndChildrenExist(childIds, parentIds);
  }

}
