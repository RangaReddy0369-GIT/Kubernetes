import * as mongoose from 'mongoose';
import { Document, Schema } from 'mongoose';
import { Utils } from '../utils/Utils';

interface IPermissionModel extends Document {
  id: string,
  instanceId: string,
  organizationId: string,
  principalId: string,
  isUser: boolean,
  actionRoleId: string,
  isRole: boolean,
  scopes: string[]
};

const permissionSchema = new Schema({
  id: { type: String, index: true, unique: true, default: Utils.generateUuid },
  instanceId: { type: String, index: true },
  organizationId: { type: String, index: true },
  isUser: { type: Boolean, index: true },
  principalId: { type: String, index: true },
  actionRoleId: { type: String, index: true },
  isRole: { type: Boolean, index: true, default: false },
  scopes: [{ type: String, index: true }],
}, { versionKey: false });

const PermissionModel = mongoose.model<IPermissionModel>('permissions', permissionSchema);

export { IPermissionModel, PermissionModel };
