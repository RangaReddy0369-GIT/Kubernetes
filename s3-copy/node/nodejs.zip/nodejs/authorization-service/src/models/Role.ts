import * as mongoose from 'mongoose';
import { Document, Schema } from 'mongoose';
import { Utils } from '../utils/Utils';

interface IRoleModel extends Document {
  id: string,
  instanceId: string,
  organizationId: string,
  roleName: string,
  childRoleIds: string[],
  actionIds: string[],
  description: string
};

const roleSchema: Schema = new Schema({
  id: { type: String, index: true, unique: true, default: Utils.generateUuid },
  instanceId: { type: String, index: true },
  organizationId: { type: String, index: true },
  roleName: { type: String, index: true },
  childRoleIds: [{ type: String, index: true, default: [] }],
  actionIds: [{ type: String, index: true, default: [] }],
  description: String
}, { versionKey: false });

roleSchema.index({ instanceId: 1, organizationId: 1, roleName: 1 }, { unique: true });

const RoleModel = mongoose.model<IRoleModel>('roles', roleSchema);

export { IRoleModel, RoleModel };
