import * as mongoose from 'mongoose';
import { Document, Schema } from 'mongoose';
import { Utils } from '../utils/Utils';

interface IActionModel extends Document {
  id: string,
  actionName: string,
  childActionIds: string[],
  description: string
};

const actionSchema: Schema = new Schema({
  id: { type: String, index: true, unique: true, default: Utils.generateUuid },
  actionName: { type: String, index: true, unique: true },
  childActionIds: [{ type: String, index: true, default: [] }],
  description: String
}, { versionKey: false });

const ActionModel = mongoose.model<IActionModel>('actions', actionSchema);

export { IActionModel, ActionModel };
