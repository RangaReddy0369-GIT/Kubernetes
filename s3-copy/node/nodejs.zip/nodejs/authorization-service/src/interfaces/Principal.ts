import { PrincipalType } from '../enums/PrincipalType';

export interface Principal {
  principal: string,
  principalType: PrincipalType
}