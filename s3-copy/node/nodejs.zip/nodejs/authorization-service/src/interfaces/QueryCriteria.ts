export interface QueryCriteria {
  filter?: {[s: string]: any},
  fields?: string[],
  sortOptions?: SortOption[],
  skip?: number
  limit?: number
}

export interface SortOption {
  sortKey: string,
  sortOrder: number
}
