export interface PermissionsQuery {
  actionId: string,
  actionName: string,
  scope: string,
  allowed: boolean
}

export interface Action {
  actionId?: string,
  actionName?: string
}

export interface PermissionIntermediate {
  actionIds: string[],
  scopes: string[]
}

export interface TicketPermission {
  actionNames: string[],
  scopes: string[]
}

export interface Permission {
  actions: Action[],
  scopes: string[]
}

export interface PermissionTicket {
  permissions?: TicketPermission[],
  userGroupIds?: string[],
  expiry: number
}
