import 'reflect-metadata';
import { fluentProvide } from 'inversify-binding-decorators';
import {Container} from 'inversify';

export const provideSingleton = function (identifier) {
  return fluentProvide(identifier)
    .inSingletonScope()
    .done();
};

export const container = new Container();
