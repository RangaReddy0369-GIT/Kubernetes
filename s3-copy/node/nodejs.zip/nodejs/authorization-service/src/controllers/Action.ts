import { inject } from "inversify";
import { controller, httpGet, httpPost, httpPut, httpDelete } from 'inversify-express-utils';
import { Request, Response, NextFunction } from "express";
import { ValidationUtils } from "@edunxtv2/service-util";
import { Constants } from "../constants/Constants";
import { RequestPreprocessor } from "../utils/RequestPreprocessor";
import { ActionService } from "../services/Action";
import { CompositeHierarchyController } from "./CompositeHierarchyController";
import { Logger } from '@edunxtv2/service-util';
import { Utils } from "../utils/Utils";
import { ActionModel } from "../models/Action";

@controller(`${Constants.CONTEXT_PATH}/actions`)
export class ActionController extends CompositeHierarchyController {

  constructor(@inject(ActionService) private actionService: ActionService) {
    super();
  }

  protected getEntityAttribName(): string {
    return "actionName";
  }

  protected getParentAttribsName(): string {
    return "parentActionIds";
  }

  protected getChildAttribsName(): string {
    return "childActionIds";
  }

  protected getService(): ActionService {
    return this.actionService;
  }

  @httpDelete("/clear/all", RequestPreprocessor.preprocess)
  public async clearAll(req: Request, res: Response, next: NextFunction) {
    await this.actionService.clearAll();

    await this.commitTransaction();
    res.send("success");
  }

  @httpPost("/", RequestPreprocessor.preprocess)
  public async create(req: Request, res: Response, next: NextFunction) {
    ValidationUtils.validateStringNotEmpty(req.body.actionName, "actionName");
    const description = (!req.body.description || req.body.description.trim().length === 0) ?
      req.body.actionName : req.body.description.trim();

    const result: any = await this.actionService.create(req.body.actionName, description);

    await this.commitTransaction();
    res.json(result[0]);
  }

  @httpGet("/", RequestPreprocessor.preprocess)
  public async findAll(req: Request, res: Response, next: NextFunction) {
    await super.findAll(req, res, next);
  }

  @httpGet("/:id", RequestPreprocessor.preprocess)
  public async findById(req: Request, res: Response, next: NextFunction) {
    await super.findById(req, res, next);
  }

  @httpGet("/childActions/:id", RequestPreprocessor.preprocess)
  public async findChildren(req: Request, res: Response, next: NextFunction) {
    await super.findChildren(req, res, next);
  }

  @httpGet("/parentActions/:id", RequestPreprocessor.preprocess)
  public async findParents(req: Request, res: Response, next: NextFunction) {
    await super.findParents(req, res, next);
  }

  @httpPut("/:id", RequestPreprocessor.preprocess)
  public async updateAttributes(req: Request, res: Response, next: NextFunction) {
    await super.updateAttributes(req, res, next);
  }

  @httpPut("/actions/parents", RequestPreprocessor.preprocess)
  public async addChildrenToParents(req: Request, res: Response, next: NextFunction) {
    await super.addChildrenToParents(req, res, next);
  }

  @httpDelete("/actions/parents", RequestPreprocessor.preprocess)
  public async removeChildrenFromParents(req: Request, res: Response, next: NextFunction) {
    await super.removeChildrenFromParents(req, res, next);
  }

  @httpDelete("/:id", RequestPreprocessor.preprocess)
  public async delete(req: Request, res: Response, next: NextFunction) {
    await super.delete(req, res, next);
  }

}
