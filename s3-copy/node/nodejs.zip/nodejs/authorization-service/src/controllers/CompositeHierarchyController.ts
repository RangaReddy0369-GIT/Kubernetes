import { injectable } from "inversify";
import { Request, Response, NextFunction } from "express";
import { ValidationUtils, ErrUtils } from "@edunxtv2/service-util";
import { BaseController } from "./Base";
import { CompositeHierarchyService } from "../services/CompositeHierarchy";

@injectable()
export abstract class CompositeHierarchyController extends BaseController {

  protected abstract getService(): CompositeHierarchyService;

  protected abstract getEntityAttribName(): string;

  protected abstract getParentAttribsName(): string;

  protected abstract getChildAttribsName(): string;

  public async findAll(req: Request, res: Response, next: NextFunction) {
    const results: any[] = await this.getService().findAll(
      this.createDefaultQueryCriteria(req));

    await this.commitTransaction();
    res.json(results);
  }

  public async findById(req: Request, res: Response, next: NextFunction) {
    ValidationUtils.validateStringNotEmpty(req.params.id, "action id");
    const result = await this.getService().findById(req.params.id);

    await this.commitTransaction();
    res.json(result);
  }

  public async findChildren(req: Request, res: Response, next: NextFunction) {
    const results: any = await this.getService().findChildren(
      req.params.id, this.createDefaultQueryCriteria(req));

    await this.commitTransaction();
    res.json(results);
  }

  public async findParents(req: Request, res: Response, next: NextFunction) {
    const results: any = await this.getService().findParents(
      req.params.id, this.createDefaultQueryCriteria(req));

    await this.commitTransaction();
    res.json(results);
  }

  public async updateAttributes(req: Request, res: Response, next: NextFunction) {
    this.validateAttributes(req);

    const result: any = await this.getService().updateAttributes(req.params.id,
      req.body[this.getEntityAttribName()], req.body.description);

    await this.commitTransaction();
    res.json(result);
  }

  validateAttributes(req: Request) {
    const entityNameAttrib: string = this.getEntityAttribName();
    const entityName: string = req.body[entityNameAttrib];
    const description: string = req.body.description;
    
    if(!(entityName && entityName.trim().length > 0) && !(description && description.trim().length > 0)) {
      ErrUtils.throwValidationError(`Either the ${entityNameAttrib} or the description must be specified`,
        "ENTITY_NAME_AND_DESC_MISSING");
    }
  }

  public async addChildrenToParents(req: Request, res: Response, next: NextFunction) {
    this.validateRelationAttributes(req, this.getChildAttribsName(), this.getParentAttribsName());

    const result = await this.getService().addChildrenToParents(
      req.body[this.getChildAttribsName()], req.body[this.getParentAttribsName()]);

    await this.commitTransaction();
    res.json(result);
  }

  public async removeChildrenFromParents(req: Request, res: Response, next: NextFunction) {
    await this.validateRelationAttributes(req, this.getChildAttribsName(), this.getParentAttribsName(), false);

    const result: any = await this.getService().removeChildrenFromParents(
      req.body[this.getParentAttribsName()], req.body[this.getChildAttribsName()]);

    await this.commitTransaction();
    res.json(result);
  }

  public async delete(req: Request, res: Response, next: NextFunction) {
    await this.getService().delete(req.params.id);

    await this.commitTransaction();
    res.send("success");
  }

}
