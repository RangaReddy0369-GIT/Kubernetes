import { inject } from "inversify";
import { controller, httpGet, httpPut, httpDelete } from 'inversify-express-utils';
import { Request, Response, NextFunction } from "express";
import { Constants } from "../constants/Constants";
import { RequestPreprocessor } from "../utils/RequestPreprocessor";
import { CompositeHierarchyController } from "./CompositeHierarchyController";
import { RoleActionRelationService } from "../services/RoleActionRelationship";

@controller(`${Constants.CONTEXT_PATH}/roleactions`)
export class RoleActionRelationshipController extends CompositeHierarchyController {

  constructor(@inject(RoleActionRelationService)
  private roleActionRelationshipService: RoleActionRelationService) {
    super();
  }

  protected getEntityAttribName(): string {
    return "roleName";
  }

  protected getChildAttribName(): string {
    return "actionId";
  }

  protected getParentAttribsName(): string {
    return "roleIds";
  }

  protected getChildAttribsName(): string {
    return "actionIds";
  }

  protected getService(): RoleActionRelationService {
    return this.roleActionRelationshipService;
  }

  @httpGet("/childActions/:id", RequestPreprocessor.preprocess)
  public async findChildren(req: Request, res: Response, next: NextFunction) {
    await super.findChildren(req, res, next);
  }

  @httpGet("/parentRoles/:id", RequestPreprocessor.preprocess)
  public async findParents(req: Request, res: Response, next: NextFunction) {
    await super.findParents(req, res, next);
  }

  @httpPut("/roles/actions", RequestPreprocessor.preprocess)
  public async addActionsToRoles(req: Request, res: Response, next: NextFunction) {
    await super.addChildrenToParents(req, res, next);
  }

  @httpDelete("/roles/actions", RequestPreprocessor.preprocess)
  public async removeChildrenFromParents(req: Request, res: Response, next: NextFunction) {
    await super.removeChildrenFromParents(req, res, next);
  }

}
