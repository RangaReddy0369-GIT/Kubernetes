import { Request, Response } from 'express';
import { controller, httpGet } from 'inversify-express-utils';
import { Constants } from '../constants/Constants';
import { inject } from 'inversify';
import { BaseController } from './Base';
import { ActionService } from '../services/Action';

@controller(`${Constants.CONTEXT_PATH}/healthcheck`)
export class HealthCheckController extends BaseController {

  constructor(@inject(ActionService) private actionService: ActionService) {
    super();
  }  

  @httpGet('/')
  public async checkHealth(req: Request, res: Response) {
    await this.actionService.findById("nonExistentId");
    
    await this.commitTransaction();
    res.send("success");
  }

}
