import { inject } from "inversify";
import { controller, httpGet, httpPost, httpPut, httpDelete } from 'inversify-express-utils';
import { Request, Response, NextFunction } from "express";
import { ValidationUtils, ErrUtils, ReqContextManager } from "@edunxtv2/service-util";
import { Constants } from "../constants/Constants";
import { RequestPreprocessor } from "../utils/RequestPreprocessor";
import { PermissionService } from "../services/Permission";
import { BaseController } from "./Base";
import { Permission, PermissionsQuery, PermissionIntermediate, TicketPermission } from "../interfaces/Permission";
import * as _ from 'lodash';
import { ActionService } from "../services/Action";

@controller(`${Constants.CONTEXT_PATH}/permissions`)
export class PermissionController extends BaseController {

  constructor(
    @inject(PermissionService) private permissionService: PermissionService,
    @inject(ActionService) private actionService: ActionService
  ) {
    super();
  }

  @httpPost("/", RequestPreprocessor.preprocess)
  public async create(req: Request, res: Response, next: NextFunction) {
    this.validateForCreate(req);

    const result: any = await this.permissionService.create(req.body.instanceId,
      req.body.organizationId, req.body.principalId, req.body.isUser, req.body.actionRoleId,
      req.body.isRole, req.body.scopes);

    await this.commitTransaction();
    res.json(result[0]);
  }

  @httpGet("/", RequestPreprocessor.preprocess)
  public async findAll(req: Request, res: Response, next: NextFunction) {
    const results: any[] = await this.permissionService.findAll(this.createDefaultQueryCriteria(req));

    await this.commitTransaction();
    res.json(results);
  }

  @httpPut("/scopes/:id", RequestPreprocessor.preprocess)
  public async addScopes(req: Request, res: Response, next: NextFunction) {
    this.validateScopes(req);
    const result = this.permissionService.addScopes(req.params.id, req.body.scopes);

    await this.commitTransaction();
    res.json(result);
  }

  @httpDelete("/scopes/:id", RequestPreprocessor.preprocess)
  public async removeScopes(req: Request, res: Response, next: NextFunction) {
    this.validateScopes(req);
    const result = this.permissionService.removeScopes(req.params.id, req.body.scopes);

    await this.commitTransaction();
    res.json(result);
  }

  @httpGet("/allowed/:id/:areAllowedParams", RequestPreprocessor.preprocess)
  public async areAllowed(req: Request, res: Response, next: NextFunction) {
    const areAllowedParamsStr = req.params.areAllowedParams;
    let areAllowedParams: any = null;

    try {
      areAllowedParams = JSON.parse(areAllowedParamsStr);
    } catch (err) {
      ErrUtils.throwValidationError(`Invalid JSON string provided for areAllowedParams`,
        "INVALID_JSON_PERMISSIONS_QUERY_STR");
    }

    this.validateAreAllowedParams(areAllowedParams);
    this.convertActionNamesToUpperCase(areAllowedParams.permissionsQueries);
    const allowAll: boolean = ReqContextManager.getAuthToken() ? false : true;
    let permissions: PermissionIntermediate[] = null;

    if (!allowAll) {
      let dummyVariable;

      [permissions, dummyVariable] = await Promise.all([
        this.permissionService.determineAllPermissionsForUser(req.params.id, areAllowedParams.instanceId, areAllowedParams.organizationId),
        this.populateActionIds(areAllowedParams.permissionsQueries)
      ]);
    }

    this.permissionService.updateQueryWithResult(areAllowedParams.permissionsQueries, permissions, allowAll);

    await this.commitTransaction();
    res.json(areAllowedParams);
  }

  private convertActionNamesToUpperCase(permissionsQueries: PermissionsQuery[]) {
    for (let permissionQuery of permissionsQueries) {
      permissionQuery.actionName = permissionQuery.actionName.toUpperCase();
    }
  }

  public async populateActionIds(permissionQueries: PermissionsQuery[]): Promise<void> {
    const actionNames: string[] = _.map(permissionQueries, "actionName");
    const nameToIdMapping: { [s: string]: string } =
      await this.actionService.fetchActionIdsForNames(actionNames);

    for (let permissionQuery of permissionQueries) {
      permissionQuery.actionId = nameToIdMapping[permissionQuery.actionName];
    }
  }

  @httpGet("/permissionsTicket/:id/:instanceId/:organizationId", RequestPreprocessor.preprocess)
  public async fetchPermissionsTicket(req: Request, res: Response, next: NextFunction) {
    const id = req.params.id;

    const permissions: PermissionIntermediate[] =
      await this.permissionService.determineAllPermissionsForUser(id,
        req.params.instanceId, req.params.organizationId);
    const permissionsForTicket: TicketPermission[] = await
      this.permissionService.convertToPermissionsForTicket(permissions);

    const permissionsTicket: string =
      this.permissionService.createPermissionsTicket(permissionsForTicket);

    await this.commitTransaction();
    res.json({ permissionsTicket: permissionsTicket });
  }

  @httpDelete("/:id", RequestPreprocessor.preprocess)
  public async delete(req: Request, res: Response, next: NextFunction) {
    await this.permissionService.delete(req.params.id);

    await this.commitTransaction();
  }

  @httpDelete("/user/:id", RequestPreprocessor.preprocess)
  public async deleteEntriesForUser(req: Request, res: Response, next: NextFunction) {
    await this.permissionService.deleteForPrincipal(req.params.id, true);

    await this.commitTransaction();
    res.send("success");
  }

  @httpDelete("/usergroup/:id", RequestPreprocessor.preprocess)
  public async deleteEntriesForUsergroup(req: Request, res: Response, next: NextFunction) {
    await this.permissionService.deleteForPrincipal(req.params.id, false);

    await this.commitTransaction();
    res.send("success");
  }

  private validateForCreate(req) {
    ValidationUtils.validateStringNotEmpty(req.body.instanceId, "instanceId");
    ValidationUtils.validateStringNotEmpty(req.body.organizationId, "organizationId");
    ValidationUtils.validateStringNotEmpty(req.body.principalId, "principalId");
    ValidationUtils.validateIsNotNullOrUndefined(req.body.isUser, "isUser");
    ValidationUtils.validateStringNotEmpty(req.body.actionRoleId, "actionRoleId");
    ValidationUtils.validateIsNotNullOrUndefined(req.body.isRole, "isRole");

    this.validateScopes(req);
  }

  private validateScopes(req) {
    ValidationUtils.validateIsNotNullOrUndefined(req.body.scopes, "scopes");

    if (req.body.scopes.length === 0) {
      ErrUtils.throwValidationError("scopes cannot be empty", "EMPTY_SCOPES");
    }
  }

  private validateAreAllowedParams(areAllowedParams: any): void {
    ValidationUtils.validateIsNotNullOrUndefined(areAllowedParams, "areAllowedParams");
    ValidationUtils.validateStringNotEmpty(areAllowedParams.instanceId, "areAllowedParams.instanceId");
    ValidationUtils.validateStringNotEmpty(areAllowedParams.organizationId, "areAllowedParams.organizationId");

    const permissionsQueries: PermissionsQuery[] = areAllowedParams.permissionsQueries;

    ValidationUtils.validateArrayNotEmpty(permissionsQueries, "permissionsQueries");

    for (let permissionsQuery of permissionsQueries) {
      ValidationUtils.validateIsNotNullOrUndefined(permissionsQuery, "permissionsQuery");
      ValidationUtils.validateStringNotEmpty(permissionsQuery.actionName, "permissionsQuery.action");
      ValidationUtils.validateStringNotEmpty(permissionsQuery.scope, "permissionsQuery.scope");
    }
  }

}
