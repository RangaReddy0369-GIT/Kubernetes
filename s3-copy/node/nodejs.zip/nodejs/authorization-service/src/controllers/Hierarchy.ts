import { injectable } from "inversify";
import { Request, Response, NextFunction } from "express";
import { BaseController } from "./Base";
import { HierarchyService } from "../services/Hierarchy";

@injectable()
export abstract class HierarchyController extends BaseController {

  protected abstract getService(): HierarchyService;

  protected abstract getParentAttribsName(): string;

  protected abstract getChildAttribsName(): string;

  protected async findAll(req: Request, res: Response, next: NextFunction) {
    res.json(await this.getService().findAll(this.createDefaultQueryCriteria(req)));
    await this.commitTransaction();
  }

  protected async addChildrenToParents(req: Request, res: Response, next: NextFunction) {
    this.validateRelationAttributes(req, this.getParentAttribsName(), this.getChildAttribsName());
    const result = await this.getService().addChildrenToParents(
      req.body[this.getParentAttribsName()], req.body[this.getChildAttribsName()]);

    await this.commitTransaction();
    res.json(result);
  }

  protected async removeChildrenFromParents(req: Request, res: Response, next: NextFunction) {
    await this.validateRelationAttributes(req, this.getParentAttribsName(), this.getChildAttribsName(), false);

    const result: any = await this.getService().removeChildrenFromParents(
      req.body[this.getParentAttribsName()], req.body[this.getChildAttribsName()]);

    await this.commitTransaction();
    res.json(result);
  }

  protected async delete(req: Request, res: Response, next: NextFunction) {
    await this.getService().delete(req.params.id);

    await this.commitTransaction();
    res.send("success");
  }

}
