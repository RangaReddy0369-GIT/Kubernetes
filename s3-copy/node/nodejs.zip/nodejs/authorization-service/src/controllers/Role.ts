import { inject } from "inversify";
import { controller, httpGet, httpPost, httpPut, httpDelete } from 'inversify-express-utils';
import { Request, Response, NextFunction } from "express";
import { ValidationUtils, ErrUtils, InstancesProvider, ResponseUtils } from "@edunxtv2/service-util";
import { Constants } from "../constants/Constants";
import { RequestPreprocessor } from "../utils/RequestPreprocessor";
import { CompositeHierarchyController } from "./CompositeHierarchyController";
import { RoleService } from "../services/Role";

@controller(`${Constants.CONTEXT_PATH}/roles`)
export class RoleController extends CompositeHierarchyController {

  constructor(@inject(RoleService) private roleService: RoleService) {
    super();
  }

  protected getEntityAttribName(): string {
    return "roleName";
  }

  protected getParentAttribsName(): string {
    return "parentRoleIds";
  }

  protected getChildAttribsName(): string {
    return "childRoleIds";
  }

  protected getService(): RoleService {
    return this.roleService;
  }

  @httpPost("/", RequestPreprocessor.preprocess)
  public async create(req: Request, res: Response, next: NextFunction) {
    this.validateForCreate(req.body);

    const description = (!req.body.description || req.body.description.trim().length === 0) ?
      req.body.roleName : req.body.description.trim();

    const result: any = await this.roleService.create(req.body.roleName,
      description, req.body.instanceId, req.body.organizationId);

    await this.commitTransaction();
    res.json(result[0]);
  }

  @httpGet("/", RequestPreprocessor.preprocess)
  public async findAll(req: Request, res: Response, next: NextFunction) {
    await super.findAll(req, res, next);
  }

  @httpGet("/roleNames/:roleNames", RequestPreprocessor.preprocess)
  public async findByRoleNames(req: Request, res: Response, next: NextFunction) {
    let roleNamesCriteria: {[s: string]: string}[];

    try {
      roleNamesCriteria = JSON.parse(req.params.roleNames);
    } catch (err) {
      ErrUtils.throwValidationError("Malformed JSON provided", "MALFORMED_JSON");
    }

    this.validateRoleNameCriteria(roleNamesCriteria);
    this.capitalizeRoleNames(roleNamesCriteria);

    const response: any[] = await this.roleService.findByRoleNames(roleNamesCriteria);
    
    await this.commitTransaction();

    res.json(ResponseUtils.wrapResponse(response));
  }

  private capitalizeRoleNames(roleNamesCriteria: {[s: string]: string}[]) {
    for (let role of roleNamesCriteria) {
      role.roleName = role.roleName.toUpperCase();
    }
  }

  private validateRoleNameCriteria(roleNamesCriteria: {[s: string]: string}[]) {
    if (!Array.isArray(roleNamesCriteria)) {
      ErrUtils.throwValidationError("The roleNamesCriteria must be an array", "ROLE_NAMES_NOT_ARRAY");
    }

    if (roleNamesCriteria.length === 0) {
      ErrUtils.throwValidationError("The roleNamesCriteria must not be empty", "ROLE_NAMES_EMPTY");
    }

    for (let role of roleNamesCriteria) {
      ValidationUtils.validateIsNotNullOrUndefined(role, "role within criteria");
      ValidationUtils.validateStringNotEmpty(role.roleName, "roleName");
      ValidationUtils.validateStringNotEmpty(role.organizationId, "organizationId");

      ValidationUtils.validateStringNotEmpty(role.instanceId, "instanceId");

      if (!InstancesProvider.getInstitute(role.instanceId)) {
        ErrUtils.throwValidationError(`Invalid instanceId ${role.instanceId} provided`, "INVALID_INSTANCE_ID");
      }
    }
  }

  @httpGet("/:id", RequestPreprocessor.preprocess)
  public async findById(req: Request, res: Response, next: NextFunction) {
    await super.findById(req, res, next);
  }

  @httpGet("/childRoles/:id", RequestPreprocessor.preprocess)
  public async findChildren(req: Request, res: Response, next: NextFunction) {
    await super.findChildren(req, res, next);
  }

  @httpGet("/parentRoles/:id", RequestPreprocessor.preprocess)
  public async findParents(req: Request, res: Response, next: NextFunction) {
    await super.findParents(req, res, next);
  }

  @httpPut("/:id", RequestPreprocessor.preprocess)
  public async updateAttributes(req: Request, res: Response, next: NextFunction) {
    await super.updateAttributes(req, res, next);
  }

  @httpPut("/roles/parents", RequestPreprocessor.preprocess)
  public async addRolesToParents(req: Request, res: Response, next: NextFunction) {
    await super.addChildrenToParents(req, res, next);
  }

  @httpDelete("/roles/parents", RequestPreprocessor.preprocess)
  public async removeRolesFromParents(req: Request, res: Response, next: NextFunction) {
    await super.removeChildrenFromParents(req, res, next);
  }

  @httpDelete("/:id", RequestPreprocessor.preprocess)
  public async delete(req: Request, res: Response, next: NextFunction) {
    await super.delete(req, res, next);
  }

  private validateForCreate(reqBody: any) {
    ValidationUtils.validateStringNotEmpty(reqBody.roleName, "roleName");

    const instanceId = reqBody.instanceId;
    const organizationId = reqBody.organizationId;

    ValidationUtils.validateStringNotEmpty(instanceId, "instanceId");
    ValidationUtils.validateStringNotEmpty(organizationId, "organizationId");

    if (organizationId === "SYSTEM" || instanceId === "SYSTEM") {
      if (organizationId !== "SYSTEM" || instanceId !== "SYSTEM") {
        ErrUtils.throwValidationError("Either both instanceId as well as organizationId values need to be SYSTEM or none should have the value SYSTEM",
          "INVALID_INSTANCE_ORG_COMBINATION");
      }
    } else if (instanceId === "INSTANCE") {
      ErrUtils.throwValidationError("The instanceId value cannot be set to INSTANCE",
        "INVALID_INSTANCE_VALUE");
    }
  }

}
