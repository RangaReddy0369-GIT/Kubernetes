import 'reflect-metadata';
require('express-async-errors');
import { InversifyExpressServer } from 'inversify-express-utils';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import * as compression from 'compression';
import { container } from './ioc/ioc';
import './ioc/loader';
import * as express from 'express';
import { ContextManager, ReqContextManager, ApiSecurityManager, Service, Logger, ValidationUtils, TransactionManager, TransactionManagerFactory, OrmOdms, ProviderFactory, ServiceUtil, MageHttpClient } from '@edunxtv2/service-util';
import { Request, Response, NextFunction } from 'express';
import * as mongoose from 'mongoose';

async function init() {
  Logger.init(Service.AUTHORIZATION_SERVICE);
  await connectToMongoDb();
  initializeServer();
}

function initializeServer() {
  let server = new InversifyExpressServer(container);

  server.setConfig((app: express.Application) => {
    app.use(compression());
    app.disable('etag');
    app.use(cors());

    app.use(bodyParser.urlencoded({
      extended: true
    }));

    app.use(bodyParser.json({ limit: '10mb' }));

    ServiceUtil.init();
    ContextManager.init(app);
    ReqContextManager.registerWithReqContextManager(app,
      ["/authorizationservice/healthcheck", "/authorizationservice/actions/clear/all"]);
    ApiSecurityManager.switchOnApiSecurityValidation(
      app, ["/authorizationservice/healthcheck", "/authorizationservice/actions/clear/all"],
      Service.AUTHORIZATION_SERVICE);
    MageHttpClient.init(Service.AUTHORIZATION_SERVICE);

    const transactionManager: TransactionManager =
      TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE);
    transactionManager.register(app);

    server.setErrorConfig((app) => {
      app.use(async (err: any, req: Request, res: Response, next: NextFunction) => {
        Logger.error(err, err.errId || "UNKNOWN", err.errType || "UNKNOWN");
        const transactionManager: TransactionManager =
          TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE);
        await transactionManager.rollback();

        res.status(err.code || 500).json(err.message);
      });
    });
  });

  const port = process.env.PORT || 3011;

  server.build().listen(port, () => {
    Logger.info(`Listening on port ${port}`);
  });
}

async function connectToMongoDb(): Promise<void> {
  const mongoUrl: any = ProviderFactory.getSecretsProvider()
    .getSecret("AUTHZ_SERVICE_MONGODB_URL");

  Logger.info('Connecting to mongodb. Using string ', mongoUrl);
  (mongoose as any).Promise = global.Promise;

  try {
    await mongoose.connect(mongoUrl, {});
    Logger.info('Connected to mongodb. Using string ', mongoUrl);
  } catch (err) {
    Logger.info('MongoDB connection error. Please make sure MongoDB is running. ' + err);
    process.exit();
  }
}

module.exports.init = init;
