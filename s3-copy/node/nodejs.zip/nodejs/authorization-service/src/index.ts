import 'reflect-metadata';
// tslint:disable-next-line: no-var-requires
require('express-async-errors');

import { ProviderFactory, ServiceUtil } from '@edunxtv2/service-util';

async function init() {
  require('dotenv').config()
  await ProviderFactory.init(
    [],
    ["AUTHZ_SERVICE_MONGODB_URL", "PERMISSIONS_TICKET_PRIVATE_KEY"],
    ["ALLOW_CLEAR_ALL", "PERMISSIONS_TICKET_PUBLIC_KEY", "PERMISSIONS_TICKET_EXPIRY_DURATION","DOMAIN"]
  );
  ServiceUtil.init();
  require('./bootstrap').init();
}

init();
