export class Constants {

  public static STATUS_ACTIVE = "ACTIVE";

  public static CONTEXT_PATH = "/authorizationservice";

  public static IS_SYSTEM_CONTEXT_MGR_ATTRIB = "IS_SYSTEM";

}
