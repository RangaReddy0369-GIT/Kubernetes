import { expect } from 'chai';
import 'mocha';
import * as _ from 'lodash';
import * as rp from 'request-promise';
import { TestUtils } from '@edunxtv2/service-util';
import { HttpUtil } from './HttpUtil';

beforeEach(async () => {
  await rp({
    method: "DELETE",
    uri: "http://localhost:3011/authorizationservice/actions/clear/all"
  });
});

function validateIdAndUnderscoreAndRemoveAttribs(results: any[]) {
  for (let result of results) {
    expect(result._id).to.not.be.undefined;
    expect(result.id).to.not.be.undefined;
    delete result._id;
    delete result.id;
  }
}

describe("The create API", async () => {
  it("throws an error if the roleName is not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "roleName may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/roles", {}, {});
    });
  });

  it("throws an error if either the instance id or the organization id is not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "instanceId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "instanceId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1", instanceId: " " }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "organizationId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1", instanceId: "instanceId1" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "organizationId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1", instanceId: "instanceId1", organization: " " }, {});
    });
  });

  it("throws an error if the instance id or the organization id have incorrect values and combinations", async () => {
    await TestUtils.verifyAsyncError(`401 - "Either both instanceId as well as organizationId values need to be SYSTEM or none should have the value SYSTEM"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1", instanceId: "SYSTEM", organizationId: "somethingElse" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Either both instanceId as well as organizationId values need to be SYSTEM or none should have the value SYSTEM"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1", instanceId: "somethingElse", organizationId: "SYSTEM" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The instanceId value cannot be set to INSTANCE"`, async () => {
      await HttpUtil.post("/roles", { roleName: "roleName1", instanceId: "INSTANCE", organizationId: "anything" }, {});
    });
  });

  it("successfully creates the action when all necessary data is provided, populates the default description and capitalizes the role name", async () => {
    let result: any = await HttpUtil.post("/roles",
      { roleName: "roleName1", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {});
    validateIdAndUnderscoreAndRemoveAttribs([result]);

    let expectedResult: any = {
      actionIds: [], childRoleIds: [], roleName: 'ROLENAME1',
      description: 'ROLENAME1', instanceId: "SYSTEM", organizationId: "SYSTEM"
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;

    result = await HttpUtil.post("/roles",
      { roleName: "roleName2", instanceId: "instance1", organizationId: "INSTANCE", description: "desc1" }, {});
    validateIdAndUnderscoreAndRemoveAttribs([result]);

    expectedResult = {
      actionIds: [], childRoleIds: [], roleName: 'ROLENAME2',
      description: 'desc1', instanceId: "instance1", organizationId: "INSTANCE"
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;

    result = await HttpUtil.post("/roles",
      { roleName: "roleName3", instanceId: "instanceId1", organizationId: "organizationId1", description: "desc1" }, {});
    validateIdAndUnderscoreAndRemoveAttribs([result]);

    expectedResult = {
      actionIds: [], childRoleIds: [], roleName: 'ROLENAME3',
      description: 'desc1', instanceId: "instanceId1", organizationId: "organizationId1"
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;
  });

  it("throws an error if one tries to create an action with a name that already exists within the same" +
    " organization but does not throw the error if the same role names are used across instances " +
    "and organizations with the organization and instance ids being case insensitive", async () => {
      let result: any = await HttpUtil.post("/roles",
        { roleName: "roleName1", instanceId: "instanceId1", organizationId: "organizationId1", description: "desc1" }, {});
      expect(result.roleName).equals("ROLENAME1");

      await TestUtils.verifyAsyncError(`401 - "Entity role with id ROLENAME1 already exists"`, async () => {
        await HttpUtil.post("/roles",
          { roleName: "roleName1", instanceId: "instanceId1", organizationId: "organizationId1", description: "desc1" }, {});
      });

      result = await HttpUtil.post("/roles",
        { roleName: "roleName1", instanceId: "SYSTEM", organizationId: "SYSTEM", description: "desc1" }, {});
      expect(result.roleName).equals("ROLENAME1");

      await TestUtils.verifyAsyncError(`401 - "Entity role with id ROLENAME1 already exists"`, async () => {
        await HttpUtil.post("/roles",
          { roleName: "roleName1", instanceId: "SYSTEM", organizationId: "SYSTEM", description: "desc1" }, {});
      });

      result = await HttpUtil.post("/roles",
        { roleName: "roleName1", instanceId: "instanceId1", organizationId: "INSTANCE", description: "desc1" }, {});
      expect(result.roleName).equals("ROLENAME1");

      await TestUtils.verifyAsyncError(`401 - "Entity role with id ROLENAME1 already exists"`, async () => {
        await HttpUtil.post("/roles",
          { roleName: "roleName1", instanceId: "instanceId1", organizationId: "INSTANCE", description: "desc1" }, {});
      });

      result = await HttpUtil.post("/roles",
        { roleName: "roleName1", instanceId: "InstanceId1", organizationId: "INSTANCe", description: "desc1" }, {});
      expect(result.roleName).equals("ROLENAME1");

      result = await HttpUtil.post("/roles",
        { roleName: "roleName2", instanceId: "instanceId1", organizationId: "INSTANCE", description: "desc1" }, {});
      expect(result.roleName).equals("ROLENAME2");
    });
});

async function createSomeRolesInSerial(): Promise<string[]> {
  const roles: any[] = [];

  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName0", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName1", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName2", instanceId: "instance1", organizationId: "INSTANCE" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName3", instanceId: "instance1", organizationId: "INSTANCE" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName4", instanceId: "instance2", organizationId: "INSTANCE" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName5", instanceId: "instance3", organizationId: "INSTANCE" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName6", instanceId: "instance1", organizationId: "organization1" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName7", instanceId: "instance1", organizationId: "organization1" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName8", instanceId: "instance1", organizationId: "organization2" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName9", instanceId: "instance1", organizationId: "organization2" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName10", instanceId: "instance2", organizationId: "organization1" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName11", instanceId: "instance2", organizationId: "organization1" }, {}));

  return roles.map((action) => {
    return action.id;
  });
}

async function addChildrenToParents(ids: string[]) {
  await HttpUtil.put("/roles/roles/parents", { parentRoleIds: [ids[0]], childRoleIds: [ids[1]] }, {});
  await HttpUtil.put("/roles/roles/parents", { parentRoleIds: [ids[0]], childRoleIds: [ids[1]] }, {});
  await HttpUtil.put("/roles/roles/parents", { parentRoleIds: [ids[2]], childRoleIds: [ids[0], ids[3]] }, {});
  await HttpUtil.put("/roles/roles/parents", { parentRoleIds: [ids[6], ids[7]], childRoleIds: [ids[0], ids[2]] }, {});
  await HttpUtil.put("/roles/roles/parents", { parentRoleIds: [ids[6]], childRoleIds: [ids[7]] }, {});
}

async function createSomeRolesInParallel(): Promise<string[]> {
  const roles: any[] = await Promise.all([
    HttpUtil.post("/roles", { "roleName": "roleName0", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName1", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName2", instanceId: "instance1", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName3", instanceId: "instance1", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName4", instanceId: "instance2", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName5", instanceId: "instance2", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName6", instanceId: "instance1", organizationId: "organization1" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName7", instanceId: "instance1", organizationId: "organization1" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName8", instanceId: "instance1", organizationId: "organization2" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName9", instanceId: "instance1", organizationId: "organization2" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName10", instanceId: "instance2", organizationId: "organization1" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName11", instanceId: "instance2", organizationId: "organization1" }, {}),
  ]);

  return roles.map((action) => {
    return action.id;
  });
}

describe("The addChildrenToParents() API adds children", async () => {
  it("throws an error if the either the childRoleIds or the parentRoleIds are not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "childRoleIds may not be null or undefined"`, async () => {
      await HttpUtil.put("/roles/roles/parents", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "childRoleIds may not be empty"`, async () => {
      await HttpUtil.put("/roles/roles/parents", { childRoleIds: [] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentRoleIds may not be null or undefined"`, async () => {
      await HttpUtil.put("/roles/roles/parents", { childRoleIds: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentRoleIds may not be empty"`, async () => {
      await HttpUtil.put("/roles/roles/parents", { childRoleIds: ["asdf"], parentRoleIds: [] }, {});
    });
  });

  it("throws an error if there are any common ids between the childRoleIds and the parentRoleIds", async () => {
    await TestUtils.verifyAsyncError(`401 - "The childRoleIds and parentRoleIds may not have any ids in common. The following ids were found to be in common roleId1"`, async () => {
      await HttpUtil.put("/roles/roles/parents", { childRoleIds: ["roleId1"], parentRoleIds: ["roleId1"] }, {});
    });
  });

  it("throws an error if either the childRoleIds or the parentRoleIds do not exist", async () => {
    const ids: string[] = await createSomeRolesInParallel();

    await TestUtils.verifyAsyncError(`401 - "The following role entities were not found in the database: roleId1"`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[0], ids[1]], childRoleIds: [ids[2], "roleId1"]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The following role entities were not found in the database: roleId1"`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[0], "roleId1"], childRoleIds: [ids[1], ids[2]]
      }, {});
    });
  });

  it("throws an error if either instance or organization roles are added as children to system roles, adds the roles otherwise", async () => {
    const ids: string[] = await createSomeRolesInParallel();

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME6 (${ids[6]}) to role ROLENAME0 (${ids[0]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[0]], childRoleIds: [ids[6]]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME7 (${ids[7]}) to role ROLENAME0 (${ids[0]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[0], ids[6]], childRoleIds: [ids[1], ids[7]]
      }, {});
    });

    await HttpUtil.put("/roles/roles/parents", {
      parentRoleIds: [ids[0]], childRoleIds: [ids[1]]
    }, {});

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME2 (${ids[2]}) to role ROLENAME0 (${ids[0]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[0]], childRoleIds: [ids[2]]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME3 (${ids[3]}) to role ROLENAME0 (${ids[0]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[0], ids[2]], childRoleIds: [ids[1], ids[3]]
      }, {});
    });
  });

  it("throws an error if either an instance role of a different instance or an organization role is added as a child to an instance role, adds the roles otherwise", async () => {
    const ids: string[] = await createSomeRolesInParallel();

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME4 (${ids[4]}) to role ROLENAME2 (${ids[2]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[2]], childRoleIds: [ids[4]]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME7 (${ids[7]}) to role ROLENAME2 (${ids[2]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[2], ids[6]], childRoleIds: [ids[0], ids[7]]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME8 (${ids[8]}) to role ROLENAME4 (${ids[4]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[4]], childRoleIds: [ids[8]]
      }, {});
    });

    await HttpUtil.put("/roles/roles/parents", {
      parentRoleIds: [ids[2]], childRoleIds: [ids[0], ids[3]]
    }, {});
  });

  it("throws an error if either an instance role of a different instance or an organization role of a different instance is added as a child to an organization role, adds the roles otherwise", async () => {
    const ids: string[] = await createSomeRolesInParallel();

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME8 (${ids[8]}) to role ROLENAME6 (${ids[6]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[6]], childRoleIds: [ids[8]]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Not allowed to add role ROLENAME5 (${ids[5]}) to role ROLENAME6 (${ids[6]}). Remember the rules. Organization roles can be added as children only to other roles belonging to the same organizations. Instance roles can be added to any roles that belong to the instance or to organizations belonging to the instance. System roles can be added to any role."`, async () => {
      await HttpUtil.put("/roles/roles/parents", {
        parentRoleIds: [ids[6]], childRoleIds: [ids[5]]
      }, {});
    });

    await HttpUtil.put("/roles/roles/parents", {
      parentRoleIds: [ids[6]], childRoleIds: [ids[0], ids[2], ids[7]]
    }, {});
  });

  it("adds the actions to parents and does not add duplicates", async () => {
    const ids: string[] = await createSomeRolesInSerial();
    await addChildrenToParents(ids);

    const results: any[] = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      { actionIds: [], childRoleIds: [ids[1]], "roleName": "ROLENAME0", "description": "ROLENAME0", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME1", "description": "ROLENAME1", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [ids[0], ids[3]], "roleName": "ROLENAME2", "description": "ROLENAME2", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME3", "description": "ROLENAME3", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME4", "description": "ROLENAME4", instanceId: "instance2", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME5", "description": "ROLENAME5", instanceId: "instance3", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [ids[0], ids[2], ids[7]], "roleName": "ROLENAME6", "description": "ROLENAME6", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [ids[0], ids[2]], "roleName": "ROLENAME7", "description": "ROLENAME7", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME8", "description": "ROLENAME8", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME9", "description": "ROLENAME9", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME10", "description": "ROLENAME10", instanceId: "instance2", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], "roleName": "ROLENAME11", "description": "ROLENAME11", instanceId: "instance2", organizationId: "organization1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  }).timeout(10000);
});

describe("The findAll() API", async () => {
  it("honours the skip, limit and sort options", async () => {
    await createSomeRolesInParallel();
    let results: any[] = await HttpUtil.get("/roles?sort=roleName%3Adesc&skip=2&limit=8", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME7", description: "ROLENAME7", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME6", description: "ROLENAME6", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME5", description: "ROLENAME5", instanceId: "instance2", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME4", description: "ROLENAME4", instanceId: "instance2", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME3", description: "ROLENAME3", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME2", description: "ROLENAME2", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME11", description: "ROLENAME11", instanceId: "instance2", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME10", description: "ROLENAME10", instanceId: "instance2", organizationId: "organization1" },
    ]

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The findById() API", async () => {
  it("finds the action", async () => {
    const ids: string[] = await createSomeRolesInParallel();
    let result: any = await HttpUtil.get(`/roles/${ids[1]}`, {});
    validateIdAndUnderscoreAndRemoveAttribs([result]);

    const expectedResult: any = {
      childRoleIds: [], actionIds: [], roleName: 'ROLENAME1',
      description: 'ROLENAME1', instanceId: 'SYSTEM', organizationId: 'SYSTEM'
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;
  });

  it("return null if the id cannot be found", async () => {
    let result: any = await HttpUtil.get(`/roles/someId`, {});
    expect(result).to.be.null;
  });
});

describe("The findChildRoles() API", async () => {
  it("throws an error if the provided role id does not exist", async () => {
    await TestUtils.verifyAsyncError(`401 - "The following role entities were not found in the database: someId"`, async () => {
      await HttpUtil.get(`/roles/childRoles/someId`, {});
    });
  });

  it("Fetches children of actions and respects the sort, limit and skip attributes", async () => {
    const ids: string[] = await createSomeRolesInParallel();
    await HttpUtil.put("/roles/roles/parents", {
      parentRoleIds: [ids[7]], childRoleIds: [ids[0], ids[1], ids[2], ids[3], ids[6]]
    }, {});

    const results: any[] = await HttpUtil.get(`/roles/childRoles/${ids[7]}?sort=roleName%3Adesc&skip=1&limit=3`, {});
    validateIdAndUnderscoreAndRemoveAttribs(results);
    const expectedResults: any[] = [
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAME3', description: 'ROLENAME3', instanceId: 'instance1', organizationId: 'INSTANCE' },
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAME2', description: 'ROLENAME2', instanceId: 'instance1', organizationId: 'INSTANCE' },
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAME1', description: 'ROLENAME1', instanceId: 'SYSTEM', organizationId: 'SYSTEM' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The findParentRoles() API", async () => {
  it("throws an error if the provided role id does not exist", async () => {
    await TestUtils.verifyAsyncError(`401 - "The following role entities were not found in the database: someId"`, async () => {
      await HttpUtil.get(`/roles/parentRoles/someId`, {});
    });
  });

  it("Fetches children of actions and respects the sort, limit and skip attributes", async () => {
    const ids: string[] = await createSomeRolesInParallel();
    await HttpUtil.put("/roles/roles/parents", {
      parentRoleIds: [ids[1], ids[2], ids[3], ids[6], ids[7], ids[8]], childRoleIds: [ids[0]]
    }, {});

    const results: any[] = await HttpUtil.get(`/roles/parentRoles/${ids[0]}?sort=roleName%3Adesc&skip=1&limit=4`, {});
    validateIdAndUnderscoreAndRemoveAttribs(results);
    const expectedResults: any[] = [
      { childRoleIds: [ids[0]], actionIds: [], roleName: 'ROLENAME7', description: 'ROLENAME7', instanceId: 'instance1', organizationId: 'organization1' },
      { childRoleIds: [ids[0]], actionIds: [], roleName: 'ROLENAME6', description: 'ROLENAME6', instanceId: 'instance1', organizationId: 'organization1' },
      { childRoleIds: [ids[0]], actionIds: [], roleName: 'ROLENAME3', description: 'ROLENAME3', instanceId: 'instance1', organizationId: 'INSTANCE' },
      { childRoleIds: [ids[0]], actionIds: [], roleName: 'ROLENAME2', description: 'ROLENAME2', instanceId: 'instance1', organizationId: 'INSTANCE' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The removeChildrenFromParents() API", async () => {
  it("throws an error if the either the childRoleIds or the parentRoleIds are not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "childRoleIds may not be null or undefined"`, async () => {
      await HttpUtil.delete("/roles/roles/parents", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "childRoleIds may not be empty"`, async () => {
      await HttpUtil.delete("/roles/roles/parents", { childRoleIds: [] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentRoleIds may not be null or undefined"`, async () => {
      await HttpUtil.delete("/roles/roles/parents", { childRoleIds: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentRoleIds may not be empty"`, async () => {
      await HttpUtil.delete("/roles/roles/parents", { childRoleIds: ["asdf"], parentRoleIds: [] }, {});
    });
  });

  it("removes the actions from parents and does not complain if some/all of the provided roles are missing", async () => {
    const ids: string[] = await createSomeRolesInSerial();
    await addChildrenToParents(ids);
    await HttpUtil.delete("/roles/roles/parents",
      { parentRoleIds: [ids[0], ids[2], ids[6], "someId"], childRoleIds: [ids[1], ids[3], ids[0], "someOtherId"] }, {});

    const results: any[] = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME0", description: "ROLENAME0", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME1", description: "ROLENAME1", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME2", description: "ROLENAME2", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME3", description: "ROLENAME3", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME4", description: "ROLENAME4", instanceId: "instance2", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME5", description: "ROLENAME5", instanceId: "instance3", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [ids[2], ids[7]], roleName: "ROLENAME6", description: "ROLENAME6", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [ids[0], ids[2]], roleName: "ROLENAME7", description: "ROLENAME7", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME8", description: "ROLENAME8", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME9", description: "ROLENAME9", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME10", description: "ROLENAME10", instanceId: "instance2", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME11", description: "ROLENAME11", instanceId: "instance2", organizationId: "organization1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The delete() API", async () => {
  it("deletes the role and removes the role from parent roles", async () => {
    const ids: string[] = await createSomeRolesInSerial();
    await addChildrenToParents(ids);

    await HttpUtil.delete(`/roles/${ids[0]}`, {}, {});
    let results: any[] = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME1", description: "ROLENAME1", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [ids[3]], roleName: "ROLENAME2", description: "ROLENAME2", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME3", description: "ROLENAME3", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME4", description: "ROLENAME4", instanceId: "instance2", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME5", description: "ROLENAME5", instanceId: "instance3", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [ids[2], ids[7]], roleName: "ROLENAME6", description: "ROLENAME6", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [ids[2]], roleName: "ROLENAME7", description: "ROLENAME7", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME8", description: "ROLENAME8", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME9", description: "ROLENAME9", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME10", description: "ROLENAME10", instanceId: "instance2", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME11", description: "ROLENAME11", instanceId: "instance2", organizationId: "organization1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });

  it("does nothing if the role does not exist", async () => {
    const ids: string[] = await createSomeRolesInSerial();
    await addChildrenToParents(ids);

    await HttpUtil.delete(`/roles/someId`, {}, {});
    let results: any[] = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      { actionIds: [], childRoleIds: [ids[1]], roleName: "ROLENAME0", description: "ROLENAME0", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME1", description: "ROLENAME1", instanceId: "SYSTEM", organizationId: "SYSTEM" },
      { actionIds: [], childRoleIds: [ids[0], ids[3]], roleName: "ROLENAME2", description: "ROLENAME2", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME3", description: "ROLENAME3", instanceId: "instance1", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME4", description: "ROLENAME4", instanceId: "instance2", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME5", description: "ROLENAME5", instanceId: "instance3", organizationId: "INSTANCE" },
      { actionIds: [], childRoleIds: [ids[0], ids[2], ids[7]], roleName: "ROLENAME6", description: "ROLENAME6", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [ids[0], ids[2]], roleName: "ROLENAME7", description: "ROLENAME7", instanceId: "instance1", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME8", description: "ROLENAME8", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME9", description: "ROLENAME9", instanceId: "instance1", organizationId: "organization2" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME10", description: "ROLENAME10", instanceId: "instance2", organizationId: "organization1" },
      { actionIds: [], childRoleIds: [], roleName: "ROLENAME11", description: "ROLENAME11", instanceId: "instance2", organizationId: "organization1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

async function createTwoRoles() {
  const roles: string[] = [];

  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName1", description: "desc2", instanceId: "instaId1", organizationId: "orgId1" }, {}));
  roles.push(await HttpUtil.post("/roles", { "roleName": "roleName2", instanceId: "instaId1", organizationId: "orgId1" }, {}));

  return roles.map((item: any) => { return item.id });
};

describe("The updateAttributes() API", async () => {
  it("throws an error if the both the description as well as the role name are not provided", async () => {
    await TestUtils.verifyAsyncError(`Either the roleName or the description must be specified`,
      async () => {
        await HttpUtil.put(`/roles/someId`, {}, {});
      });

    await TestUtils.verifyAsyncError(`Either the roleName or the description must be specified`,
      async () => {
        await HttpUtil.put(`/roles/someId`, { roleName: " ", description: " " }, {});
      });
  });

  it("throws an error if the role doesn't exist", async () => {
    await TestUtils.verifyAsyncError(`The following role entities were not found in the database: someId`,
      async () => {
        await HttpUtil.put(`/roles/someId`, { roleName: "roleNameMod1" }, {});
      });
  });

  it("Updates the description and role name of the role and converts the role name to upper case", async () => {
    const ids: string[] = await createTwoRoles();
    await HttpUtil.put(`/roles/${ids[1]}`, { roleName: "roleNameMod1" }, {});

    let results: any[] = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    let expectedResults: any[] = [
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAME1', description: 'desc2', instanceId: "instaId1", organizationId: "orgId1" },
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAMEMOD1', description: 'ROLENAME2', instanceId: "instaId1", organizationId: "orgId1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;

    await HttpUtil.put(`/roles/${ids[1]}`, { description: "descMod1" }, {});
    results = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    expectedResults = [
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAME1', description: 'desc2', instanceId: "instaId1", organizationId: "orgId1" },
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAMEMOD1', description: 'descMod1', instanceId: "instaId1", organizationId: "orgId1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;

    await HttpUtil.put(`/roles/${ids[1]}`, { roleName: "roleNameMod2", description: "descMod2" }, {});
    results = await HttpUtil.get("/roles", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    expectedResults = [
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAME1', description: 'desc2', instanceId: "instaId1", organizationId: "orgId1" },
      { childRoleIds: [], actionIds: [], roleName: 'ROLENAMEMOD2', description: 'descMod2', instanceId: "instaId1", organizationId: "orgId1" }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

async function createSomeMoreRolesInParallel(): Promise<string[]> {
  const roles: any[] = await Promise.all([
    HttpUtil.post("/roles", { "roleName": "roleName00", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName01", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName02", instanceId: "MAB", organizationId: "org1" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName03", instanceId: "MAB", organizationId: "org1" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName04", instanceId: "MAB", organizationId: "org2" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName05", instanceId: "MAB", organizationId: "org2" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName06", instanceId: "AMS", organizationId: "org3" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName07", instanceId: "AMS", organizationId: "org3" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName08", instanceId: "AMS", organizationId: "org3" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName09", instanceId: "AMS", organizationId: "org3" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName10", instanceId: "MAIT", organizationId: "org3" }, {}),
    HttpUtil.post("/roles", { "roleName": "roleName11", instanceId: "MAIT", organizationId: "org3" }, {}),
  ]);

  return roles.map((role) => {
    return role.id;
  });
}

describe("The findByRoleNames() API", async () => {
  it("throws an error if incorrect data is provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "Malformed JSON provided"`, async () => {
      await HttpUtil.get(`/roles/roleNames/invalidJson`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The roleNamesCriteria must be an array"`, async () => {
      await HttpUtil.get(`/roles/roleNames/${JSON.stringify({})}`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The roleNamesCriteria must not be empty"`, async () => {
      await HttpUtil.get(`/roles/roleNames/${JSON.stringify([])}`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "roleName may not be null, undefined or blank"`, async () => {
      await HttpUtil.get(`/roles/roleNames/${JSON.stringify([{ roleName: "asdf", instanceId: "MAB", organizationId: "someOrg" },
      { roleName: " " }])}`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "organizationId may not be null, undefined or blank"`, async () => {
      await HttpUtil.get(`/roles/roleNames/${JSON.stringify([
        { roleName: "asdf", instanceId: "MAB", organizationId: "someOrg" },
        { roleName: "asdf", organizationId: " " }])}`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "instanceId may not be null, undefined or blank"`, async () => {
      await HttpUtil.get(`/roles/roleNames/${JSON.stringify([
        { roleName: "asdf", instanceId: "MAB", organizationId: "someOrg" },
        { roleName: "asdf", organizationId: "orgId", instanceId: " " }])}`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Invalid instanceId asdf provided"`, async () => {
      await HttpUtil.get(`/roles/roleNames/${JSON.stringify([
        { roleName: "roleName00", instanceId: "MAB", organizationId: "someOrg" },
        { roleName: "asdf", organizationId: "orgId", instanceId: "asdf" }])}`, {});
    });
  });

  it("returns ", async () => {
    const roleIds: string[] = await createSomeMoreRolesInParallel();
    const encodedArray = encodeURIComponent(JSON.stringify([
      { roleName: "roleName00", instanceId: "MAB", organizationId: "SYSTEM" },
      { roleName: "roleName01", instanceId: "MAB", organizationId: "org1" },
      { roleName: "roleName02", instanceId: "MAIT", organizationId: "org1" },
      { roleName: "roleName03", instanceId: "MAB", organizationId: "org1" },
      { roleName: "roleName09", instanceId: "AMS", organizationId: "org3" },
      { roleName: "roleName11", instanceId: "MAIT", organizationId: "org3" }
    ]))

    const result: any = await HttpUtil.get(`/roles/roleNames/${encodedArray}`, {});

    validateIdAndUnderscoreAndRemoveAttribs(result.data);

    const expectedResult: any = {
      totalCount: 3,
      data:
        [{
          childRoleIds: [],
          actionIds: [],
          roleName: 'ROLENAME03',
          description: 'ROLENAME03',
          instanceId: 'MAB',
          organizationId: 'org1'
        },
        {
          childRoleIds: [],
          actionIds: [],
          roleName: 'ROLENAME09',
          description: 'ROLENAME09',
          instanceId: 'AMS',
          organizationId: 'org3'
        },
        {
          childRoleIds: [],
          actionIds: [],
          roleName: 'ROLENAME11',
          description: 'ROLENAME11',
          instanceId: 'MAIT',
          organizationId: 'org3'
        }]
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;
  });

});
