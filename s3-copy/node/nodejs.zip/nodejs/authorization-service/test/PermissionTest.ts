import { TestUtils, Service } from '@edunxtv2/service-util';

import { expect } from 'chai';
import 'mocha';
import * as _ from 'lodash';
import { HttpUtil } from './HttpUtil';
import { diff } from 'deep-diff';

beforeEach(async () => {
  await Promise.all([
    HttpUtil.call("DELETE", "/actions/clear/all", {}, {}),
    HttpUtil.call("DELETE", "/usergroups/clearall/groups", {}, {}, Service.USERGROUP_SERVICE),
    HttpUtil.call("DELETE", "/users/clearall", {}, {}, Service.USER_SERVICE)
  ]);
});

process.env.PERMISSIONS_TICKET_PRIVATE_KEY = "-----BEGIN RSA PRIVATE KEY-----\nMIICXAIBAAKBgQCafqrRnb4AWlhyW9cMtFbrVCjLgbWhPMjcHoVDQLjf9GM/xQwE\nkDaorU103bIu5rNnj25f6yyiXhC8VZWqoxodBeTRDliTHzl3Ht9PGuV9ClHBFGc1\nKhH0SQeb7M3SpiGhTrRzLwjr/MqDCBGLGX4SlOXyfBohg8h0H9z3ZiPMdQIDAQAB\nAoGAFmi9Gj6JKr/wCFZt8PfPi77fU/VyhPquH8+FgOXIayOlqcBJJ/hLFVhd3c+y\nYr8v0pupZNxV0w9V2huH5AJYbRd6FUJXqU++8kDEimh6+V5l7NUWlqQDwe+p5Ksu\n56nIILwKU8qA8LIv/rRWpq9tdBRBDfdBpty/C6KA34Yup8ECQQDTjU75KS9WwGC1\namfOnU2yMjDmklz7FNfklIZzUlbQHX99aqlSdNqc0/cicYOUmw44amt1FiYyVTRV\ni7qKqeFpAkEAuvRwPk9WqDQXjPu9NIvIwafMNNlSfCkQBR7kAFxv6g7WI4FFBMrr\nbTG3I13qKbJk4zYmH6PkF+3vAulJKbslLQJAXqdsPWljB/K9ko5Qcg7J88AnRxMX\nzTPPQTP/UFv4Adgg8fGmXwFvyxnACsY1dGlIHI/pEpNddcnPx7LkPSSzeQJBAKWq\nWZQ9hdLDZmMd6EmZ3KoOYRwrv7YaRQHkn7HaN6m2v/byZBCdKAW42kpSvF96n3/f\nyeSbvFGgG/3+b0C1f3kCQECAg0j2YhZJWxSkNSkStuv3a/9PyB39IX0jm45efiOu\nxKwwctoAek/s3o2/f1J+El4KaWG5tOS3egnG5oN2huY=\n-----END RSA PRIVATE KEY-----";
process.env.PERMISSIONS_TICKET_PRIVATE_KEY = "-----BEGIN RSA PUBLIC KEY-----\nMIGJAoGBAJp+qtGdvgBaWHJb1wy0VutUKMuBtaE8yNwehUNAuN/0Yz/FDASQNqit\nTXTdsi7ms2ePbl/rLKJeELxVlaqjGh0F5NEOWJMfOXce308a5X0KUcEUZzUqEfRJ\nB5vszdKmIaFOtHMvCOv8yoMIEYsZfhKU5fJ8GiGDyHQf3PdmI8x1AgMBAAE=\n-----END RSA PUBLIC KEY-----";

function verifyEqual(obj1: any, obj2: any) {
  try {
    expect(_.isEqual(obj1, obj2)).to.be.true;
  } catch (err) {
    console.log("obj1", obj1);
    console.log("obj2", obj2);
    console.log("Diff:", diff(obj1, obj2));
    throw err;
  }
};

function validateIdAndUnderscoreAndRemoveAttribs(results: any[]) {
  for (let result of results) {
    expect(result._id).to.not.be.undefined;
    expect(result.id).to.not.be.undefined;
    delete result._id;
    delete result.id;
  }
}

function convertToIds(entities: any[], fieldName: string, names: string[]) {
  const map: { [s: string]: any } = {};

  for (let entity of entities) {
    map[entity[fieldName]] = entity;
  }

  const ids: string[] = [];
  let index = 0;

  for (let name of names) {
    ids[index] = map[name].id;
    index++;
  }

  return ids;
}

async function createRoles(): Promise<string[]> {
  const roles: any[] = await Promise.all([
    HttpUtil.post("/roles", { roleName: "roleName00", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName01", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName02", instanceId: "instance1", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName03", instanceId: "instance1", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName04", instanceId: "instance2", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName05", instanceId: "instance2", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName06", instanceId: "instance1", organizationId: "organization1" }, {})
  ]);

  return convertToIds(roles, "roleName", ["ROLENAME00", "ROLENAME01", "ROLENAME02",
    "ROLENAME03", "ROLENAME04", "ROLENAME05", "ROLENAME06"]);
}

async function createActions(): Promise<string[]> {
  const actions: any[] = await Promise.all([
    HttpUtil.post("/actions", { actionName: "actionName00" }, {}),
    HttpUtil.post("/actions", { actionName: "actionName01" }, {}),
    HttpUtil.post("/actions", { actionName: "actionName02" }, {}),
    HttpUtil.post("/actions", { actionName: "actionName03" }, {}),
    HttpUtil.post("/actions", { actionName: "actionName04" }, {}),
    HttpUtil.post("/actions", { actionName: "actionName05" }, {}),
    HttpUtil.post("/actions", { actionName: "actionName06" }, {})
  ]);

  return convertToIds(actions, "actionName", ["ACTIONNAME00", "ACTIONNAME01",
    "ACTIONNAME02", "ACTIONNAME03", "ACTIONNAME04", "ACTIONNAME05", "ACTIONNAME06"]);
}

async function createUsers(): Promise<string[]> {
  const users: any[] = await Promise.all([
    HttpUtil.post("/users", { name: "userId00", emailId: "userid00@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE),
    HttpUtil.post("/users", { name: "userId01", emailId: "userid01@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE),
    HttpUtil.post("/users", { name: "userId02", emailId: "userid02@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE),
    HttpUtil.post("/users", { name: "userId03", emailId: "userid03@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE),
    HttpUtil.post("/users", { name: "userId04", emailId: "userid04@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE),
    HttpUtil.post("/users", { name: "userId05", emailId: "userid05@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE),
    HttpUtil.post("/users", { name: "userId06", emailId: "userid06@gmail.com", phone: { countryCode: "91", phoneNumber: "1234567890" }, tenantAndRoles: [{ id: "someOrg", name: "orgOne", roles: [] }] }, {}, Service.USER_SERVICE)
  ]);

  const usersUnpacked: any[] = _.map(users, "user");

  return convertToIds(usersUnpacked, "name", ["userid00", "userid01", "userid02", "userid03",
    "userid04", "userid05", "userid06"]);
}

async function createUsergroups(): Promise<string[]> {
  const userGroups: any[] = await Promise.all([
    HttpUtil.post("/usergroups", { name: "userGroupId00", instanceId: "instance1", organizationId: "organization1" }, {}, Service.USERGROUP_SERVICE),
    HttpUtil.post("/usergroups", { name: "userGroupId01", instanceId: "instance1", organizationId: "organization2" }, {}, Service.USERGROUP_SERVICE),
    HttpUtil.post("/usergroups", { name: "userGroupId02", instanceId: "instance1", organizationId: "organization3" }, {}, Service.USERGROUP_SERVICE),
    HttpUtil.post("/usergroups", { name: "userGroupId03", instanceId: "instance1", organizationId: "organization4" }, {}, Service.USERGROUP_SERVICE),
    HttpUtil.post("/usergroups", { name: "userGroupId04", instanceId: "instance1", organizationId: "organization5" }, {}, Service.USERGROUP_SERVICE),
    HttpUtil.post("/usergroups", { name: "userGroupId05", instanceId: "instance1", organizationId: "organization6" }, {}, Service.USERGROUP_SERVICE),
    HttpUtil.post("/usergroups", { name: "userGroupId06", instanceId: "instance1", organizationId: "organization7" }, {}, Service.USERGROUP_SERVICE)
  ]);

  return convertToIds(userGroups, "name", ["USERGROUPID00", "USERGROUPID01", "USERGROUPID02", "USERGROUPID03", "USERGROUPID04", "USERGROUPID05", "USERGROUPID06"]);
}

async function createPermissions(entities: any): Promise<string[]> {
  const userIds: string[] = entities.userIds;
  const userGroupIds: string[] = entities.userGroupIds;
  const actionIds: string[] = entities.actionIds;
  const roleIds: string[] = entities.roleIds;

  const permissions: any[] = await Promise.all([
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId8", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope2"] }, {})
  ]);

  return _.sortBy(_.map(permissions, "id"), "id");
}

async function createPermissionsForVerification(entities: any): Promise<string[]> {
  const userIds: string[] = entities.userIds;
  const userGroupIds: string[] = entities.userGroupIds;
  const actionIds: string[] = entities.actionIds;
  const roleIds: string[] = entities.roleIds;

  const permissions: any[] = await Promise.all([
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] }, {}),
    HttpUtil.post("/permissions", { instanceId: "MAB", organizationId: "org1", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope2"] }, {})
  ]);

  return _.sortBy(_.map(permissions, "id"), "id");
}

async function createEntities() {
  const ids: string[][] = await Promise.all([
    createUsers(),
    createUsergroups(),
    createActions(),
    createRoles()
  ]);

  return {
    userIds: ids[0],
    userGroupIds: ids[1],
    actionIds: ids[2],
    roleIds: ids[3]
  }
}

describe("The create API", async () => {
  it("throws an error if mandatory attributes have not been provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "instanceId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "organizationId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "principalId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "principalId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: " " }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "isUser may not be null or undefined"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "actionRoleId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf", isUser: true }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "actionRoleId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf", isUser: true, actionRoleId: " " }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "actionRoleId may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf", isUser: true, actionRoleId: " " }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "isRole may not be null or undefined"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf", isUser: true, actionRoleId: "asdf" }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "scopes may not be null or undefined"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf", isUser: true, actionRoleId: "asdf", isRole: false }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "scopes cannot be empty"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "asdf", isUser: true, actionRoleId: "asdf", isRole: false, scopes: [] }, {});
    });
  });

  it("throws an error if any of the provided entities do not exist", async () => {
    const entities: { [s: string]: any } = await createEntities();

    await TestUtils.verifyAsyncError(`401 - "Entity user having id userId1 does not exist"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "userId1", isUser: true, actionRoleId: "asdf", isRole: false, scopes: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Entity userGroup having id userGrpId1 does not exist"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: "userGrpId1", isUser: false, actionRoleId: "asdf", isRole: false, scopes: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Entity userGroup having id ${entities.userIds[0]} does not exist"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: entities.userIds[0], isUser: false, actionRoleId: entities.actionIds[0], isRole: false, scopes: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Entity user having id ${entities.userGroupIds[0]} does not exist"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: entities.userGroupIds[0], isUser: true, actionRoleId: "asdf", isRole: false, scopes: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Entity action having id ${entities.roleIds[0]} does not exist"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: entities.userIds[0], isUser: true, actionRoleId: entities.roleIds[0], isRole: false, scopes: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "Entity role having id ${entities.actionIds[0]} does not exist"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: entities.userIds[0], isUser: true, actionRoleId: entities.actionIds[0], isRole: true, scopes: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "scopes may not be null or undefined"`, async () => {
      await HttpUtil.post("/permissions", { instanceId: "instanceId1", organizationId: "organizationId1", principalId: entities.userGroupIds[0], isUser: false, actionRoleId: entities.actionIds[0], isRole: false }, {});
    });

  });

  it("successfully creates the permission when all necessary data is provided and throws an error if a duplicate permission is created", async () => {
    const entities: { [s: string]: any } = await createEntities();

    let result: any = await HttpUtil.post("/permissions", {
      instanceId: "instanceId1", organizationId: "organizationId1",
      principalId: entities.userIds[0], isUser: true,
      actionRoleId: entities.actionIds[0], isRole: false, scopes: ["scope1"]
    }, {});

    validateIdAndUnderscoreAndRemoveAttribs([result]);

    let expectedResult: any = {
      instanceId: "instanceId1", organizationId: "organizationId1",
      principalId: entities.userIds[0], isUser: true, isRole: false, scopes: ['scope1'],
      actionRoleId: entities.actionIds[0]
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;
  });
});

describe("The findAll API", async () => {
  it("finds all matching permissions and honours the sort options and filters provided", async () => {
    const entities: { [s: string]: any } = await createEntities();
    const permissionIds: string[] = await createPermissions(entities);
    verifyOrderedById(permissionIds);
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const actionIds: string[] = entities.actionIds;
    const roleIds: string[] = entities.roleIds;

    let permissions: any[] = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    let expectedResult = [
      { instanceId: "instanceId1", organizationId: "organizationId8", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;

    permissions = await HttpUtil.get("/permissions?organizationId=organizationId1", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    expectedResult = [
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;
  });
});

describe("The addScopes API", async () => {
  it("adds scopes without adding duplicates", async () => {
    const entities: { [s: string]: any } = await createEntities();
    const permissionIds: string[] = await createPermissions(entities);
    verifyOrderedById(permissionIds);
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const actionIds: string[] = entities.actionIds;
    const roleIds: string[] = entities.roleIds;

    let permissions: any[] = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    const id = permissions[0].id;
    await HttpUtil.put(`/permissions/scopes/${id}`,
      { scopes: ["scope2", "scope3", "scope4"] }, {});
    permissions = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    let expectedResult: any[] = [
      { instanceId: "instanceId1", organizationId: "organizationId8", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope2", "scope3", "scope4"] },
      { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;

    await HttpUtil.put(`/permissions/scopes/${id}`,
      { scopes: ["scope3", "scope4", "scope5"] }, {});
    permissions = await HttpUtil.get("/permissions?sort=organizationId:desc", {});

    expectedResult = [
      { instanceId: "instanceId1", organizationId: "organizationId8", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope2", "scope3", "scope4", "scope5"] },
      { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    expect(_.isEqual(permissions, expectedResult)).to.be.true;
  });
});

describe("The removeScopes API", async () => {
  it("removes scopes for the provided IDs", async () => {
    const entities: { [s: string]: any } = await createEntities();
    const permissionIds: string[] = await createPermissions(entities);
    verifyOrderedById(permissionIds);
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const actionIds: string[] = entities.actionIds;
    const roleIds: string[] = entities.roleIds;

    let permissions: any[] = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    const id1 = permissions[0].id;
    const id2 = permissions[1].id;
    await HttpUtil.put(`/permissions/scopes/${id1}`,
      { scopes: ["scope2", "scope3", "scope4", "scope5"] }, {});
    await HttpUtil.put(`/permissions/scopes/${id2}`,
      { scopes: ["scope2", "scope3", "scope4", "scope5"] }, {});
    await HttpUtil.delete(`/permissions/scopes/${id1}`,
      { scopes: ["scope2", "scope4", "scope5"] }, {});
    await HttpUtil.delete(`/permissions/scopes/${id2}`,
      { scopes: ["scope1", "scope2", "scope3", "scope4", "scope5", "scope6"] }, {});
    permissions = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    let expectedResult: any[] = [
      { instanceId: "instanceId1", organizationId: "organizationId8", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope3"] },
      { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: [] },
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;
  });
});

describe("The deleteEntriesForUser API", async () => {
  it("deletes the permission entries for the provided user", async () => {
    const entities: { [s: string]: any } = await createEntities();
    const permissionIds: string[] = await createPermissions(entities);
    verifyOrderedById(permissionIds);
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const roleIds: string[] = entities.roleIds;

    await HttpUtil.delete(`/permissions/user/${userIds[0]}`, {}, {});

    let permissions: any[] = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    let expectedResult: any[] = [
      { instanceId: "instanceId1", organizationId: "organizationId8", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;
  });
});

describe("The deleteEntriesForUsergroup API", async () => {
  it("deletes the permission entries for the provided user", async () => {
    const entities: { [s: string]: any } = await createEntities();
    const permissionIds: string[] = await createPermissions(entities);
    verifyOrderedById(permissionIds);
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const roleIds: string[] = entities.roleIds;
    const actionIds: string[] = entities.actionIds;

    await HttpUtil.delete(`/permissions/usergroup/${userGroupIds[0]}`, {}, {});

    let permissions: any[] = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    let expectedResult = [
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;
  });
});

describe("The delete API", async () => {
  it("deletes the permission entry", async () => {
    const entities: { [s: string]: any } = await createEntities();
    const permissionIds: string[] = await createPermissions(entities);
    verifyOrderedById(permissionIds);
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const roleIds: string[] = entities.roleIds;
    const actionIds: string[] = entities.actionIds;
    let permissions: any[] = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    const id1: string = permissions[0].id;

    await HttpUtil.delete(`/permissions/${id1}`, {}, {});

    permissions = await HttpUtil.get("/permissions?sort=organizationId:desc", {});
    validateIdAndUnderscoreAndRemoveAttribs(permissions);

    let expectedResult = [
      { instanceId: "instanceId1", organizationId: "organizationId7", principalId: userGroupIds[0], isUser: false, actionRoleId: roleIds[1], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId6", principalId: userIds[1], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId5", principalId: userIds[0], isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId4", principalId: userIds[0], isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId3", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope2"] },
      { instanceId: "instanceId1", organizationId: "organizationId2", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] },
      { instanceId: "instanceId1", organizationId: "organizationId1", principalId: userIds[0], isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1"] }
    ];

    expect(_.isEqual(permissions, expectedResult)).to.be.true;
  });
});

describe("The areAllowed API", async () => {
  async function verifyPermissionsQueryValidation(permissionsQuery: any, errMsg: string) {
    await TestUtils.verifyAsyncError(errMsg, async () => {
      await HttpUtil.get(`/permissions/allowed/someid/${encodeURIComponent(JSON.stringify(permissionsQuery))}`, {});
    });
  }

  it("throws an error if the permissions query is not in the right format or has missing data", async () => {
    await TestUtils.verifyAsyncError(`401 - "Invalid JSON string provided for areAllowedParams`, async () => {
      await HttpUtil.get(`/permissions/allowed/someid/invalidJson`, {});
    });

    await verifyPermissionsQueryValidation(null, `401 - "areAllowedParams may not be null or undefined"`);
    await verifyPermissionsQueryValidation(undefined, `401 - "Invalid JSON string provided for areAllowedParams"`);
    await verifyPermissionsQueryValidation({}, `401 - "areAllowedParams.instanceId may not be null, undefined or blank"`);
    await verifyPermissionsQueryValidation({ instanceId: "MAB" }, `401 - "areAllowedParams.organizationId may not be null, undefined or blank"`);
    await verifyPermissionsQueryValidation({ instanceId: "MAB", organizationId: "orgId1" },
      `401 - "permissionsQueries may not be null or undefined"`);
    await verifyPermissionsQueryValidation({ instanceId: "MAB", organizationId: "orgId", permissionsQueries: {} },
      `401 - "permissionsQueries is not an array"`);
    await verifyPermissionsQueryValidation({ instanceId: "MAB", organizationId: "orgId", permissionsQueries: [] },
      `401 - "Array permissionsQueries is empty"`);
    await verifyPermissionsQueryValidation({ instanceId: "MAB", organizationId: "orgId", permissionsQueries: [null] },
      `401 - "permissionsQuery may not be null or undefined"`);
    await verifyPermissionsQueryValidation({
      instanceId: "MAB", organizationId: "orgId", permissionsQueries:
        [{ action: "action1", scope: "scope1" }, { action: " " }]
    },
      `401 - "permissionsQuery.action may not be null, undefined or blank"`);
    await verifyPermissionsQueryValidation({
      instanceId: "MAB", organizationId: "orgId", permissionsQueries:
        [{ action: "action1", scope: "scope1" }, { action: "action1", scope: " " }]
    },
      `401 - "permissionsQuery.action may not be null, undefined or blank"`);
  });

  async function setupForPermissionsCheck() {
    const entities: { [s: string]: any } = await createEntities();
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const actionIds: string[] = entities.actionIds;
    const roleIds: string[] = entities.roleIds;

    await Promise.all([
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userIds[0],
        isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1", "scope2"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userIds[0],
        isUser: true, actionRoleId: actionIds[1], isRole: false, scopes: ["scope2", "scope3"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userIds[0],
        isUser: true, actionRoleId: actionIds[0], isRole: false, scopes: ["scope1/*/5"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userIds[0],
        isUser: true, actionRoleId: actionIds[2], isRole: false, scopes: ["scope4", "scope5"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userGroupIds[0],
        isUser: false, actionRoleId: actionIds[0], isRole: false, scopes: ["scope6"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userGroupIds[3],
        isUser: false, actionRoleId: actionIds[0], isRole: false, scopes: ["scope7"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userGroupIds[4],
        isUser: false, actionRoleId: actionIds[0], isRole: false, scopes: ["scope8"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userGroupIds[5],
        isUser: false, actionRoleId: actionIds[0], isRole: false, scopes: ["scope9"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userIds[0],
        isUser: true, actionRoleId: roleIds[0], isRole: true, scopes: ["scope10"]
      }, {}),
      HttpUtil.post("/permissions", {
        instanceId: "MAB", organizationId: "org1", principalId: userIds[0],
        isUser: true, actionRoleId: roleIds[2], isRole: true, scopes: ["scope11"]
      }, {})
    ]);

    return entities;
  };

  it(`does the following
           - checks for permissions directly assigned to the user
           - checks for permissions directly assigned to it's parent user groups (direct and indirect)
           - ignores any actions that don't exist
           - is able to perform wild card matches on the scope`, async () => {
    const entities: { [s: string]: any } = await setupForPermissionsCheck();
    const userIds: string[] = entities.userIds;
    const userGroupIds: string[] = entities.userGroupIds;
    const actionIds: string[] = entities.actionIds;

    let permissionsQueryString = encodeURIComponent(JSON.stringify({
      instanceId: "MAB", organizationId: "org1",
      permissionsQueries: [
        { actionName: "actionName00", scope: "scope1" },
        { actionName: "actionName00", scope: "scope2" },
        { actionName: "actionName00", scope: "scope1/abc/5" },
        { actionName: "actionName00", scope: "scope1/abc/6" },
        { actionName: "actionName00", scope: "scope6" },
        { actionName: "actionName00", scope: "scope7" },
        { actionName: "actionName01", scope: "scope2" },
        { actionName: "actionName01", scope: "scope4" },
        { actionName: "actionName00", scope: "scope8" },
        { actionName: "actionName00", scope: "scope9" },
        { actionName: "actionNameNonExistent", scope: "scope4" }
      ]
    }));

    let result = await HttpUtil.get(`/permissions/allowed/${userIds[0]}/${permissionsQueryString}`, {});

    let expectedResult: any = {
      instanceId: "MAB", organizationId: "org1",
      permissionsQueries: [
        { actionName: 'ACTIONNAME00', scope: 'scope1', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope2', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope1/abc/5', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope1/abc/6', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope6', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope7', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAME01', scope: 'scope2', actionId: actionIds[1], allowed: true },
        { actionName: 'ACTIONNAME01', scope: 'scope4', actionId: actionIds[1], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope8', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope9', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAMENONEXISTENT', scope: 'scope4', allowed: false }
      ]
    };

    verifyEqual(result, expectedResult);

    await HttpUtil.post(`/usergroups/user`, {
      userIds: [userIds[0], userIds[1]], parentGroupIds: [userGroupIds[0], userGroupIds[1]]
    }, {}, Service.USERGROUP_SERVICE);

    await HttpUtil.put(`/usergroups/parents`, {
      childGroupIds: [userGroupIds[0]], parentGroupIds: [userGroupIds[3], userGroupIds[2]]
    }, {}, Service.USERGROUP_SERVICE);

    await HttpUtil.put(`/usergroups/parents`, {
      childGroupIds: [userGroupIds[3]], parentGroupIds: [userGroupIds[4]]
    }, {}, Service.USERGROUP_SERVICE);

    result = await HttpUtil.get(`/permissions/allowed/${userIds[0]}/${permissionsQueryString}`, {});

    expectedResult = {
      instanceId: "MAB", organizationId: "org1",
      permissionsQueries: [
        { actionName: 'ACTIONNAME00', scope: 'scope1', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope2', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope1/abc/5', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope1/abc/6', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope6', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope7', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME01', scope: 'scope2', actionId: actionIds[1], allowed: true },
        { actionName: 'ACTIONNAME01', scope: 'scope4', actionId: actionIds[1], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope8', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope9', actionId: actionIds[0], allowed: false },
        { actionName: 'ACTIONNAMENONEXISTENT', scope: 'scope4', allowed: false }
      ]
    };

    verifyEqual(result, expectedResult);
  });

  it(`checks for
      - actions that are children of an assigned action
      - actions assigned to roles
      - actions assigned to roles that are children of assigned roles`, async () => {
    const entities: { [s: string]: any } = await setupForPermissionsCheck();
    const userIds: string[] = entities.userIds;
    const actionIds: string[] = entities.actionIds;
    const roleIds: string[] = entities.roleIds;

    await HttpUtil.put(`/actions/actions/parents`, {
      childActionIds: [actionIds[2]], parentActionIds: [actionIds[0]]
    }, {});

    await HttpUtil.put(`/actions/actions/parents`, {
      childActionIds: [actionIds[3]], parentActionIds: [actionIds[2]]
    }, {});

    await HttpUtil.put(`/roleactions/roles/actions`, {
      roleIds: [roleIds[0]], actionIds: [actionIds[0]]
    }, {});

    await HttpUtil.put(`/roles/roles/parents`, {
      childRoleIds: [roleIds[0]], parentRoleIds: [roleIds[1]]
    }, {});

    await HttpUtil.put(`/roles/roles/parents`, {
      childRoleIds: [roleIds[1]], parentRoleIds: [roleIds[2]]
    }, {});

    let permissionsQueryString = encodeURIComponent(JSON.stringify({
      instanceId: "MAB", organizationId: "org1",
      permissionsQueries: [
        { actionName: "actionName00", scope: "scope1" },
        { actionName: "actionName00", scope: "scope2" },
        { actionName: "actionName02", scope: "scope2" },
        { actionName: "actionName03", scope: "scope2" },
        { actionName: "actionName04", scope: "scope2" },
        { actionName: "actionName00", scope: "scope10" },
        { actionName: "actionName03", scope: "scope10" },
        { actionName: "actionName00", scope: "scope11" }
      ]
    }));

    let result = await HttpUtil.get(`/permissions/allowed/${userIds[0]}/${permissionsQueryString}`, {});

    let expectedResult: any = {
      instanceId: "MAB", organizationId: "org1",
      permissionsQueries: [
        { actionName: 'ACTIONNAME00', scope: 'scope1', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope2', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME02', scope: 'scope2', actionId: actionIds[2], allowed: true },
        { actionName: 'ACTIONNAME03', scope: 'scope2', actionId: actionIds[3], allowed: true },
        { actionName: 'ACTIONNAME04', scope: 'scope2', actionId: actionIds[4], allowed: false },
        { actionName: 'ACTIONNAME00', scope: 'scope10', actionId: actionIds[0], allowed: true },
        { actionName: 'ACTIONNAME03', scope: 'scope10', actionId: actionIds[3], allowed: true },
        { actionName: 'ACTIONNAME00', scope: 'scope11', actionId: actionIds[0], allowed: true },
      ]
    };

    verifyEqual(result, expectedResult);
  });
});

function permissionsHashGenerator(permission: any) {
  const scopes: string = permission.scopes.join(",");

  return `${permission.instanceId}_${permission.organizationId}_${permission.principalId}_${permission.isUser}_${permission.actionRoleId}_${permission.isRole}_scopes`;
}

function compareArraysRegardlessOfOrdering(permissions1: any[],
  permissions2: any[], hashGenerator: Function = permissionsHashGenerator) {
  const map1 = generateHashCodeMap(permissions1, hashGenerator);
  const map2 = generateHashCodeMap(permissions2, hashGenerator);

  return _.isEqual(map1, map2);
}

function generateHashCodeMap(objs: any[], hashGenerator: Function) {
  const hashMap: { [s: string]: number } = {};

  for (let obj of objs) {
    const objHash = hashGenerator(obj);
    let count: number = obj[objHash];

    if (!count) {
      hashMap[objHash] = 1;
    } else {
      hashMap[objHash] = count + 1;
    }
  }

  return hashMap;
}

function verifyOrderedById(permissionIds: any[]) {
  const sortedIds: string[] = _.sortBy(permissionIds, "id");
  expect(_.isEqual(permissionIds, sortedIds)).to.be.true;
}
