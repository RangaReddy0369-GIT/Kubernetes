import { expect } from 'chai';
import 'mocha';
import * as _ from 'lodash';
import * as rp from 'request-promise';
import { TestUtils } from '@edunxtv2/service-util';
import { HttpUtil } from './HttpUtil';

beforeEach(async () => {
  await rp({
    method: "DELETE",
    uri: "http://localhost:3011/authorizationservice/actions/clear/all"
  });
});

function validateIdAndUnderscoreAndRemoveAttribs(results: any[]) {
  for (let result of results) {
    expect(result._id).to.not.be.undefined;
    expect(result.id).to.not.be.undefined;
    delete result._id;
    delete result.id;
  }
}

async function addActionsToRoles(ids: string[]) {
  await HttpUtil.put("/roleactions/roles/actions", { parentRoleIds: [ids[0]], childRoleIds: [ids[1]] }, {});
  await HttpUtil.put("/roleactions/roles/actions", { parentRoleIds: [ids[0]], childRoleIds: [ids[1]] }, {});
  await HttpUtil.put("/roleactions/roles/actions", { parentRoleIds: [ids[2]], childRoleIds: [ids[0], ids[3]] }, {});
  await HttpUtil.put("/roleactions/roles/actions", { parentRoleIds: [ids[6], ids[7]], childRoleIds: [ids[0], ids[2]] }, {});
  await HttpUtil.put("/roleactions/roles/actions", { parentRoleIds: [ids[6]], childRoleIds: [ids[7]] }, {});
}

const actionNames: string[] = ["ACTIONNAME00", "ACTIONNAME01", "ACTIONNAME02", "ACTIONNAME03", "ACTIONNAME04", "ACTIONNAME05"];

async function createSomeActions(): Promise<string[]> {
  const actions: any[] = await Promise.all([
    HttpUtil.post("/actions", { "actionName": "actionName00" }, {}),
    HttpUtil.post("/actions", { "actionName": "actionName01" }, {}),
    HttpUtil.post("/actions", { "actionName": "actionName02" }, {}),
    HttpUtil.post("/actions", { "actionName": "actionName03" }, {}),
    HttpUtil.post("/actions", { "actionName": "actionName04" }, {}),
    HttpUtil.post("/actions", { "actionName": "actionName05" }, {})
  ]);

  const actionMap: { [s: string]: any } = {};

  for (let action of actions) {
    actionMap[action.actionName] = action;
  }

  const ids: string[] = [];
  let index = 0;

  for (let actionName of actionNames) {
    ids[index] = actionMap[actionName].id;
    index++;
  }

  return ids;
}

const roleNames: string[] = ["ROLENAME00", "ROLENAME01", "ROLENAME02", "ROLENAME03", "ROLENAME04", "ROLENAME05", "ROLENAME06"];

async function createSomeRoles(): Promise<string[]> {
  const roles: any[] = await Promise.all([
    HttpUtil.post("/roles", { id: "asdf", roleName: "roleName00", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { id: "qwer", roleName: "roleName01", instanceId: "SYSTEM", organizationId: "SYSTEM" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName02", instanceId: "instance1", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName03", instanceId: "instance1", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName04", instanceId: "instance2", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName05", instanceId: "instance2", organizationId: "INSTANCE" }, {}),
    HttpUtil.post("/roles", { roleName: "roleName06", instanceId: "instance1", organizationId: "organization1" }, {})
  ]);

  const roleMap: { [s: string]: any } = {};

  for (let role of roles) {
    roleMap[role.roleName] = role;
  }

  const ids: string[] = [];
  let index = 0;

  for (let roleName of roleNames) {
    ids[index] = roleMap[roleName].id;
    index++;
  }

  return ids;
}

describe("The addActionsToRoles() API adds children", async () => {
  it("throws an error if the either the actionIds or the roleIds are not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "actionIds may not be null or undefined"`, async () => {
      await HttpUtil.put("/roleactions/roles/actions", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "actionIds may not be empty"`, async () => {
      await HttpUtil.put("/roleactions/roles/actions", { actionIds: [] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "roleIds may not be null or undefined"`, async () => {
      await HttpUtil.put("/roleactions/roles/actions", { actionIds: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "roleIds may not be empty"`, async () => {
      await HttpUtil.put("/roleactions/roles/actions", { actionIds: ["asdf"], roleIds: [] }, {});
    });
  });

  it("throws an error if either the roleIds or the actionIds do not exist", async () => {
    const roleIds: string[] = await createSomeRoles();
    const actionIds: string[] = await createSomeActions();

    await TestUtils.verifyAsyncError(`401 - "The following action entities were not found in the database: someActionId1, someActionId2"`, async () => {
      await HttpUtil.put("/roleactions/roles/actions",
        { actionIds: [actionIds[0], "someActionId1", "someActionId2"], roleIds: [roleIds[0], "someRoleId"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The following role entities were not found in the database: someRoleId1, someRoleId2"`, async () => {
      await HttpUtil.put("/roleactions/roles/actions",
        { actionIds: [actionIds[0], actionIds[0]], roleIds: [roleIds[0], "someRoleId1", "someRoleId2"] }, {});
    });
  });

  it("adds the actions to parents and does not add duplicates", async () => {
    const roleIds: string[] = await createSomeRoles();
    const actionIds: string[] = await createSomeActions();

    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[0], roleIds[2], roleIds[4]], actionIds: [actionIds[0], actionIds[1], actionIds[2]] }, {});
    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[2], roleIds[4], roleIds[5]], actionIds: [actionIds[1], actionIds[2], actionIds[3]] }, {});

    const results: any[] = await HttpUtil.get("/roles?sort=roleName", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      {
        roleName: "ROLENAME00", description: "ROLENAME00", instanceId: "SYSTEM", organizationId: "SYSTEM",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[1], actionIds[2]]
      },
      { roleName: "ROLENAME01", description: "ROLENAME01", instanceId: "SYSTEM", organizationId: "SYSTEM", childRoleIds: [], actionIds: [] },
      {
        roleName: "ROLENAME02", description: "ROLENAME02", instanceId: "instance1", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[1], actionIds[2], actionIds[3]]
      },
      { roleName: "ROLENAME03", description: "ROLENAME03", instanceId: "instance1", organizationId: "INSTANCE", childRoleIds: [], actionIds: [] },
      {
        roleName: "ROLENAME04", description: "ROLENAME04", instanceId: "instance2", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[1], actionIds[2], actionIds[3]]
      },
      {
        roleName: "ROLENAME05", description: "ROLENAME05", instanceId: "instance2", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[1], actionIds[2], actionIds[3]]
      },
      { roleName: "ROLENAME06", description: "ROLENAME06", instanceId: "instance1", organizationId: "organization1", childRoleIds: [], actionIds: [] }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The findChildActions() API", async () => {
  it("throws an error if the provided role id does not exist", async () => {
    await TestUtils.verifyAsyncError(`401 - "The following role entities were not found in the database: someId"`, async () => {
      await HttpUtil.get(`/roleactions/childActions/someId`, {});
    });
  });

  it("Fetches children of actions and respects the sort, limit and skip attributes", async () => {
    const roleIds: string[] = await createSomeRoles();
    const actionIds: string[] = await createSomeActions();

    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[0], roleIds[2], roleIds[4]], actionIds: [actionIds[0], actionIds[1], actionIds[2]] }, {});
    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[2], roleIds[4], roleIds[5]], actionIds: [actionIds[1], actionIds[2], actionIds[3], actionIds[4]] }, {});

    const results: any[] = await HttpUtil.get(`/roleactions/childActions/${roleIds[2]}?sort=actionName&skip=1&limit=3`, {});
    validateIdAndUnderscoreAndRemoveAttribs(results);
    
    const expectedResults: any[] = [
      { actionName: "ACTIONNAME01", description: "ACTIONNAME01", childActionIds: [] },
      { actionName: "ACTIONNAME02", description: "ACTIONNAME02", childActionIds: [] },
      { actionName: "ACTIONNAME03", description: "ACTIONNAME03", childActionIds: [] }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The findParentActions() API", async () => {
  it("throws an error if the provided role id does not exist", async () => {
    await TestUtils.verifyAsyncError(`401 - "The following action entities were not found in the database: someId"`, async () => {
      await HttpUtil.get(`/roleactions/parentRoles/someId`, {});
    });
  });

  it("Fetches children of actions and respects the sort, limit and skip attributes", async () => {
    const roleIds: string[] = await createSomeRoles();
    const actionIds: string[] = await createSomeActions();

    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[0], roleIds[2], roleIds[4]], actionIds: [actionIds[0], actionIds[1], actionIds[2]] }, {});
    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[2], roleIds[3], roleIds[4], roleIds[5]], actionIds: [actionIds[1], actionIds[2], actionIds[3], actionIds[4]] }, {});

    const results: any[] = await HttpUtil.get(`/roleactions/parentRoles/${actionIds[2]}?sort=roleName&skip=1&limit=3`, {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      {
        roleName: "ROLENAME02", description: "ROLENAME02", instanceId: "instance1", organizationId: "INSTANCE",
        actionIds: [actionIds[0], actionIds[1], actionIds[2], actionIds[3], actionIds[4]], childRoleIds: []
      },
      {
        roleName: "ROLENAME03", description: "ROLENAME03", instanceId: "instance1", organizationId: "INSTANCE",
        actionIds: [actionIds[1], actionIds[2], actionIds[3], actionIds[4]], childRoleIds: []
      },
      {
        roleName: "ROLENAME04", description: "ROLENAME04", instanceId: "instance2", organizationId: "INSTANCE",
        actionIds: [actionIds[0], actionIds[1], actionIds[2], actionIds[3], actionIds[4]], childRoleIds: []
      }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The removeActionsFromRoles() API", async () => {
  it("throws an error if the either the childRoleIds or the actionIds are not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "actionIds may not be null or undefined"`, async () => {
      await HttpUtil.delete("/roleactions/roles/actions", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "actionIds may not be empty"`, async () => {
      await HttpUtil.delete("/roleactions/roles/actions", { actionIds: [] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "roleIds may not be null or undefined"`, async () => {
      await HttpUtil.delete("/roleactions/roles/actions", { actionIds: ["asf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "roleIds may not be empty"`, async () => {
      await HttpUtil.delete("/roleactions/roles/actions", { actionIds: ["asdf"], roleIds: [] }, {});
    });
  });

  it("removes the actions from parents and does not complain if some/all of the provided roles and actions are missing", async () => {
    const roleIds: string[] = await createSomeRoles();
    const actionIds: string[] = await createSomeActions();

    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[0], roleIds[2], roleIds[4]], actionIds: [actionIds[0], actionIds[1], actionIds[2]] }, {});
    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[2], roleIds[4], roleIds[5]], actionIds: [actionIds[1], actionIds[2], actionIds[3]] }, {});

    await HttpUtil.delete("/roleactions/roles/actions",
      { roleIds: [roleIds[0], roleIds[2], roleIds[5], "someRoleId"], actionIds: [actionIds[0], actionIds[1], actionIds[3], "someActionId"] }, {});

    const results: any[] = await HttpUtil.get("/roles?sort=roleName", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      {
        roleName: "ROLENAME00", description: "ROLENAME00", instanceId: "SYSTEM", organizationId: "SYSTEM",
        childRoleIds: [], actionIds: [actionIds[2]]
      },
      {
        roleName: "ROLENAME01", description: "ROLENAME01", instanceId: "SYSTEM", organizationId: "SYSTEM",
        childRoleIds: [], actionIds: []
      },
      {
        roleName: "ROLENAME02", description: "ROLENAME02", instanceId: "instance1", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[2]]
      },
      {
        roleName: "ROLENAME03", description: "ROLENAME03", instanceId: "instance1", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: []
      },
      {
        roleName: "ROLENAME04", description: "ROLENAME04", instanceId: "instance2", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[1], actionIds[2], actionIds[3]]
      },
      {
        roleName: "ROLENAME05", description: "ROLENAME05", instanceId: "instance2", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[2]]
      },
      {
        roleName: "ROLENAME06", description: "ROLENAME06", instanceId: "instance1", organizationId: "organization1",
        childRoleIds: [], actionIds: []
      }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The deleteAction() API", async () => {
  it("deletes the action (covered in ActionTest) and removes the action from parent roles", async () => {
    const roleIds: string[] = await createSomeRoles();
    const actionIds: string[] = await createSomeActions();

    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[0], roleIds[2], roleIds[4]], actionIds: [actionIds[0], actionIds[1], actionIds[2]] }, {});
    await HttpUtil.put("/roleactions/roles/actions",
      { roleIds: [roleIds[2], roleIds[4], roleIds[5]], actionIds: [actionIds[1], actionIds[2], actionIds[3]] }, {});

    await HttpUtil.delete(`/actions/${actionIds[1]}`, {}, {});

    const results = await HttpUtil.get("/roles?sort=roleName", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      {
        roleName: "ROLENAME00", description: "ROLENAME00", instanceId: "SYSTEM", organizationId: "SYSTEM",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[2]]
      },
      { roleName: "ROLENAME01", description: "ROLENAME01", instanceId: "SYSTEM", organizationId: "SYSTEM", childRoleIds: [], actionIds: [] },
      {
        roleName: "ROLENAME02", description: "ROLENAME02", instanceId: "instance1", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[2], actionIds[3]]
      },
      { roleName: "ROLENAME03", description: "ROLENAME03", instanceId: "instance1", organizationId: "INSTANCE", childRoleIds: [], actionIds: [] },
      {
        roleName: "ROLENAME04", description: "ROLENAME04", instanceId: "instance2", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[0], actionIds[2], actionIds[3]]
      },
      {
        roleName: "ROLENAME05", description: "ROLENAME05", instanceId: "instance2", organizationId: "INSTANCE",
        childRoleIds: [], actionIds: [actionIds[2], actionIds[3]]
      },
      { roleName: "ROLENAME06", description: "ROLENAME06", instanceId: "instance1", organizationId: "organization1", childRoleIds: [], actionIds: [] }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});
