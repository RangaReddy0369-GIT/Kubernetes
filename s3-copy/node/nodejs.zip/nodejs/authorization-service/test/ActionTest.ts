import { expect } from 'chai';
import 'mocha';
import * as _ from 'lodash';
import * as rp from 'request-promise';
import { TestUtils } from '@edunxtv2/service-util';
import { HttpUtil } from './HttpUtil';

beforeEach(async () => {
  await rp({
    method: "DELETE",
    uri: "http://localhost:3011/authorizationservice/actions/clear/all"
  });
});

function validateIdAndUnderscoreAndRemoveAttribs(results: any[]) {
  for (let result of results) {
    expect(result._id).to.not.be.undefined;
    expect(result.id).to.not.be.undefined;
    delete result._id;
    delete result.id;
  }
}

describe("The create API", async () => {
  it("throws an error if the actionName is not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "actionName may not be null, undefined or blank"`, async () => {
      await HttpUtil.post("/actions", {}, {});
    });
  });

  it("successfully creates the action when all necessary data is provided", async () => {
    //checking if it populates the default description
    let result: any = await HttpUtil.post("/actions", { "actionName": "actionName1" }, {});
    validateIdAndUnderscoreAndRemoveAttribs([result]);

    let expectedResult: any = {
      childActionIds: [],
      actionName: 'ACTIONNAME1',
      description: 'ACTIONNAME1'
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;

    //checking if it honours the description and system values provided
    result = await HttpUtil.post("/actions",
      { "actionName": "ACTION_1", "description": "desc1" }, {});
    validateIdAndUnderscoreAndRemoveAttribs([result]);

    expectedResult = {
      childActionIds: [],
      actionName: 'ACTION_1',
      description: 'desc1'
    };

    expect(_.isEqual(result, expectedResult)).to.be.true;
  });

  it("throws an error if one tries to create an action with a name that already exists", async () => {
    await HttpUtil.post("/actions", { "actionName": "action_Name1" }, {});

    await TestUtils.verifyAsyncError(`401 - "Entity action with id ACTION_NAME1 already exists"`, async () => {
      await HttpUtil.post("/actions", { "actionName": "action_Name1" }, {});
    });
  });
});


describe("The findAll() API", async () => {
  beforeEach(async () => {
    //Calling them in sequence so that these are entered in the following order in the db
    await HttpUtil.post("/actions", { "actionName": "actionName1", description: "desc1" }, {});
    await HttpUtil.post("/actions", { "actionName": "actionName2", description: "desc1" }, {});
    await HttpUtil.post("/actions", { "actionName": "actionName3", description: "desc2" }, {});
    await HttpUtil.post("/actions", { "actionName": "actionName4", description: "desc1" }, {});
    await HttpUtil.post("/actions", { "actionName": "actionName5" }, {});
    await HttpUtil.post("/actions", { "actionName": "actionName6" }, {});
  });

  it("honours the skip, limit and sort options", async () => {
    let results: any[] = await HttpUtil.get("/actions?sort=actionName%3Adesc", {});
    expect(_.isEqual(_.map(results, "actionName"),
      ["ACTIONNAME6", "ACTIONNAME5", "ACTIONNAME4", "ACTIONNAME3", "ACTIONNAME2", "ACTIONNAME1"])).to.be.true;

    results = await HttpUtil.get("/actions?limit=3", {});
    expect(_.isEqual(_.map(results, "actionName"),
      ["ACTIONNAME1", "ACTIONNAME2", "ACTIONNAME3"])).to.be.true;

    results = await HttpUtil.get("/actions?limit=3&sort=actionName%3Adesc", {});
    expect(_.isEqual(_.map(results, "actionName"),
      ["ACTIONNAME6", "ACTIONNAME5", "ACTIONNAME4"])).to.be.true;

    results = await HttpUtil.get("/actions?description=desc1&sort=actionName%3Adesc", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    let expectedResult: any[] = [
      { childActionIds: [], actionName: 'ACTIONNAME4', description: 'desc1' },
      { childActionIds: [], actionName: 'ACTIONNAME2', description: 'desc1' },
      { childActionIds: [], actionName: 'ACTIONNAME1', description: 'desc1' }
    ];

    expect(_.isEqual(results, expectedResult)).to.be.true;

    results = await HttpUtil.get("/actions?description=desc1&actionName=ACTIONNAME1", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    expectedResult = [
      { childActionIds: [], actionName: 'ACTIONNAME1', description: 'desc1' }
    ];

    expect(_.isEqual(results, expectedResult)).to.be.true;
  });
});

describe("The findById() API", async () => {
  it("finds the action", async () => {
    const results: any[] = await Promise.all([
      HttpUtil.post("/actions", { "actionName": "actionName1" }, {}),
      HttpUtil.post("/actions", { "actionName": "actionName2" }, {}),
      HttpUtil.post("/actions", { "actionName": "actionName3" }, {}),
      HttpUtil.post("/actions", { "actionName": "actionName4" }, {}),
      HttpUtil.post("/actions", { "actionName": "actionName5" }, {}),
      HttpUtil.post("/actions", { "actionName": "actionName6" }, {})
    ]);

    const result3: any = results[2];
    let result: any = await HttpUtil.get(`/actions/${result3.id}`, {});
    expect(result._id).to.not.be.undefined;
    delete result._id;

    const expectedResult: any = {
      childActionIds: [],
      actionName: 'ACTIONNAME3',
      description: 'ACTIONNAME3',
      id: result3.id
    };

    expect(_.isEqual(expectedResult, result)).to.be.true;
  });
});

async function createSomeActions(): Promise<string[]> {
  const actions: any[] = [];

  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName1", description: "desc2" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName2" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName3" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName4" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName5" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName6" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName7" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName8" }, {}));

  return actions.map((action) => {
    return action.id;
  });
}

async function addActionsToParents(ids: string[]) {
  await HttpUtil.put("/actions/actions/parents", {
    parentActionIds: [ids[0], ids[1], ids[2]], childActionIds: [ids[3], ids[4], ids[5]]
  }, {});

  await HttpUtil.put("/actions/actions/parents", {
    parentActionIds: [ids[1], ids[2], ids[3]], childActionIds: [ids[5], ids[6], ids[7]]
  }, {});
}

describe("The addChildrenToParents() API adds children", async () => {
  it("throws an error if the either the childActionIds or the parentActionIds are not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "childActionIds may not be null or undefined"`, async () => {
      await HttpUtil.put("/actions/actions/parents", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "childActionIds may not be empty"`, async () => {
      await HttpUtil.put("/actions/actions/parents", { childActionIds: [] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentActionIds may not be null or undefined"`, async () => {
      await HttpUtil.put("/actions/actions/parents", { childActionIds: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentActionIds may not be empty"`, async () => {
      await HttpUtil.put("/actions/actions/parents", { childActionIds: ["asdf"], parentActionIds: [] }, {});
    });
  });

  it("throws an error if there are any common ids between the parent and child actiosn", async () => {
    await TestUtils.verifyAsyncError(`401 - "The childActionIds and parentActionIds may not have any ids in common. The following ids were found to be in common actionId1"`, async () => {
      await HttpUtil.put("/actions/actions/parents", { childActionIds: ["actionId1"], parentActionIds: ["actionId1"] }, {});
    });
  });

  it("throws an error if either the childActionIds or the parentActionIds do not exist", async () => {
    const ids: string[] = await createSomeActions();

    await TestUtils.verifyAsyncError(`401 - "The following action entities were not found in the database: actionId2"`, async () => {
      await HttpUtil.put("/actions/actions/parents", {
        parentActionIds: [ids[0], ids[1]], childActionIds: [ids[2], "actionId2"]
      }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The following action entities were not found in the database: actionId1"`, async () => {
      await HttpUtil.put("/actions/actions/parents", {
        parentActionIds: [ids[0], "actionId1"], childActionIds: [ids[1], ids[2]]
      }, {});
    });
  });

  it("adds the actions to parents and does not add duplicates", async () => {
    const ids: string[] = await createSomeActions(); 
    await addActionsToParents(ids);

    const results: any[] = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      { childActionIds: [ids[3], ids[4], ids[5]], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [ids[3], ids[4], ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME2', description: 'ACTIONNAME2' },
      { childActionIds: [ids[3], ids[4], ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME3', description: 'ACTIONNAME3' },
      { childActionIds: [ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME4', description: 'ACTIONNAME4' },
      { childActionIds: [], actionName: 'ACTIONNAME5', description: 'ACTIONNAME5' },
      { childActionIds: [], actionName: 'ACTIONNAME6', description: 'ACTIONNAME6' },
      { childActionIds: [], actionName: 'ACTIONNAME7', description: 'ACTIONNAME7' },
      { childActionIds: [], actionName: 'ACTIONNAME8', description: 'ACTIONNAME8' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The findChildActions() API", async () => {
  it("throws errors if invalid values for limit and skip are provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "The value specified for limit (0) cannot be zero"`, async () => {
      await HttpUtil.get(`/actions/childActions/someid?sort=actionName&limit=0`, {});
    });

    await TestUtils.verifyAsyncError(`401 - "The value specified for skip (-1) is not a valid positive integer"`, async () => {
      await HttpUtil.get(`/actions/childActions/someid?sort=actionName&skip=-1`, {});
    });
  });

  it("throws an error if the provided action id does not exist", async () => {
    await TestUtils.verifyAsyncError(`401 - "The following action entities were not found in the database: someid"`, async () => {
      await HttpUtil.get(`/actions/childActions/someid`, {});
    });
  });

  it("Fetches children of actions and respects the sort, limit and skip attributes", async () => {
    const ids: string[] = await createSomeActions();
    await addActionsToParents(ids);

    let results: any[] = await HttpUtil.get(`/actions/childActions/${ids[0]}?sort=actionName`, {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    let expectedResults: any[] = [
      { childActionIds: [ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME4', description: 'ACTIONNAME4' },
      { childActionIds: [], actionName: 'ACTIONNAME5', description: 'ACTIONNAME5' },
      { childActionIds: [], actionName: 'ACTIONNAME6', description: 'ACTIONNAME6' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;

    let actionNames: string[] =
      _.map(await HttpUtil.get(`/actions/childActions/${ids[2]}?sort=actionName`, {}), "actionName");
    expect(_.isEqual(actionNames, ["ACTIONNAME4", "ACTIONNAME5", "ACTIONNAME6", 'ACTIONNAME7', 'ACTIONNAME8'])).to.be.true;

    actionNames =
      _.map(await HttpUtil.get(`/actions/childActions/${ids[2]}?sort=actionName&limit=2`, {}), "actionName");
    expect(_.isEqual(actionNames, ["ACTIONNAME4", "ACTIONNAME5"])).to.be.true;

    actionNames =
      _.map(await HttpUtil.get(`/actions/childActions/${ids[2]}?sort=actionName&limit=2&skip=1`, {}), "actionName");
    expect(_.isEqual(actionNames, ["ACTIONNAME5", "ACTIONNAME6"])).to.be.true;

    actionNames =
      _.map(await HttpUtil.get(`/actions/childActions/${ids[2]}?sort=actionName&limit=2&skip=10`, {}), "actionName");
    expect(_.isEqual(actionNames, [])).to.be.true;

    actionNames =
      _.map(await HttpUtil.get(`/actions/childActions/${ids[2]}?sort=actionName%3Adesc`, {}), "actionName");
    expect(_.isEqual(actionNames, ["ACTIONNAME8", "ACTIONNAME7", "ACTIONNAME6", "ACTIONNAME5", "ACTIONNAME4"])).to.be.true;

    actionNames =
      _.map(await HttpUtil.get(`/actions/childActions/${ids[6]}`, {}), "actionName");
    expect(_.isEqual(actionNames, [])).to.be.true;
  });
});

describe("The findParentActions() API", async () => {
  it("throws an error if the provided action id does not exist", async () => {
    await TestUtils.verifyAsyncError(`401 - "The following action entities were not found in the database: someid"`, async () => {
      await HttpUtil.get(`/actions/parentActions/someid`, {});
    });
  });

  it("Fetches children of actions and respects the sort, limit and skip attributes", async () => {
    const ids: string[] = await createSomeActions();
    await addActionsToParents(ids);

    let results: any[] = await HttpUtil.get(`/actions/parentActions/${ids[5]}?sort=actionName%3Adesc&limit`, {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      { childActionIds: [ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME4', description: 'ACTIONNAME4' },
      { childActionIds: [ids[3], ids[4], ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME3', description: 'ACTIONNAME3' },
      { childActionIds: [ids[3], ids[4], ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME2', description: 'ACTIONNAME2' },
      { childActionIds: [ids[3], ids[4], ids[5]], actionName: 'ACTIONNAME1', description: 'desc2' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The removeChildrenFromParents() API", async () => {
  it("throws an error if the either the childActionIds or the parentActionIds are not provided", async () => {
    await TestUtils.verifyAsyncError(`401 - "childActionIds may not be null or undefined"`, async () => {
      await HttpUtil.delete("/actions/actions/parents", {}, {});
    });

    await TestUtils.verifyAsyncError(`401 - "childActionIds may not be empty"`, async () => {
      await HttpUtil.delete("/actions/actions/parents", { childActionIds: [] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentActionIds may not be null or undefined"`, async () => {
      await HttpUtil.delete("/actions/actions/parents", { childActionIds: ["asdf"] }, {});
    });

    await TestUtils.verifyAsyncError(`401 - "parentActionIds may not be empty"`, async () => {
      await HttpUtil.delete("/actions/actions/parents", { childActionIds: ["asdf"], parentActionIds: [] }, {});
    });
  });

  it("removes the provided actions from the parents and does not complain about any missing action ids", async () => {
    const ids: string[] = await createSomeActions(); 
    await addActionsToParents(ids);

    await Promise.all([
      HttpUtil.delete("/actions/actions/parents", { 
        parentActionIds: [ids[0], "justsomeid"], childActionIds: [ids[3], ids[4], ids[5], "justanotherid"]
      }, {}),
      HttpUtil.delete("/actions/actions/parents", {
        parentActionIds: [ids[1], ids[2]], childActionIds: [ids[5], ids[6]]
      }, {})
    ]);

    const results: any[] = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults = [
      { childActionIds: [], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [ids[3], ids[4], ids[7]], actionName: 'ACTIONNAME2', description: 'ACTIONNAME2' },
      { childActionIds: [ids[3], ids[4], ids[7]], actionName: 'ACTIONNAME3', description: 'ACTIONNAME3' },
      { childActionIds: [ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME4', description: 'ACTIONNAME4' },
      { childActionIds: [], actionName: 'ACTIONNAME5', description: 'ACTIONNAME5' },
      { childActionIds: [], actionName: 'ACTIONNAME6', description: 'ACTIONNAME6' },
      { childActionIds: [], actionName: 'ACTIONNAME7', description: 'ACTIONNAME7' },
      { childActionIds: [], actionName: 'ACTIONNAME8', description: 'ACTIONNAME8' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

describe("The delete() API", async () => {
  it("deletes the action and removes the action from parent actions", async () => {
    const ids: string[] = await createSomeActions();
    await addActionsToParents(ids);

    await HttpUtil.delete(`/actions/${ids[5]}`, {}, {});
    let results: any[] = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      { childActionIds: [ids[3], ids[4]], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [ids[3], ids[4], ids[6], ids[7]], actionName: 'ACTIONNAME2', description: 'ACTIONNAME2' },
      { childActionIds: [ids[3], ids[4], ids[6], ids[7]], actionName: 'ACTIONNAME3', description: 'ACTIONNAME3' },
      { childActionIds: [ids[6], ids[7]], actionName: 'ACTIONNAME4', description: 'ACTIONNAME4' },
      { childActionIds: [], actionName: 'ACTIONNAME5', description: 'ACTIONNAME5' },
      { childActionIds: [], actionName: 'ACTIONNAME7', description: 'ACTIONNAME7' },
      { childActionIds: [], actionName: 'ACTIONNAME8', description: 'ACTIONNAME8' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });

  it("does nothing if the action id does not exist", async () => {
    const ids: string[] = await createSomeActions();
    await addActionsToParents(ids);

    await HttpUtil.delete(`/actions/asdfwefasdfs`, {}, {});
    let results: any[] = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    const expectedResults: any[] = [
      { childActionIds: [ids[3], ids[4], ids[5]], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [ids[3], ids[4], ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME2', description: 'ACTIONNAME2' },
      { childActionIds: [ids[3], ids[4], ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME3', description: 'ACTIONNAME3' },
      { childActionIds: [ids[5], ids[6], ids[7]], actionName: 'ACTIONNAME4', description: 'ACTIONNAME4' },
      { childActionIds: [], actionName: 'ACTIONNAME5', description: 'ACTIONNAME5' },
      { childActionIds: [], actionName: 'ACTIONNAME6', description: 'ACTIONNAME6' },
      { childActionIds: [], actionName: 'ACTIONNAME7', description: 'ACTIONNAME7' },
      { childActionIds: [], actionName: 'ACTIONNAME8', description: 'ACTIONNAME8' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});

async function createTwoActions() {
  const actions: string[] = [];

  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName1", description: "desc2" }, {}));
  actions.push(await HttpUtil.post("/actions", { "actionName": "actionName2" }, {}));

  return actions.map((item: any) => { return item.id });
};

describe("The updateAttributes() API", async () => {
  it("throws an error if the both the description as well as the action name are not provided", async () => {
    await TestUtils.verifyAsyncError(`Either the actionName or the description must be specified`,
      async () => {
        await HttpUtil.put(`/actions/someId`, {}, {});
      });

    await TestUtils.verifyAsyncError(`Either the actionName or the description must be specified`,
      async () => {
        await HttpUtil.put(`/actions/someId`, { actionName: " ", description: " " }, {});
      });
  });

  it("throws an error if the action doesn't exist", async () => {
    await TestUtils.verifyAsyncError(`The following action entities were not found in the database: someId`,
      async () => {
        await HttpUtil.put(`/actions/someId`, { actionName: "actionNameMod1" }, {});
      });
  });

  it("Updates the description and action name of the action and converts the action name to upper case", async () => {
    const ids: string[] = await createTwoActions();
    await HttpUtil.put(`/actions/${ids[1]}`, { actionName: "actionNameMod1" }, {});

    let results: any[] = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    let expectedResults: any[] = [
      { childActionIds: [], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [], actionName: 'ACTIONNAMEMOD1', description: 'ACTIONNAME2' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;

    await HttpUtil.put(`/actions/${ids[1]}`, { description: "descMod1" }, {});
    results = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    expectedResults = [
      { childActionIds: [], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [], actionName: 'ACTIONNAMEMOD1', description: 'descMod1' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;

    await HttpUtil.put(`/actions/${ids[1]}`, { actionName: "actionNameMod2", description: "descMod2" }, {});
    results = await HttpUtil.get("/actions", {});
    validateIdAndUnderscoreAndRemoveAttribs(results);

    expectedResults = [
      { childActionIds: [], actionName: 'ACTIONNAME1', description: 'desc2' },
      { childActionIds: [], actionName: 'ACTIONNAMEMOD2', description: 'descMod2' }
    ];

    expect(_.isEqual(expectedResults, results)).to.be.true;
  });
});
