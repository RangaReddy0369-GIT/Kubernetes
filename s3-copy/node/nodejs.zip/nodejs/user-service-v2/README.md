Instructions
1. Set the following mandatory environment or attribute values
    USER_SERVICE_MONGODB_URL: string
    ENABLE_COGNITO: boolean
    PERMISSIONS_TICKET_PRIVATE_KEY: boolean
    AWS_COGNITO_USER_POOL_ID: string
    AWS_COGNITO_REGION_NAME: string
    
<!-- 2. Run  -->



Create API takes time more than 2 second as there is validation for roles are happening need to fix that

User batch job for activation and deactivation
    Blocking
        startTime:  00:00:00
        endTime:    23:59:00
Lambda: Runs at midnight every day. Fetch all users status is active and blocktime is 
    Blocking
