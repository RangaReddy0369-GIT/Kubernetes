import { injectable } from "inversify";
import { Request } from "express";
import { ValidationUtils, ErrUtils, TransactionManagerFactory, OrmOdms, ContextManager } from "@edunxtv2/service-util";
import { SortOption, QueryCriteria } from '../interfaces/QueryCriteria';
import { Constants } from "../constants";
import * as _ from 'lodash';

@injectable()
export class BaseController {

  protected validateRelationAttributes(req: Request, parentAttribsName: string, childAttribsName: string,
    validateCommonIds: boolean = true) {
    this.validateArrayInReqBody(req, parentAttribsName);
    this.validateArrayInReqBody(req, childAttribsName);

    if (validateCommonIds) {
      const commonIds: string[] = _.intersection(req.body[parentAttribsName], req.body[childAttribsName]);

      if (commonIds.length > 0) {
        ErrUtils.throwValidationError(`The ${parentAttribsName} and ${childAttribsName} may not have any ids in common. The following ids were found to be in common ${commonIds.join(",")}`,
          "CHILD_CANNOT_BE_ITS_OWN_PARENT");
      }
    }
  }

  private validateArrayInReqBody(req: Request, attribName: string) {
    ValidationUtils.validateIsNotNullOrUndefined(req.body[attribName], attribName);

    if (req.body[attribName].length === 0) {
      ErrUtils.throwValidationError(`${attribName} may not be empty`, "EMPTY_IDS");
    }
  }

  protected isSystem(): boolean {
    return ContextManager.getAttribute(Constants.IS_SYSTEM_CONTEXT_MGR_ATTRIB);
  }

  protected async commitTransaction() {
    await TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE).commit();
  }

  protected determineLimit(req: Request) {
    return this.convertToPositiveInt("limit", req, 20, false);
  }

  protected determineSkip(req: Request) {
    return this.convertToPositiveInt("skip", req, 0, true);
  }

  protected determineSortOptions(req: Request): SortOption[] {
    const sortOptionStr: string = req.query.sort;

    if (!sortOptionStr || sortOptionStr.trim().length === 0) {
      return undefined;
    }

    const sortOptions: string[] = sortOptionStr.split(":");
    let sortKey: string;
    let sortOrder: number = 1;

    if (sortOptions.length === 1) {
      sortKey = sortOptionStr.trim();
    } else {
      sortKey = sortOptions[0].trim();
      const sortOrderStr = sortOptions[1].trim().toLowerCase();

      if (sortOrderStr === "desc" || sortOrderStr === "descending") {
        sortOrder = -1;
      }
    }

    return [{
      sortKey: sortKey,
      sortOrder: sortOrder
    }];
  }

  protected createDefaultQueryCriteria(req: Request): QueryCriteria {
    const filter: { [s: string]: any } = {};

    if (req.query.search_criteria) {
      const queryString = req.query.search_criteria;
      filter["$or"] = [{ name: { "$regex": (queryString+"").toLowerCase() } }, { emailId: { "$regex": (queryString+"").toLowerCase() } }, { status: queryString }, { 'tenantAndRoles.name': queryString }, { 'tenantAndRoles.roles.name': queryString }];
      delete req.query.search_criteria
    }
    for (let key of Object.keys(req.query)) {
      const value = req.query[key].trim();

      if (value.length > 0 && (key !== "sort" && key !== "limit" && key !== "skip")) {
        filter[key] = value;
      }
    }

    return {
      filter: filter,
      fields: [],
      sortOptions: this.determineSortOptions(req),
      skip: this.determineSkip(req),
      limit: this.determineLimit(req)
    };
  }

  private convertToPositiveInt(attribName: string, req: Request, defaultNum: number, zeroAllowed: boolean) {
    const numStr: string = req.query[attribName];

    if (numStr && numStr.trim().length > 0) {
      const num = parseInt(numStr);

      if (isNaN(num) || num < 0) {
        ErrUtils.throwValidationError(`The value specified for ${attribName} (${numStr}) is not a valid positive integer`,
          "NOT_VALID_NUMBER");
      }

      if (!zeroAllowed && num === 0) {
        ErrUtils.throwValidationError(`The value specified for ${attribName} (${numStr}) cannot be zero`,
          "NOT_POSITIVE_NUMBER");
      }

      return num;
    } else {
      return defaultNum;
    }
  }

}
