import { BaseController } from "./base.controller";
import { controller, httpPost, httpGet, httpPut, httpDelete } from "inversify-express-utils";
import { Constants } from "../constants";
import { Request, Response, NextFunction } from "express";
import { inject, injectable } from "inversify";
import { RequestPreprocessor } from "../utils/RequestPreprocessor";
import { HierarchyService } from "services/hierarchy.service";
import { HierarchyController } from "./hierarchy.controller";
import { ValidationUtils, ReqContextManager, ErrUtils, MageHttpClient, Service, Logger, ProviderFactory } from "@edunxtv2/service-util";
import * as _ from 'lodash';
import { Utils } from "../utils/Utils";
import { UserService } from "../services/user.service";
import { QueryCriteria } from "../interfaces/QueryCriteria";
import { AWSCognitoService } from "../services/aws-cognito.service";
import { UserGroupService } from "../services/user-group.service";
import { AWSService } from "../services/aws.service";


@controller(`${Constants.CONTEXT_PATH}/users`)
export class User extends HierarchyController {
    useCognito = false;
    userPoolId: string;

    constructor(@inject(UserService) private userService: UserService, private cognitoService: AWSCognitoService, private userGroupService: UserGroupService, private awsService: AWSService) {
        super();
        this.userPoolId = ProviderFactory.getAttribsProvider().getConfigVar("AWS_COGNITO_USER_POOL_ID");

        if (ProviderFactory.getAttribsProvider().getConfigVar("ENABLE_COGNITO") === 'true') {
            this.useCognito = true;
        } else {
            Logger.info("Cognito is disabled");
        }

    }

    protected getService(): HierarchyService {
        return this.userService;
    }

    protected getParentAttribsName(): string {
        return "parentGroupIds";
    }

    protected getChildAttribsName(): string {
        return 'childGroupIds';
    }


    @httpDelete("/clearall", RequestPreprocessor.preprocess)
    public async clearAll(req: Request, res: Response, next: NextFunction) {
        await this.userService.clearAll();

        await this.commitTransaction();
    }
    @httpGet('/search')
    public async searchUser(req: Request, res: Response, next: NextFunction) {
        const queryString = req.query.criteria;
        const extended = req.query.extended ? (req.query.extended === 'true') : false;
        const sortField = req.query.sort || 'name';
        const sortOrder = req.query.order || 'asc';

        // ValidationUtils.validateStringNotEmpty(queryString, "User search criteria")


        let startIndex = req.query.skip ? +req.query.skip : 0;

        const endIndex = req.query.limit ? +req.query.limit : 10;

        return await this.userService.searchUser(queryString, endIndex, startIndex, extended, { sortField, sortOrder });
    }

    /**
     * Returns the list of uses for activation and deactivation
     * @param req 
     * @param res 
     * @param next 
     */
    @httpGet('/activation')
    public async getActivationBatch(req: Request, res: Response, next: NextFunction) {
        return await this.userService.getActivationBatchUser();
    }


    @httpGet('/ids/:ids')
    public async getMultipleUsers(req: Request, res: Response, next: NextFunction) {
        const userIdsStr = req.params.ids;
        let userIds;
        try {
            userIds = JSON.parse(userIdsStr);
        } catch (e) {
            throw ErrUtils.createValidationError("Invalid JSON input", "VALIDATION_ERR")
        }
        const queryCriteria = {
            "id": { "$in": userIds }
        }
        const users = await this.userService.getModel().find(queryCriteria)
        res.json(users)
        // const extended = req.query.extended || false;
        // if(!extended){
        //     // return this.userService.findById(userId);
        // }else{
        //  TODO for extended check all the data which need to be populated like group info
        // }
    }
    @httpGet('/:id')
    public async getUsers(req: Request, res: Response, next: NextFunction) {
        const userId = req.params.id;
        const extended = req.query.extended || false;
        if (!extended) {
            return this.userService.findById(userId);
        } else {
            //TODO for extended check all the data which need to be populated like group info
        }
    }

    @httpGet('/')
    public async getAllUser(req: Request, res: Response, next: NextFunction) {

        return await super.findAll(req, res, next);
    }

    @httpPost('/')
    public async createUser(req: Request, res: Response, next: NextFunction) {
        const existingUser = await this.userService.getModel().findOne({ emailId: req.body.emailId }).exec();

        // req.body["instanceId"]


        if (existingUser) {
            return ErrUtils.throwValidationError(`Entity users with id ${req.body.emailId} already exists`,
                "ENTITY_EXISTS");
        }
        const data = await this.userService.buildForCreate(req.body);

        const userGroups = req.body.userGroups;

        if (this.useCognito) {
            const cognitoUser = await this.cognitoService.createUser(data);
            data.cognitoId = cognitoUser.User.Username;
            data.userPoolId = this.userPoolId;
        } else {
            data.cognitoId = Utils.generateUuid();
            data.userPoolId = "NA";

        }
        const newUser = await this.userService.create(data);

        // Add user to user group as per the body
        // if error after cognito remove user from cognito
        await this.commitTransaction();
        const response = {
            user: newUser[0],
            userGroupStatus: ''
        };
        if (req.body.userGroups) {
            try {
                // if user group mapping fails send the message in the response
                await this.userGroupService.updateUserGroup(newUser[0].id, userGroups, true);
                response["userGroupStatus"] = "success";

            } catch (err) {
                console.log(err.message)
                response["userGroupStatus"] = err.message
            }
        }

        res.status(201).json(response);
    }

    @httpPut('/:id')
    public async updateUser(req: Request, res: Response, next: NextFunction) {
        let updateData = await this.userService.buildForUpdate(req.body);
        let updatedData = await this.userService.update(req.params.id, updateData);
        if (!updatedData) {
            return res.json(null);
        }
       

        if (this.useCognito) {
            await this.cognitoService.updateUser(updatedData);
        }


        await this.commitTransaction();
        if (req.body.updateGroup === true || req.body.updateGroup === 'true') {
            Logger.info("updating user group ", req.body);
            await this.userGroupService.updateUserGroup(req.params.id, req.body.userGroups, true);
        }
        res.json(updatedData);
    }


    @httpPut('/:id/ping')
    public async updateLastSeen(req: Request, res: Response, next: NextFunction) {

        await this.userService.update(req.params.id, { lastActive: new Date() });
        await this.commitTransaction();
        res.json('success');
    }

    /**
     * 
     * @param req 
     * @param res 
     * @param next 
     * First check the operation to be performed in status variable. If its valid to the operation
     * Otherwise throw error. For block operation validate the date duration 
     */
    @httpPut('/:id/activation')
    public async updateUserActivation(req: Request, res: Response, next: NextFunction) {
        const status = req.body.status;


        if (['block', 'deactivate', 'activate'].indexOf(status) == -1) {
            ErrUtils.throwValidationError("Invalid operation", "VALIDATION_ERR")
        }
        ValidationUtils.validateStringNotEmpty(req.body.statusRemark, "statusRemark");

        let data = {

        };
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (status === 'block') {
            if (!req.body.endDate) {
                ErrUtils.throwValidationError("For Blocking user endDate is mandatory", "VALIDATION_ERR");
            }
            let startDate = req.body.startDate;
            let endDate = req.body.endDate;
            ValidationUtils.validateDate(startDate, 'StartDate');
            ValidationUtils.validateDate(req.body.endDate, 'EndDate');
            startDate = new Date(req.body.startDate);
            endDate = new Date(req.body.endDate);

            startDate.setHours(0, 0, 0, 0);
            endDate.setHours(23, 59, 0, 0);

            if (endDate < today) {
                ErrUtils.throwValidationError("End date must be after today", "VALIDATION_ERR")
            }
            //TODO check for the time correctness
            if (startDate > endDate) {
                ErrUtils.throwValidationError("Start date must be before end date", "VALIDATION_ERR")
            }
            data = {
                // status: 'blocked',
                blockDuration: {
                    startDate,
                    endDate
                },
                statusRemark: req.body.statusRemark

            }
            if (startDate <= today) {
                data["status"] = 'blocked';
            }

        } else if (status === 'deactivate') {
            ValidationUtils.validateStringNotEmpty(req.body.statusRemark, "statusRemark");

            data = { status: 'deactivated', statusRemark: req.body.statusRemark }
        } else if (status === 'activate') {
            data = { 'status': 'activated', blockDuration: null, statusRemark: req.body.statusRemark };
        }


        let updatedUser = await this.userService.update(req.params.id, data);
        if (!updatedUser) {
            res.status(404).send("Invalid userid");
        }


        if (this.useCognito) {
            if (status === 'activate') {
                await this.cognitoService.enableUser(updatedUser['cognitoId']);
            } else if (status === 'deactivate') {
                await this.cognitoService.disableUser(updatedUser['cognitoId']);
            } else if (status === 'block') {
                if (data["blockDuration"]["startDate"] <= today) {
                    await this.cognitoService.disableUser(updatedUser['cognitoId']);
                }
            }
        }
        await this.commitTransaction();

        res.json(updatedUser);
    }

    @httpDelete('/:id')
    public async deleteUser(req: Request, res: Response, next: NextFunction) {
        this.getService().delete(req.params.id);
        await this.commitTransaction();
        res.send('success')
    }


    private validateForCreate(data) {

        ValidationUtils.validateStringNotEmpty(data.name, "name");
        ValidationUtils.validateStringNotEmpty(data.emailId, "emailId");
        ValidationUtils.validateIsNotNullOrUndefined(data.phone, "phone");
        ValidationUtils.validateStringNotEmpty(data.phone.countryCode, "countryCode");
        ValidationUtils.validateStringNotEmpty(data.phone.phoneNumber, "phoneNumber");
        let tenantAndRoles = data.tenantAndRoles;


        ValidationUtils.validateEmail(data.emailId);
        //TODO: Create validations for country code 
        //TODO: Create validations for Phone Number 
    }

    private async validateTenantAndRoles(tenants: any[]) {
        if (!tenants || tenants.length === 0) {
            throw ErrUtils.createValidationError(`Invalid tenant Data`, "VALIDATION_ERR")

        }
        const promises = []
        const requestData = []
        for (let x = 0; x < tenants.length; x++) {
            const tenantRoles = tenants[x];
            tenantRoles.roles.forEach(tenantRole => {
                const options = {
                    method: 'GET',
                    qs: {
                        organizationId: tenantRoles.id,
                        id: tenantRole.roleId,
                        roleName: tenantRole.name

                    }
                }
                requestData.push({
                    organizationId: tenantRoles.id,
                    id: tenantRole.roleId,
                    roleName: tenantRole.name
                });
                promises.push(MageHttpClient.call(Service.AUTHORIZATION_SERVICE, '/roles', options));
            });
        }
        let responses = await Promise.all(promises);
        let invalidDataIndex = responses.findIndex(response => response === "" || response.length === 0);
        if (invalidDataIndex != -1) {
            throw ErrUtils.createValidationError(`Invalid tenant Role mapping: ${requestData[invalidDataIndex].roleName}`, "VALIDATION_ERR")
        }

    }

}