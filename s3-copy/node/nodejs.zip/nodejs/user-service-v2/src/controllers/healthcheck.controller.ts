import { BaseController } from "./base.controller";
import { controller, httpGet } from "inversify-express-utils";
import { Constants } from "../constants";
import { Request, Response } from 'express';
import { QueueService } from "../services/queue.service";

@controller(`${Constants.CONTEXT_PATH}/healthcheck`)
export class HealthCheckController extends BaseController{
    constructor(private queueService: QueueService){
        super();
    }

    @httpGet('/')
    public async chechHealth(req: Request, res: Response){
        res.send('success');
    }

}