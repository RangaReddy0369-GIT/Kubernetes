import { Request, Response, NextFunction } from "express";
import { controller, httpPost, httpGet, httpPut, httpDelete } from "inversify-express-utils";
import * as parser from 'csv-parser';
import { ValidationUtils, ReqContextManager, ProviderFactory, NamespaceMessageUtils, Logger, ErrUtils, MageHttpClient, Service } from "@edunxtv2/service-util";
import { Queue, QueueFactory, QueueName } from "@edunxtv2/messaging-client";

import { HierarchyController } from "./hierarchy.controller";
import { Constants } from "../constants";
import { BatchService } from "../services/batch.service";
import { AWSService } from "../services/aws.service";
import { UserBatchService } from "../services/user-batch.service";
import { BATCHSTATUS } from "../models/batch.model";
import { USERBATCHSTATUS } from "../models/batch-user.model";
import { RequestPreprocessor } from "../utils/RequestPreprocessor";
import { Utils } from "../utils/Utils";

@controller(`${Constants.CONTEXT_PATH}/batches`)
export class BatchController extends HierarchyController {


    bucketName: any;
    queue: Queue;
    constructor(private batchService: BatchService, private awsService: AWSService, private batchUserService: UserBatchService) {
        super();
        this.queue = QueueFactory.getQueue(QueueName.USER_USERCREATION_BATCH);

        this.bucketName = ProviderFactory.getAttribsProvider().getConfigVar("S3_BUCKET_NAME");
    }

    @httpGet('/fileupload')
    public async getUrlForFileUpload(req: Request, res: Response, next: NextFunction) {
        ValidationUtils.validateStringNotEmpty(req.query.organizationId, 'organizationId')
        ValidationUtils.validateStringNotEmpty(req.query.instanceId, 'instanceId')
        ValidationUtils.validateStringNotEmpty(req.query.filename, 'name')

        // ValidationUtils.validateStringNotEmpty(req.query.organizationId,'organizationId')
        // ValidationUtils.validateStringNotEmpty(req.query.organizationId,'organizationId')
        const meta = {}
        meta["name"] = req.query.instanceId + '/' + req.query.organizationId + '/' + Utils.generateUuid() + req.query.filename;
        meta['ContentType'] = "application/csv";
        meta['organizationId'] = req.query.organizationId;
        meta['instanceId'] = req.query.instanceId;
        // meta['instanceId']=req.query.name;

        const response = await this.awsService.getSignedUrl(meta);
        return response;

    }


    /**
     * 
     * @param req Create a new batch with reference to s3 file Id, bucket and region and batch name (yyyy-MM-dd-OrgName-InstanceName) and 
     * @param res 
     */
    @httpPost('/')
    public async createNewBatch(req: Request, res: Response) {
        // ValidationUtils.validateStringNotEmpty(req.body.name, "name");
        ValidationUtils.validateStringNotEmpty(req.body.filename, "fileName");
        ValidationUtils.validateStringNotEmpty(req.body.organizationId, "organizationId");
        ValidationUtils.validateStringNotEmpty(req.body.instanceId, "instanceId");
        ValidationUtils.validateStringNotEmpty(req.body.s3FileId, "s3FileId");
        const organizationId = req.body.organizationId;
        const instanceId = req.body.instanceId;
        const name = `${new Date().toISOString().split('T')[0]}-${organizationId}-${instanceId}`
        const batchId = Utils.generateUuid();
        const data = {
            name: name,
            id: batchId,
            organizationId: organizationId,
            instanceId: req.body.instanceId,
            s3Details: {
                s3FileId: req.body.s3FileId,
                fileName: req.body.filename,
                bucketName: this.bucketName
            }

        };
        let response;
        try {
            response = await this.batchService.createBatch(data);
            response = response[0];
            await this.awsService.getFileMeta(req.body.s3FileId);
            const fileStream = this.awsService.getFileStream(req.body.s3FileId);

            let messages = [];
            let bulkData = [];
            let totalRecords = 0;
            fileStream.pipe(parser())
                .on('data', async (data) => {
                    let userData = {
                        name: data.Name,
                        batchId,
                        instanceId,
                        organizationId,
                        emailId: data.EmailId ? data.EmailId.toLowerCase() : null,
                        phone: {
                            countryCode: data.CountryCode,
                            phoneNumber: data.Phone
                        },
                        roles: data.Roles.split(","),
                        userGroups: [data.UserGroupName]
                    }
                    messages.push(NamespaceMessageUtils.createMessage('createUser', null, userData));
                    bulkData.push(userData);
                    totalRecords++;
                })
                .on('error', function (err) {
                    // capture any errors that occur when writing data to the file
                    console.error('File Stream:', err);

                })
                .on('end', async () => {
                    const results = await this.batchUserService.bulkCreate(bulkData);
                    const updateData = {
                        stats: { total: totalRecords }
                    }
                    await this.batchService.updateBatch(batchId, updateData);
                    await this.queue.post(messages, Utils.generateUuid()); // try catch and make sqs fail
                   
                });
        } catch (err) {
            Logger.error(err, "S3ERR", "AWS");
            //TODO handle AWS error correctly
            if (response) {
                await this.batchService.updateBatch(response.id, { status: BATCHSTATUS.ERROR, statusRemark: err.code });
            }
            if (err.code === 'NotFound') {
                throw ErrUtils.createValidationError("Invalid file key", "S3FILEERR")
            }
            throw err;
        }

        await this.commitTransaction();
        return response;
    }

    @httpGet('/:id/status')
    public async batchStatusCheck(req: Request, res: Response) {
        
        const batchDetail = await this.batchService.getBatchDetails(req.params.id);
        if (!batchDetail) {
            return res.status(404).send() ;
        }
        return await this.batchService.checkAndUpdateBatchStatus(batchDetail);

    }

    @httpGet('/:id')
    public async getBatchDetails(req: Request, res: Response) {
        return await this.batchService.getBatchDetails(req.params.id);
    }

    @httpGet('/')
    public async getAllBatchDetails(req: Request, res: Response, next: NextFunction) {
        return await super.findAll(req, res, next);
    }

    @httpPut('/:id')
    public async updateBatch(req: Request, res: Response) {
        ValidationUtils.validateStringNotEmpty(req.body.status, "status");
        return await this.batchService.updateBatch(req.params.id, req.body.status);
    }
    @httpDelete("/clearall/batches", RequestPreprocessor.preprocess)
    public async clearAll(req: Request, res: Response, next: NextFunction) {
        await this.batchUserService.clearAll();

        await this.commitTransaction();
    }


    protected getService() {
        return this.batchService;
    }
    protected getParentAttribsName(): string {
        throw new Error("Method not implemented.");
    }
    protected getChildAttribsName(): string {
        throw new Error("Method not implemented.");
    }
}


