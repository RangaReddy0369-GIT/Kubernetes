import { controller, httpGet, httpPut, httpPost } from "inversify-express-utils";
import { Constants } from "../constants";
import { Request, Response, NextFunction } from 'express';
import { UserBatchService } from "../services/user-batch.service";
import { HierarchyService } from "services/hierarchy.service";
import { HierarchyController } from "./hierarchy.controller";

@controller(`${Constants.CONTEXT_PATH}/userbatches`)
export class BatchProcessController extends HierarchyController{
    protected getService(): HierarchyService {
        return this.userBatchService;
    }
    protected getParentAttribsName(): string {
        throw new Error("Method not implemented.");
    }
    protected getChildAttribsName(): string {
        throw new Error("Method not implemented.");
    }
   
    constructor(private userBatchService: UserBatchService){
        super()
    }

    @httpPost('/')
    public async addBatchUser(req: Request, res: Response){
        // this.validateBatch(req.body);
        
        // return this.userBatchService.createUser(req.body);

    }

    @httpGet('/')
    public async retrieveAllBatchUsers(req: Request, res: Response, next: NextFunction){        
        return await super.findAll(req, res, next);
    }
    @httpGet('/:id')
    public async retrieveBatchUsers(req: Request, res: Response, next: NextFunction){   
        // const id= req.params.id;
        req.query.batchId=req.params.id;     
        return await super.findAll(req, res, next);
    }

    // @httpPost('/:id')
    // public async updateBatchUser(req: Request, res: Response){
    //     // return
    // }
    // @httpPost('/:id/status')
    // public async updateBatchUserStatus(req: Request, res: Response){
    //     // return
    //     const updateData = {}
    //     const remark = req.body.remark;
    //     ValidationUtils.validateStringNotEmpty(remark, 'remark');
    //     // return await this.userBatchService.updateBatchUser(req.params.id, )
    // }
    // private  validateBatch(data:any[]){
    //     data.forEach(data=>{
    //         ValidationUtils.validateStringNotEmpty(data.batchId,'batchId' );
    //         ValidationUtils.validateStringNotEmpty(data.id,'batchId' );
    //         ValidationUtils.validateStringNotEmpty(data.name,'batchId' );
    //         ValidationUtils.validateStringNotEmpty(data.emailId,'batchId' );
    //         //TODO process tenantRoles and Phone number
    //     });
    // }

}