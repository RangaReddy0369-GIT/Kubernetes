import { injectable } from "inversify";
import { Request, Response, NextFunction } from "express";
import { ValidationUtils, ErrUtils } from "@edunxtv2/service-util";
import { BaseController } from "./base.controller";
import { HierarchyService } from "services/hierarchy.service";

@injectable()
export abstract class HierarchyController extends BaseController {

  protected abstract getService(): HierarchyService;

  protected abstract getParentAttribsName(): string;

  protected abstract getChildAttribsName(): string;

  protected async findAll(req: Request, res: Response, next: NextFunction) {
    const extended = req.query.extended ? (req.query.extended === 'true') : false;
    delete req.query.extended;
    res.json(await this.getService().findAll(this.createDefaultQueryCriteria(req),null,extended));
    await this.commitTransaction();
  }

  protected async addChildrenToParents(req: Request, res: Response, next: NextFunction) {
    this.validateRelationAttributes(req, this.getParentAttribsName(), this.getChildAttribsName());
    const result = await this.getService().addChildrenToParents(
      req.body[this.getParentAttribsName()], req.body[this.getChildAttribsName()]);

    await this.commitTransaction();
    res.json(result);
  }

  protected async removeChildrenFromParents(req: Request, res: Response, next: NextFunction) {
    await this.validateRelationAttributes(req, this.getParentAttribsName(), this.getChildAttribsName(), false);

    const result: any = await this.getService().removeChildrenFromParents(
      req.body[this.getParentAttribsName()], req.body[this.getChildAttribsName()]);

    await this.commitTransaction();
    res.json(result);
  }

  protected async delete(req: Request, res: Response, next: NextFunction) {
   
    await this.getService().delete(req.params.id);

    await this.commitTransaction();
   
    res.send("success");
  }

}
