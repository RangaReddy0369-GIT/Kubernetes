import 'reflect-metadata';
require('express-async-errors')
import * as compression from 'compression';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import * as express from 'express';
import { Request, Response, NextFunction } from 'express';


import { InversifyExpressServer } from "inversify-express-utils";

import { ContextManager, ReqContextManager, ApiSecurityManager, Service, TransactionManager, TransactionManagerFactory, OrmOdms, Logger, ServiceUtil, NamespaceMessageUtils, MageHttpClient } from "@edunxtv2/service-util";
import { QueueFactory, QueueName, Queue } from '@edunxtv2/messaging-client';

import { container } from './ioc';
import { UserService } from './services/user.service';
import { QueueService } from './services/queue.service';

export async function initializeServer() {
  let server = new InversifyExpressServer(container);

  server.setConfig(async (app: express.Application) => {
    app.use(compression());
    app.disable('etag');
    app.use(cors());

    app.use(bodyParser.urlencoded({
      extended: true
    }));

    app.use(bodyParser.json({ limit: '10mb' }));

    ContextManager.init(app);
    ServiceUtil.init();


    ReqContextManager.registerWithReqContextManager(app,
      [`/${Service.USER_SERVICE}/healthcheck`, `/${Service.USER_SERVICE}/users/clearall`]);
    ApiSecurityManager.switchOnApiSecurityValidation(
      app, [`/${Service.USER_SERVICE}/healthcheck`, `/${Service.USER_SERVICE}/usergroups/clearall`],
      Service.USER_SERVICE);

      MageHttpClient.init(Service.USER_SERVICE);  


    const transactionManager: TransactionManager =
      TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE);
    transactionManager.register(app);

    server.setErrorConfig((app) => {
      app.use(async (err: any, req: Request, res: Response, next: NextFunction) => {
        Logger.error(err, err.errId || "UNKNOWN", err.errType || "UNKNOWN");
        const transactionManager: TransactionManager =
          TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE);
        await transactionManager.rollback();

        res.status(err.code || 500).json(err.message);
      });
    });
  });

  let userService = container.get(QueueService);
  let actionMap = {}
  actionMap['createUser'] = { instance: userService, callback: userService.createUser }
  actionMap['activateUser'] = { instance: userService, callback: userService.updateUserStatus }
  actionMap['deactivateUser'] = { instance: userService, callback: userService.updateUserStatus }
  NamespaceMessageUtils.init(actionMap, TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE));

  await QueueFactory.init([QueueName.USER_USERCREATION_BATCH, QueueName.USER_ACTIVATION]);
  const queue: Queue = QueueFactory.getQueue(QueueName.USER_USERCREATION_BATCH);
  queue.registerCallback(NamespaceMessageUtils.runWithinContext);

  const userActivationQueue: Queue = QueueFactory.getQueue(QueueName.USER_ACTIVATION);
  userActivationQueue.registerCallback(NamespaceMessageUtils.runWithinContext)
  

  const port = process.env.PORT || 4053;

  server.build().listen(port, () => {
    Logger.info(`User Service is Listening on port ${port}`);
  });
}
