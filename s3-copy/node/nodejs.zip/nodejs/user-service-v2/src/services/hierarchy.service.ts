import { injectable } from "inversify";
import { BaseService } from "./base.service";
import { QueryCriteria } from "../interfaces/QueryCriteria";
import { Document } from 'mongoose';
import * as _ from 'lodash';

@injectable()
export abstract class HierarchyService extends BaseService {

  protected abstract getParentAttribsName(): string;

  protected getChildModel() {
    return this.getModel();
  }

  protected getChildEntityName(): string {
    return this.getEntityName();
  }

  public async findChildren(entityId: string, defaultQueryCriteria: QueryCriteria) {
    await this.validateEntitiesExist([entityId], this.getParentEntityName());

    const queryCriteria: QueryCriteria = _.cloneDeep(defaultQueryCriteria);
    queryCriteria.filter[this.getParentAttribsName()] = entityId;

    return await this.findAll(queryCriteria, this.getEntityName());
  }

  public async findParents(entityId: string, defaultQueryCriteria: QueryCriteria): Promise<Document[]> {
    await this.validateEntitiesExist([entityId], this.getEntityName());

    const entity: Document = await this.findById(entityId);
    const parentIds: string[] = entity[this.getParentAttribsName()];

    const queryCriteria: QueryCriteria = _.cloneDeep(defaultQueryCriteria);
    queryCriteria.filter.id = { $in: parentIds };

    return await this.findAll(queryCriteria, this.getParentEntityName());
  }

  public async addChildrenToParents(parentIds: string[], entityIds: string[]) {

    await this.validateEntitiesExistAndBelongToSameOrg(entityIds, parentIds, false);
  return await this.getModel().updateMany(
      {
        id: { $in: entityIds }
      }, {
      "$addToSet": {
        [this.getParentAttribsName()]: parentIds
      }
    }).session(this.getSession()).exec();
  }

  public async removeChildrenFromParents(entityIds: string[], childIds: string[]) {
    return await this.getModel().updateMany({
      id: { $in: childIds }
    }, {
      $pullAll: {
        [this.getParentAttribsName()]: entityIds
      }
    }).session(this.getSession()).exec();
  }

  public async handleParentDeletion(parentId: string) {
    return await this.getModel().updateMany({
      [this.getParentAttribsName()]: parentId
    }, {
      $pull: {
        [this.getParentAttribsName()]: parentId
      }
    }).session(this.getSession()).exec();
  }

  public async delete(entityId: string): Promise<void> {
    await this.getModel().deleteOne(
      { id: entityId }).session(this.getSession()).exec();
  }

  // public async update(data:)

}
