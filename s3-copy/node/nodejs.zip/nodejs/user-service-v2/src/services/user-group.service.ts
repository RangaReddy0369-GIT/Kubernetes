import { provideSingleton } from "../ioc";
import { MageHttpClient, Service } from "@edunxtv2/service-util";

@provideSingleton(UserGroupService)
export class UserGroupService {
    constructor(){
    }

    async updateUserGroup(userId: string, userGroups: string[], validateUser=true, field = 'parentGroupIds'){
        let data = {}
        if(field ==='userGroups'){
            data ={
                method: 'POST',
                body:{
                userIds: [userId],
                userGroups: userGroups,
                validateUser
                },
                json: true
            }
        }else {
            data ={
            method: 'POST',
            body:{
            userIds: [userId],
            parentGroupIds: userGroups,
            validateUser
            },
            json: true
        }
    }

        return await MageHttpClient.call(Service.USERGROUP_SERVICE, '/usergroups/user',  data);
    }
}