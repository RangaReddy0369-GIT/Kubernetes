import { provideSingleton } from "../ioc";
import { BulkProcessBatchModel, BATCHSTATUS } from "../models/batch.model";
import { BaseService } from "./base.service";
import { HierarchyService } from "./hierarchy.service";
import { UserBatchService } from "./user-batch.service";
import { USERBATCHSTATUS } from "../models/batch-user.model";

@provideSingleton(BatchService)
export class BatchService extends HierarchyService {
    
    constructor(private batchUserService: UserBatchService) {
        super()
    }
    protected getModel() {
        return BulkProcessBatchModel;
    }

    async createBatch(data: any) {
        return await this.getModel().create([data], { session: this.getSession() });
    }

    async getBatchDetails(batchId: string) {
        return await this.getModel().findOne({ id: batchId })
    }

    async updateBatch(batchId: string, data: any) {
        return await this.getModel().findOneAndUpdate({ id: batchId }, { '$set': data });//.session(this.getSession());
    }

    public async checkAndUpdateBatchStatus(batchDetail: any){
        
        let batchStatisticsArray = await this.batchUserService.batchStatus(batchDetail.id);
        let batchStatistics={
        };
        let progressCount =0;
        if (batchStatisticsArray && batchStatisticsArray.length > 0) {
            batchStatisticsArray.forEach(i=>{
                progressCount+=i.count;
                return  batchStatistics[i._id]=i.count;
            });
        } else {
            return {};
        }
        batchStatistics["total"] = batchDetail["stats"].total
        if(progressCount !== batchDetail["stats"].total){
            batchDetail["status"] = BATCHSTATUS.PROCESSING
            return batchDetail;
        }

        if(batchStatistics[USERBATCHSTATUS.CREATED] && batchStatistics[USERBATCHSTATUS.CREATED] >0){
            batchDetail["status"] = BATCHSTATUS.PROCESSING
        }else if (batchStatistics[USERBATCHSTATUS.ERROR] && batchStatistics[USERBATCHSTATUS.ERROR] >0) {
            batchDetail["status"] = BATCHSTATUS.ERROR;
        }else if (batchStatistics[USERBATCHSTATUS.COMPLETED_PARTIAL_ERROR] && batchStatistics[USERBATCHSTATUS.COMPLETED_PARTIAL_ERROR] >0) {
            batchDetail["status"] = BATCHSTATUS.COMPLETED_PARTIAL_ERROR;
        }else if (batchStatistics[USERBATCHSTATUS.COMPLETED_PARTIAL_UPDATE] && batchStatistics[USERBATCHSTATUS.COMPLETED_PARTIAL_UPDATE] >0) {
            batchDetail["status"] = BATCHSTATUS.COMPLETED_PARTIAL_UPDATE;
        }else if(batchStatistics[USERBATCHSTATUS.COMPLETED] && batchStatistics[USERBATCHSTATUS.COMPLETED] === batchDetail["stats"].total){
            batchDetail["status"] = BATCHSTATUS.COMPLETED;
        }
        const updateData = {
            status : batchDetail["status"],
            stats: batchStatistics
        }
        batchDetail = await this.updateBatch(batchDetail.id, updateData);

        // TODO check whether transaction can be created for timeinterval kind of service
        return batchDetail;
    }
    protected getParentModel() {
        throw new Error("Method not implemented.");
    }
    protected getParentEntityName(): string {
        throw new Error("Method not implemented.");
    }
    protected getEntityName(): string {
        return BaseService.ENTITY_BATCH;
    }
    protected getChildModel() {
        throw new Error("Method not implemented.");
    }
    protected getChildEntityName(): string {
        throw new Error("Method not implemented.");
    }
    protected getParentAttribsName(): string {
        throw new Error("Method not implemented.");
    }

}