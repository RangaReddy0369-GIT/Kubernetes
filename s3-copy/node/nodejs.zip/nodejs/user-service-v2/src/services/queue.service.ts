import * as _ from 'lodash';

import { provideSingleton } from "../ioc";
import { UserService } from "./user.service";
import { ErrUtils,  ProviderFactory, Logger } from "@edunxtv2/service-util";
import { BatchService } from "./batch.service";
import { AWSCognitoService } from "./aws-cognito.service";
import { Utils } from "../utils/Utils";
import { UserBatchService } from "./user-batch.service";
import { UserGroupService } from "./user-group.service";
import { USERBATCHSTATUS } from "../models/batch-user.model";
import { BATCHSTATUS } from '../models/batch.model';

const delay = require('delay');

@provideSingleton(QueueService)
export class QueueService {
    useCognito: boolean;
    userPoolId: string;


    constructor(private userService: UserService, private batchUserService: UserBatchService,
        private cognitoService: AWSCognitoService, private userGroupService: UserGroupService, private batchService: BatchService) {
        this.userPoolId = ProviderFactory.getAttribsProvider().getConfigVar("AWS_COGNITO_USER_POOL_ID");

        if (ProviderFactory.getAttribsProvider().getConfigVar("ENABLE_COGNITO") === 'true') {
            this.useCognito = true;
        }
    }

    async updateUserStatus(payload) {
        const status = payload.status;
        console.log("Processing:", payload);
        if (['block', 'activate'].indexOf(status) == -1) {
            ErrUtils.throwValidationError("Invalid operation", "VALIDATION_ERR")
        }
        let data = {}
        if (status === 'block') {
            data = { 'status': 'blocked' }
            await this.cognitoService.enableUser(payload['cognitoId']);
        } else if (status === 'activate') {
            data = { 'status': 'activated', blockDuration: null }
            await this.cognitoService.disableUser(payload['cognitoId']);
        }
        await this.userService.update(payload.id, data);

    }

    async createUser(payload) {
        const userData = {
            ...payload
        }

        //@TODO integrate organization service also make multi tenant map
        userData["tenantAndRoles"] = [{
            id: payload.organizationId,
            name: payload.organizationId,
            instance: payload.instanceId,
            roles: []

        }]
        payload.roles.forEach(element => {
            userData.tenantAndRoles[0].roles.push(element)
        });

        try {
            let result;
            const user = await this.userService.findByField(userData.emailId, "emailId");
            if (user) {
                result = await this.update(userData, user)
            } else {
                result = await this.create(userData, payload);
            }
            console.log(result)
            
            await this.batchUserService.updateBatchUser({batchId: userData.batchId, emailId: userData.emailId}, result);
          
           
        } catch (err) {
            // TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE).handleDatabaseError();
            // TODO 
            await this.batchUserService.updateBatchUser({batchId: userData.batchId, emailId: userData.emailId}, { status: USERBATCHSTATUS.ERROR, remarks: `${userData.id} - ${err.message}` }, false);
            Logger.error(err.message,"BLKUPLOAD_ERR","USERSERVICE", userData);

            throw err;
        }
        setTimeout(async ()=>{
            const batchDetail = await this.batchService.getBatchDetails(userData.batchId);
            await this.batchService.checkAndUpdateBatchStatus(batchDetail);
        },200)
        


    }

    /**
     * Function to add tenant and group details to users 
     * who are already registered in the system and also present in 
     * Batch upload. Fields other than tenantAndRoles and usergroups will be ignored
     * @param userData 
     */
    async update(userData: any, userToUpdate: any) {
        const batchData = {}
        console.log("partial updatte")
        try {
            const updateData = {};
            if (userData.tenantAndRoles) {
                await this.userService.validateAndMakeTenantAndRoles(userData.tenantAndRoles)
                updateData['tenantAndRoles'] = []
            }
            userData.tenantAndRoles.forEach(newtenant => {
                const existingTenant = userToUpdate.tenantAndRoles.find(tenant => tenant.name === newtenant.name);
                if (existingTenant) {
                    existingTenant['roles'] = _.unionBy(existingTenant['roles'], newtenant.roles, "roleId");
                } else {
                    userToUpdate.tenantAndRoles.push(newtenant)
                }
            });
            updateData['tenantAndRoles'] = userToUpdate.tenantAndRoles;
            await this.userService.update(userToUpdate['id'], updateData);
            await this.userGroupService.updateUserGroup(userToUpdate['id'], userData.userGroups, true, 'userGroups');
            // await this.batchUserService.updateBatchUser(userData.emailId, { status: USERBATCHSTATUS.COMPLETED_PARTIAL_UPDATE, remarks:  })
            batchData["status"] = USERBATCHSTATUS.COMPLETED_PARTIAL_UPDATE;
            batchData["remarks"] = "updated fields only";
        } catch (err) {
            batchData["status"] = USERBATCHSTATUS.ERROR;
            batchData["remarks"] = `${userToUpdate.id} - err.message`;
            Logger.error(err, "SYSTEMERR", "APPERR");
            throw err;

        }
        return batchData;
    }


    /**
     * Create a new user in user cognito and then in the EDUNXT system. If there is any error the roll back 
     * @param userData 
     * @param payload 
     */
    async create(userData: any, payload) {
        const batchData = {}
        let newUser;
        let cognitoUser;
        try {
            await this.userService.buildForCreate(userData)
            if (this.useCognito) {
                cognitoUser = await this.cognitoService.createUser(userData);
                userData.cognitoId = cognitoUser.User.Username;
                userData.userPoolId = this.userPoolId;
            } else {
                userData.cognitoId = Utils.generateUuid();
                userData.userPoolId = "NA";
            }
            newUser = await this.userService.create(userData);
            newUser = newUser[0];
        } catch (error) {
            if (this.useCognito && cognitoUser && cognitoUser.User) {
                this.cognitoService.deleteUser(cognitoUser.User.Username);
            }
            throw error;
        }
        try {
            await this.userGroupService.updateUserGroup(newUser['id'], userData.userGroups, false, 'userGroups');
            batchData["status"] = USERBATCHSTATUS.COMPLETED;
            batchData["remarks"] = newUser.id;
        } catch (error) {
            console.log("ERROR IN USER GROUP MAPPING", error);
            batchData["status"] = USERBATCHSTATUS.COMPLETED_PARTIAL_ERROR;
            batchData["remarks"] = error.message;
        }
        //const updatedData = await this.batchUserService.updateBatchUser(userData.emailId, batchData)
        // console.log(updatedData);
        return batchData;
    }

  



}

