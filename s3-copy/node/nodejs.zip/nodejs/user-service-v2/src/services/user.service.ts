import * as _ from 'lodash';

import { HierarchyService } from "./hierarchy.service";
import { UserModel, IUserModel } from "../models/user.model";
import { BaseService } from "./base.service";
import { ErrUtils, TransactionManagerFactory, OrmOdms, ValidationUtils, MageHttpClient, Service, ServiceUtil } from "@edunxtv2/service-util";
import { ClientSession } from "mongoose";
import { provideSingleton } from "../ioc";
import { AWSCognitoService } from "./aws-cognito.service";
import { Utils } from "../utils/Utils";


// import { performance } from '../../temp/performance';


@provideSingleton(UserService)
export class UserService extends HierarchyService {


  constructor(private cognitoService: AWSCognitoService) {
    super();
    // console.log("New user service instance created...")
  }
  protected getParentAttribsName(): string {
    throw new Error("Method not implemented.");
  } protected getParentModel() {
    throw new Error("Method not implemented.");
  }
  protected getParentEntityName(): string {
    throw new Error("Method not implemented.");
  }
  getModel() {
    return UserModel;
  }
  protected getEntityName(): string {
    return BaseService.ENTITY_USER;
  }

  public async buildForCreate(data: any) {
    this.validateForCreate(data);
    data.name = data.name.toLowerCase();
    data.emailId = data.emailId.toLowerCase();
    data.phone.countryCode = (data.phone.countryCode+"").indexOf("+")!=-1 ? data.phone.countryCode: "+"+data.phone.countryCode;
    // TODO: Create validation for organisation once organisation service is ready
    data.tenantAndRoles = await this.validateAndMakeTenantAndRoles(data.tenantAndRoles);
    data.id = Utils.generateUuid();
    return data;
  }

  public async buildForUpdate(data) {
    let updateData = {}
    if (data.name) {
      ValidationUtils.validateStringNotEmpty(data.name, "name");
      updateData['name'] = data.name;

    }
    if (data.emailId) {
      ValidationUtils.validateStringNotEmpty(data.emailId, "emailId");
      ValidationUtils.validateEmail(data.emailId);
      updateData['emailId'] = data.emailId.toLocaleLowerCase();
    }
    if (data.phone) {
      ValidationUtils.validateStringNotEmpty(data.phone.countryCode, "countryCode");
      ValidationUtils.validateStringNotEmpty(data.phone.phoneNumber, "phoneNumber");
      updateData['phone'] = data.phone;
    }

    if (data.tenantAndRoles) {
      updateData["tenantAndRoles"] = await this.validateAndMakeTenantAndRoles(data.tenantAndRoles);
    }
    // performance.mark("Validation MS End")
    //     performance.measure("Create MS Validation", "Validation MS Start", "Validation MS End")
    // performance.measure("Create DB", "DB Start", "DB End")
    return updateData;
  }

  async create(user: any): Promise<IUserModel> {
    const userModel: any = await this.createEntity(user, user.emailId);
    return userModel as IUserModel;
  }

  async delete(userId: string): Promise<void> {
    await super.delete(userId);
  }

  async updateUserActivation(): Promise<void> {

  }

  async update(id, data): Promise<IUserModel> {
    try {
      return await this.getModel().findOneAndUpdate({ id: id }, { $set: data }, { upsert: false, new: true }).session(this.getSession()).exec();
    } catch (err) {
      if (err.message.startsWith("E11000 duplicate key error collection")) {
        ErrUtils.throwValidationError(`Entity ${this.getEntityName()} with name ${data.name} already exists`,
          "ENTITY_EXISTS");
      } else {
        throw err;
      }
    }
  }

  async searchUser(queryString: string, limit = 10, skip = 0, extended = false, sort: any) {
    //TODO: Need to check case changes for name roles and status
    let query = {};

    if (!queryString) {
      query = {};
    } else {
      query = { "$or": [{ name: { "$regex": queryString, "$options": 'i' } }, { emailId: { "$regex": queryString, "$options": 'i' } }, { status: queryString }, { 'tenantAndRoles.name': queryString }, { 'tenantAndRoles.roles.name': queryString }] };

    }
    let sortQuery = {}
    sortQuery[sort.sortField] = sort.sortOrder === 'desc' ? -1 : 1;
    let response = {}
    let data = await this.getModel().find(query).sort(sortQuery).limit(limit).skip(skip);
    data = data.map(result => {
      result.name = Utils.toNameCase(result.name);
      return result;
    });
    response["data"] = data;
    if (extended) {
      response["total"] = await this.getModel().find(query).count();
    }
    return response;
  }

  async getActivationBatchUser() {

    const blockStartDate = new Date();
    blockStartDate.setHours(0, 0, 0, 0);
    const blockEndDate = new Date();
    blockEndDate.setHours(0, 5, 0, 0);
    const activationStartDate = new Date();
    activationStartDate.setHours(23, 59, 0, 0);

    const requestPromises = [this.getModel().find({
      '$and': [
        {
          'status': 'activated'
        }, {
          'blockDuration.startDate': {
            '$gte': blockStartDate
          }
        }, {
          'blockDuration.startDate': {
            '$lte': blockEndDate
          }
        }
      ]
    }, { _id: 0, id: 1, blockDuration: 1 }), this.getModel().find({
      '$and': [
        {
          'status': 'blocked'
        }, {
          'blockDuration.endDate': {
            '$lte': activationStartDate
          }

        }
      ]
    }, { _id: 0, id: 1, blockDuration: 1, cognitoId: 1 })];

    let requestPromisesResult = await Promise.all(requestPromises);
    const results = {};
    results['deactivationUsers'] = requestPromisesResult[0];
    results['activationUsers'] = requestPromisesResult[1];
    return results;

  }

  public getSession(): ClientSession {
    return TransactionManagerFactory.getInstance(OrmOdms.MONGOOSE).getTransaction();
  }

  private validateForCreate(data) {

    ValidationUtils.validateStringNotEmpty(data.name, "name");
    ValidationUtils.validateStringNotEmpty(data.emailId, "emailId");
    ValidationUtils.validateIsNotNullOrUndefined(data.phone, "phone");
    ValidationUtils.validateStringNotEmpty(data.phone.countryCode, "countryCode");
    ValidationUtils.validateStringNotEmpty(data.phone.phoneNumber, "phoneNumber");
    ValidationUtils.validateEmail(data.emailId);
    //TODO: Create validations for country code 
    //TODO: Create validations for Phone Number 

  }


  /**
   * Validates and then maps roleId to roles by making request to authentications service /roles
   * @param tenants 
   */
  public async validateAndMakeTenantAndRoles(tenants: any[]) {

    let roleMapping = {}
    if (!tenants || tenants.length === 0) {
      throw ErrUtils.createValidationError(`Invalid tenant Data`, "VALIDATION_ERR")

    }
    const requestData = []
    for (let x = 0; x < tenants.length; x++) {
      const tenant = tenants[x];
      ValidationUtils.validateStringNotEmpty(tenant.id, "tenantAndRoles.[].id");
      ValidationUtils.validateStringNotEmpty(tenant.name, "tenantAndRoles.[].name");
      ValidationUtils.validateStringNotEmpty(tenant.instance, "tenantAndRoles.[].instance");
      tenant.roles.forEach(tenantRole => {
        
        const role = { roleName: tenantRole, instanceId: tenant.instance, organizationId: 'INSTANCE' }; //TODO tenantRoles.id 
        requestData.push(role);
      });
    }

    const encodedArray = encodeURIComponent(JSON.stringify(requestData))

    // try {
      let responses = await MageHttpClient.call(Service.AUTHORIZATION_SERVICE, `/roles/roleNames/${encodedArray}`, {});



      roleMapping = _.keyBy(responses.data, o => o.roleName);
      let invalidRoles = _.difference(requestData.map(rd => rd.roleName), responses.data.map(dt => dt.roleName));
      if (invalidRoles.length != 0) {
         ErrUtils.throwValidationError(`Invalid tenant Role mapping: ${invalidRoles}`, "VALIDATION_ERR")
      }
    // } catch (er) { console.log(er) }
    for (let x = 0; x < tenants.length; x++) {
      const tenantRoles = tenants[x];

      tenantRoles.roles = tenantRoles.roles.map(tenantRole => {
        return { name: tenantRole, roleId: roleMapping[tenantRole].id };
      });
    }

    return tenants;
  }



}