import * as AWS from 'aws-sdk';
import { Utils } from '../utils/Utils';
import { provideSingleton } from '../ioc';
import { ErrUtils, ProviderFactory, Logger } from '@edunxtv2/service-util';
const delay = require('delay');

@provideSingleton(AWSCognitoService)
export class AWSCognitoService {
    private cognitoIdentityServiceProvider;
    private userPoolId;

    constructor() {
        this.init();
    }
    private init() {
        this.userPoolId = ProviderFactory.getAttribsProvider().getConfigVar("AWS_COGNITO_USER_POOL_ID");
        let cognitoAWSRegion =  ProviderFactory.getAttribsProvider().getConfigVar("AWS_COGNITO_REGION_NAME");
        if(cognitoAWSRegion){
            AWS.config.update({
                region: cognitoAWSRegion
            });
        }
        this.cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
    }
    public async createUser(userData: any) {

        //TODO remove this after aws limit check fix
        await delay(200);
        
        // TODO: Need to check what will be the usename either id or email

        // as email meeans it will change and during update some issue might come
        let cognitoUser = { UserAttributes: [] };
        cognitoUser['UserPoolId'] = this.userPoolId;
        cognitoUser['TemporaryPassword'] = Utils.generateTemparoryPassword();
        cognitoUser['Username'] = userData.emailId;
        cognitoUser['DesiredDeliveryMediums']=['EMAIL']
        cognitoUser.UserAttributes.push({
            Name: 'email',
            Value: userData.emailId
        });
        cognitoUser.UserAttributes.push({
            Name: 'name',
            Value: userData.name
        });
        cognitoUser.UserAttributes.push({
            Name: 'phone_number',
            Value: `${userData.phone.countryCode}${userData.phone.phoneNumber}`
        });
        cognitoUser.UserAttributes.push({
            Name: 'custom:userid',
            Value: userData.id
        });
        // cognitoUser.UserAttributes
        cognitoUser.UserAttributes.push({
            Name: 'email_verified',
            Value: "true"
        });
        cognitoUser.UserAttributes.push({
            Name: 'phone_number_verified',
            Value: "true"
        });
        try{
            return await this.cognitoIdentityServiceProvider.adminCreateUser(cognitoUser).promise();
        }catch (awsError){
            if(awsError.code === 'UsernameExistsException'){
                ErrUtils.throwValidationError(`Entity users with id ${userData.emailId} already exists`,
                "ENTITY_EXISTS_COGNITO");
            }
            Logger.error(awsError.message,"AWS_ERR","AWS", {...cognitoUser, awsError});

            //TODO Log error for inspection
            throw ErrUtils.createSystemError("AWS Congnito error","AWS_ERR");
        }

    }

    public async updateUser( userData: any) {
        let cognitoUser = { UserAttributes: [] };
        cognitoUser['UserPoolId'] = this.userPoolId;
        cognitoUser['Username'] = userData['cognitoId'];
        cognitoUser.UserAttributes.push({
            Name: 'email',
            Value: userData.emailId
        });
        cognitoUser.UserAttributes.push({
            Name: 'phone_number',
            Value: `${userData.phone.countryCode}${userData.phone.phoneNumber}`
        });
        cognitoUser.UserAttributes.push({
            Name: 'email_verified',
            Value: "true"
        });
        cognitoUser.UserAttributes.push({
            Name: 'phone_number_verified',
            Value: "true"
        });
        console.log("user", cognitoUser);
        try{
            return await this.cognitoIdentityServiceProvider.adminUpdateUserAttributes(cognitoUser).promise();
        }catch (awsError){
            console.error(awsError);

            //TODO Log error for inspection
            throw ErrUtils.createSystemError("AWS Congnito error","AWS_ERR");
        }

    }

    public async resetUserPassword(userName: string, isPermanent: false) {
            const userData = {
                UserPoolId: this.userPoolId,
                Username: userName,
                Password: Utils.generateTemparoryPassword(),
                Permanent: isPermanent
            }
            // TODO: Need to check whether to send mail or not
            // TODO Password not getting delivered need to use SES manually
            try{
                return await this.cognitoIdentityServiceProvider.adminSetUserPassword(userData).promise()
            }catch (awsError){
                console.error(awsError);

                //TODO Log error for inspection
                throw ErrUtils.createSystemError("AWS Congnito error","AWS_ERR");
            }
    }

    public async getUser(userId: string){
        const userQuery = {
            "Username": userId,
            "UserPoolId": this.userPoolId
        }
        try{
            const user = await this.cognitoIdentityServiceProvider.adminGetUser(userQuery).promise();
            console.log(user);

        }catch (awsError){
            console.error(awsError);
            //TODO Log error for inspection
            throw ErrUtils.createSystemError("AWS Congnito error","AWS_ERR");
        }
    }

    public async disableUser(userId: string){
        const query = {
            UserPoolId: this.userPoolId,
            Username: userId
        }
        return await this.cognitoIdentityServiceProvider.adminDisableUser(query).promise();
    }

    public async enableUser(userId: string){
        const query = {
            UserPoolId: this.userPoolId,
            Username: userId
        }
        return await this.cognitoIdentityServiceProvider.adminEnableUser(query).promise();
    }

    public async getUsers(){
        return await this.cognitoIdentityServiceProvider.listUsers({"UserPoolId":this.userPoolId, "Filter": "name ^=\"test\""}) .promise()      
    }

    public async deleteUser(userId: string){
        let userQuery = {
            UserPoolId: this.userPoolId,
            Username: userId
        }
        return await this.cognitoIdentityServiceProvider.adminDeleteUser(userQuery).promise()
    }

}

async function test(){
    require('dotenv').config();
    let awscs = new AWSCognitoService();
    let userData = {
        emailId: 'arul.dsacoe1@gmail.com',
        phone:{
            countryCode: '91',
            phoneNumber: '9886162534'
        } ,
        id: 'testuserId'
    }
    // const createdUser = await awscs.createUser(userData);
    // console.log('New User', createdUser);
    // const updatedUser = await awscs.resetUserPassword('arul.dsacoe@gmail.com',false);
    const updatedUser = await awscs.updateUser(userData);
    // await awscs.getUser('arul.dsacoe1@gmail.com')
    console.log('Result',updatedUser);

}
// test()

async function resetCognito() {
    require('dotenv').config();
    let awscs = new AWSCognitoService();
    let users = await  awscs.getUsers();
    console.log(users)
    users["Users"].forEach(async user => {
        await awscs.deleteUser(user.Username)
    });
   
}
// resetCognito();