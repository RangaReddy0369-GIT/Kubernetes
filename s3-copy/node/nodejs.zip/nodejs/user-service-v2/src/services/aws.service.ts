import * as AWS from 'aws-sdk';

import { provideSingleton } from "../ioc";
import { ProviderFactory, ErrUtils } from '@edunxtv2/service-util';



@provideSingleton(AWSService)
export class AWSService {

    s3;
    bucketName;
    bucketRegion: string;
    // const allowedFiles
    constructor() {
        this.bucketName = ProviderFactory.getAttribsProvider().getConfigVar("S3_BUCKET_NAME");
        this.bucketRegion = ProviderFactory.getAttribsProvider().getConfigVar("S3_REGION");
        const s3Config = { signatureVersion: 'v4' };
        if (this.bucketRegion) {
            s3Config["region"] = this.bucketRegion;
        }

        this.s3 = new AWS.S3();

    }


    /**
     * This function will return a signed url for bulk file upload
     * @param meta - { name: manadatory string, Expires: numeric optuional, contentType: string manadory}
     */
    public async getSignedUrl(meta: any) {
        try {
            return {
                key: meta.name,
                url: await this.s3.getSignedUrlPromise('putObject', {
                    Bucket: this.bucketName,
                    'ContentType': meta.contentType,
                    'Expires': meta.Expires || 60,
                    'Key': meta.name,
                    'Metadata': {
                        organizationId: meta.organizationId,
                        instanceId: meta.instanceId
                    }
                })
            };
        } catch (error) {
            console.log(error);
            throw ErrUtils.createSystemError("AWS SDK error", "AWS_ERR");

        }

    }

    public async getFileMeta(key: string) {
        return await this.s3.headObject({ Bucket: this.bucketName, Key: key }).promise();
    }

    public getFileStream(key: string) {
        try {
            return this.s3.getObject({ Bucket: this.bucketName, Key: key }).createReadStream();
        } catch (error) {
            throw error;
        }

    }
}