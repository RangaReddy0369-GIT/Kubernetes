import { provideSingleton } from "../ioc";
import { BatchUserModel, IBatchUserModel } from "../models/batch-user.model";
import { BaseService } from "./base.service";
import { IUserModel } from "models/user.model";
import { ErrUtils } from "@edunxtv2/service-util";
import { HierarchyService } from "./hierarchy.service";

@provideSingleton(UserBatchService)
export class UserBatchService extends HierarchyService {
    protected getParentAttribsName(): string {
        throw new Error("Method not implemented.");
    }
    protected getParentModel() {
        throw new Error("Method not implemented.");
    }
    protected getParentEntityName(): string {
        throw new Error("Method not implemented.");
    }
    protected getModel() {
        return BatchUserModel;
    }
    protected getEntityName(): string {
        return BaseService.ENTITY_USERBATCH;
    }
    protected getChildModel() {
        throw new Error("Method not implemented.");
    }
    protected getChildEntityName(): string {
        throw new Error("Method not implemented.");
    }

    constructor() {
        super()
    }
    public async createUser(data): Promise<IBatchUserModel> {
        const batchUserModel = await this.getModel().create(data);
        return batchUserModel as IBatchUserModel;
    }
    public async bulkCreate(data: any[]): Promise<any> {
        // const batchUserModelResults =  await this.getModel().bulkWrite(data);
        return await this.getModel().create(data);
    }
    public async updateBatchUser(query: any, data: any, withSession = true) {
        try {
            if(withSession){
                return await this.getModel().findOneAndUpdate(query, { $set: data }, { upsert: false, new: true }).session(this.getSession()); //.session(this.getSession())
            }
            return await this.getModel().findOneAndUpdate(query, { $set: data }, { upsert: false, new: true }); //.session(this.getSession()); //.session(this.getSession())
            
        } catch (err) {
            if (err.message.startsWith("E11000 duplicate key error collection")) {
                ErrUtils.throwValidationError(`Entity ${this.getEntityName()} with name ${data.name} already exists`,
                    "ENTITY_EXISTS");
            } else {
                throw err;
            }
        }
    }


    public async batchStatus(batchId: string): Promise<any> {
        const pipeline = [
            {
                '$match': {
                    'batchId': batchId
                }
            }, {
                '$group': {
                    '_id': '$status',
                    'count': {
                        '$sum': 1
                    }
                }
            }
        ]
        return await this.getModel().aggregate(pipeline);
    }


}