import { Request, Response, NextFunction } from 'express';
import { Constants } from '../constants';
import { ContextManager } from '@edunxtv2/service-util';

export class RequestPreprocessor {

  public static preprocess(req: Request, res: Response, next: NextFunction) {
    if (req.url.startsWith(`${Constants.CONTEXT_PATH}/actions`)) {
      RequestPreprocessor.preprocessForActions(req);
    } else if (req.url.startsWith(`${Constants.CONTEXT_PATH}/roles`)) {
      RequestPreprocessor.preprocessForRoles(req);
    }

    next();
  }

  private static preprocessForRoles(req: Request) {
    RequestPreprocessor.updateStringInObject(req.body, "roleName");
    RequestPreprocessor.updateStringInObject(req.query, "roleName");
  }

  private static preprocessForActions(req: Request) {
    RequestPreprocessor.updateStringInObject(req.body, "actionName");
    RequestPreprocessor.updateStringInObject(req.query, "actionName");
  }

  private static updateStringInObject(obj: any, attribName: string) {
    if (obj[attribName]) {
      obj[attribName] = obj[attribName].trim().toUpperCase();
    }
  }

}