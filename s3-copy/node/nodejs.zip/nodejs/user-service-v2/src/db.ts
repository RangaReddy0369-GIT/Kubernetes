import { ProviderFactory, Logger } from "@edunxtv2/service-util";
import * as mongoose from 'mongoose';

export async function connectToMongoDb(): Promise<void> {
    const mongoUrl: any = ProviderFactory.getSecretsProvider()
      .getSecret("USER_SERVICE_MONGODB_URL");
  
    Logger.info('Connecting to mongodb. Using string ', mongoUrl);
    (mongoose as any).Promise = global.Promise;
  
    try {
      await mongoose.connect(mongoUrl, {});
      Logger.info('Connected to mongodb. Using string ', mongoUrl);
    } catch (err) {
      Logger.info('MongoDB connection error. Please make sure MongoDB is running. ' + err);
      process.exit();
    }
}
