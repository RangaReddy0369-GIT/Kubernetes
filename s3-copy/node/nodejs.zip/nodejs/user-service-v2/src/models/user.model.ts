import { Document, Schema } from "mongoose";
import * as mongoose from 'mongoose';
import { Utils } from "../utils/Utils";



interface IUserModel extends Document{
    id: string,
    name: string,
    cognitoId: string,
    userPoolId: string,
    emailId: string,
    tenantAndRoles:ITenantRoles[],
    profilePic: string,
    phoneNumber: IPhoneNumber,
    lastActive: string,
    statusRemark: string
}
const roleSchema = new Schema({
    roleId: {type: 'string', required: true},
    name: {type: 'string', required: true}
},{_id:false});
const rolesAndTenantSchema = new Schema({
    id: {type: 'string', required: true},       // tenantId
    name: { type:'string', required: true},     //tenantName
    instance: { type:'string', required: true},     //instanceName MAB, AMS
    roles:[
        roleSchema
    ]
}, {_id: false});

const phoneNumberSchema = new Schema({
    countryCode: {type: 'string', required: true},
    phoneNumber: { type:'number', required: true} 
},{_id: false})
const userSchema: Schema = new Schema({

    id: {type: 'string', default: Utils.generateUuid, unique: true},
    cognitoId: {type: 'string', unique:true},
    userPoolId: {type: 'string'},
    name: {type: 'string', required: true},
    emailId: {type: 'string', required: true, unique: true },
    tenantAndRoles: {type: [rolesAndTenantSchema] , required: true },
    phone: {type: phoneNumberSchema, required: true },
    profilePic: {type: 'string', required: false },
    lastActive: {type: Date, default: new Date() },
    status: {type:'string', default: 'activated'},
    blockDuration: {
        _id: false,
        startDate: {type: Date},
        endDate: Date
    },
    statusRemark : {type: 'string'}


},{timestamps: true, versionKey: false})

const UserModel = mongoose.model<IUserModel>('users',userSchema);
export { IUserModel, IPhoneNumber, IRoles, phoneNumberSchema, rolesAndTenantSchema, ITenantRoles, UserModel}

interface IPhoneNumber {
    countryCode: string,
    phoneNumber: number
}
interface IRoles {
    roleId: string,
    roleName: string
}
interface ITenantRoles{
    tenantId: string,
    tenantName: string,
    roles: IRoles[]
}