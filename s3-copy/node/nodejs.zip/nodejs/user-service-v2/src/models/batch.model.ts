import * as mongoose from 'mongoose';
import { Schema,  Document } from 'mongoose';
import { Utils } from '../utils/Utils';

enum BATCHSTATUS {
    CREATED = 'created',
    PROCESSING = 'processing',
    COMPLETED = 'completed',
    COMPLETED_PARTIAL_UPDATE = 'completed_partial_update',
    COMPLETED_PARTIAL_ERROR = 'completed_partial_error',
    ERROR = 'error'
}

interface IBulkProcessModel extends Document {
    id: string,
    name: string,
    organizationId: string,
    instanceId: string,
    status: string  
}


interface IBatchStatsSchema extends Document {
    total: number,
    error: number,
    completed_partial_update: number,
    completed_partial_error: number,
    completed: number
}

const s3DetailsSchema = new Schema({
    s3FileId: {type: 'string', required: true},
    fileName: {type: 'string', required: true}, 
    bucketName: {type: 'string', required: true},
},{_id: false})

const batchStatsSchema = new Schema({
    total: {type: 'number', default:0},
    error: {type: 'number', default:0},
    completed_partial_update: {type: 'number', default:0},
    completed_partial_error: {type: 'number', default:0},
    completed: {type: 'number', default:0}
},{_id: false})

const bulkProcessBatchSchema:Schema = new Schema({
    id: { type: 'string', required: true, default: Utils.generateUuid, unique: true} ,
    name: { type: 'string', required: true} ,
    s3Details: { type: s3DetailsSchema, required: true} ,
    status: { type: 'string', required: true, default: BATCHSTATUS.CREATED},
    stats: { type: batchStatsSchema},
    statusRemark: { type: 'string', required: true, default: 'created'}
}, {timestamps: true, versionKey: false});

const BulkProcessBatchModel = mongoose.model<IBulkProcessModel>('bulkprocessbatches', bulkProcessBatchSchema); 
export  { BulkProcessBatchModel, IBulkProcessModel, BATCHSTATUS};