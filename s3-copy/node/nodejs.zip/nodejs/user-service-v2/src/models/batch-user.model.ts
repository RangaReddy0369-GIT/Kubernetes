import { Schema, Document } from "mongoose";
import { Utils } from "../utils/Utils";
import * as mongoose from 'mongoose';

import { IPhoneNumber, ITenantRoles, phoneNumberSchema, rolesAndTenantSchema } from "./user.model";
enum USERBATCHSTATUS {
    CREATED = 'created',
    COMPLETED = 'completed',
    COMPLETED_PARTIAL_UPDATE = 'completed_partial_update',
    COMPLETED_PARTIAL_ERROR = 'completed_partial_error', // error on user group mapptin
    ERROR = 'error'
}
interface IBatchUserModel extends Document {
    batchId: string,
    id: string,
    name: string,
    emailId: string,
    tenantAndRoles: string[],
    phone: IPhoneNumber,
    remark: string
}

const batchUserSchema: Schema = new Schema({
    batchId:  {type: 'string', required: true},
    id: {type: 'string', default: Utils.generateUuid, unique: true},
    name: {type: 'string'},
    emailId: {type: 'string'},
    roles:  {type: ['string']},
    instanceId:  {type: ['string']},
    organizationId:  {type: ['string']},
    userGroups:   {type: ['string']},
    phone:  {type: phoneNumberSchema},
    remarks:  {type: 'string'},
    status:  {type: 'string', default: USERBATCHSTATUS.CREATED}, //  created, completed, completed-partial update, error
},{timestamps: true, versionKey: false});
const BatchUserModel = mongoose.model<IBatchUserModel>('batch_users',batchUserSchema);

export { BatchUserModel, IBatchUserModel, USERBATCHSTATUS }