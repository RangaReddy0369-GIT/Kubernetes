import './loader'
import {connectToMongoDb} from './db'
import { initializeServer } from './server'
import { Service, Logger } from '@edunxtv2/service-util';


export const init = async()=>{
    require('dotenv').config();
    Logger.init(Service.USER_SERVICE); 
    await connectToMongoDb();
    initializeServer();
};
