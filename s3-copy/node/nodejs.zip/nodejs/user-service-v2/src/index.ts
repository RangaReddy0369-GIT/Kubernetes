import 'reflect-metadata';
// tslint:disable-next-line: no-var-requires
require('express-async-errors');

import { ProviderFactory } from '@edunxtv2/service-util';

export async function init() {
  require('dotenv').config()

  await ProviderFactory.init(
    [],
    ["USER_SERVICE_MONGODB_URL", "PERMISSIONS_TICKET_PRIVATE_KEY"],
    ["ALLOW_CLEAR_ALL", "PERMISSIONS_TICKET_PUBLIC_KEY", "PERMISSIONS_TICKET_EXPIRY_DURATION","ENABLE_COGNITO","AWS_COGNITO_USER_POOL_ID","AWS_COGNITO_REGION_NAME","DOMAIN","S3_BUCKET_NAME","S3_REGION"]
  );
  require('./bootstrap').init();
}

init();