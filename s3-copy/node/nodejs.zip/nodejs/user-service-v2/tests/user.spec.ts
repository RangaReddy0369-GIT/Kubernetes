import 'mocha';
import { expect } from 'chai';
import * as _ from 'lodash';
import * as rp from 'request-promise';
import { HttpUtil } from './HttpUtil';
import { TestUtils, Service, ServiceUtil } from '@edunxtv2/service-util';
import { isUndefined } from 'util';
import { AWSCognitoService } from '../src/services/aws-cognito.service';

const testHeader = {
    instanceid: "MAB",
    organizationid: "someOrg",
    authorization: "eyJraWQiOiJWTE9NXC9QWHpcL1wvUnhsU3lmcmJjbnBFU2pEQWRVMVBrRHFEYnZWcW1hQ0lvPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI5ZDA3ZGY1Ni04ZTU3LTRlMWQtOGY4ZS1lNDhhZDM4NDhkMGEiLCJldmVudF9pZCI6IjU4ODZkMjFhLWZkMTMtNGE0NC04ZDNkLWU3NzI1YzcxNTcyYiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE1NjM5NDg4NTMsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTIuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0yX21Ub1hjeEh2YSIsImV4cCI6MTU2Mzk1MjQ1MywiaWF0IjoxNTYzOTQ4ODUzLCJqdGkiOiI3ZWQwZjk5Ny01ZWQ1LTQwZGEtYmMzNC00M2RjMjg5NjUxM2MiLCJjbGllbnRfaWQiOiI2MmljYW1oZzlnMTFxbTZiOTdpaGYybHY3ZyIsInVzZXJuYW1lIjoiZHZuZHIucGF0ZWwxQGdtYWlsLmNvbSJ9.K2QITu3IQyP2BcKu0BTTMKxtK8UAGByZi-U5i3u4OKfruNZ6btO7-FJ5lZqBJgj8kSxp5LCP17hQMn84FSixhu4nGcMvvtYKuUfpdaguG1Yo_eeP848TRESawUfLiDvPk8jja0HVArryUs6x6mrJvhbzuBA-4FWJPAiW2xyni_R4HqIxS4IQeODQ2NsKYqQPoJymlbd06lVPoXNF_U4CYR5iopZxOm_0DPSsSu0qBA61qbPKTKUQRSQGIp3mCHSGr0Gb0mO25BcRUS9rq_rc07tGvZql_deVqweBZEl7GtVeLaeNVytDQmBzC_S-R8zuZuqgDDk5Vm2XCzL5_--_fg"
}

let testUserRoles;
before(async function () {
    this.timeout(0);
    //setup tenant roles
    await rp({
        method: 'DELETE',
        uri: `http://localhost:3011/authorizationservice/actions/clear/all`,
        body: {},
        headers: { ...testHeader, 'Connection': 'keep-alive' },
        json: true,
        // resolveWithFullResponse: true
    });
    let rolePromises = [];
    rolePromises.push(HttpUtil.call('POST', `/roles`, {
        "roleName": "Student",
        "instanceId": "MAB",
        "organizationId": "INSTANCE"
    }, testHeader, 'http://localhost:3011/authorizationservice'));
    rolePromises.push(HttpUtil.call('POST', `/roles`, {
        "roleName": "Staff",
        "instanceId": "MAB",
        "organizationId": "INSTANCE"
    }, testHeader, 'http://localhost:3011/authorizationservice'));
    rolePromises.push(HttpUtil.call('POST', `/roles`, {
        "roleName": "Admin",
        "instanceId": "MAB",
        "organizationId": "INSTANCE"
    }, testHeader, 'http://localhost:3011/authorizationservice'));
    rolePromises.push(HttpUtil.call('POST', `/roles`, {
        "roleName": "Moderator",
        "instanceId": "MAB",
        "organizationId": "INSTANCE"
    }, testHeader, 'http://localhost:3011/authorizationservice'));

    testUserRoles = await Promise.all(rolePromises);
})
beforeEach(async function () {
    this.timeout(0);
    await deleteAllUsers();
});


async function deleteAllUsers() {
    await HttpUtil.call('DELETE', '/users/clearAll', {}, testHeader);
}

async function createTestUsers() {
    let userPromises = [];
    for (let x = 0; x < 5; x++) {
        let user = {
            "name": `test1user${x}`,
            "emailId": `test1user${x}@test.com`,
            "phone": {
                "countryCode": "+91",
                "phoneNumber": `123123123${x}`
            },
            "tenantAndRoles": [
                {
                    "id": "someOrg",
                    "name": "someOrg",
                    "instance":"MAB",
                    "roles": [
                        testUserRoles[0].roleName,
                        testUserRoles[1].roleName
                    ]
                }
            ]
        }
        // await HttpUtil.call('POST', '/users', user, testHeader)
        userPromises.push(HttpUtil.call('POST', '/users', user, testHeader))
    }
    await Promise.all(userPromises)
}
function sorter(data) {
    return _.sortBy(data, ele => ele.name);
}
describe("User creation api", async () => {
    beforeEach(async function () {
        // this.timeout(0);
        // await createTestUsers()
    });
    it("Throws error for incorrect parameters validations", async () => {
        await TestUtils.verifyAsyncError(`401 - "name may not be null, undefined or blank"`, async () => {
            await HttpUtil.post("/users", {}, testHeader);
        });
    });
    it("Throws error for invalid email", async () => {
        await TestUtils.verifyAsyncError(`401 - "Invalid Email ID: user3"`, async () => {
            const testUser = {
                "name": "user3",
                "emailId": "user3",
                "phone": {
                    "countryCode": "+91",
                    "phoneNumber": "1231231233"
                },
                "tenantAndRoles": [
                    {
                        "id": "someOrg",
                        "name": "someOrg",
                        "instance":"MAB",

                        "roles": [
                             testUserRoles[0].roleName,
                              testUserRoles[1].roleName
                        ]
                    }
                ]
            }
            await HttpUtil.post("/users", testUser, testHeader);
        });
    });

    it("Creates the user successfully if all the criterias are satisfied", async () => {
        const testUser = {
            "name": "ctuser",
            "emailId": "ctuser@test.com",
            "phone": {
                "countryCode": "+91",
                "phoneNumber": "1231231233"
            },
            "tenantAndRoles": [
                {
                    "id": "someOrg",
                    "name": "someOrg",
                    "instance":"MAB",

                    "roles": [
                            testUserRoles[0].roleName,
                            testUserRoles[1].roleName
                    ]
                }
            ]
        }
        let newUser = await HttpUtil.post("/users", testUser, testHeader);
        newUser = newUser.user;
        delete newUser._id;
        delete newUser.lastActive;
        delete newUser.createdAt;
        delete newUser.updatedAt;
        delete newUser.id;
        delete newUser.status;
        delete newUser.cognitoId;
        delete newUser.userPoolId;

        newUser.phone.phoneNumber = newUser.phone.phoneNumber.toString();
        //    delete newUser.tenantAndRoles;
        //    delete testUser.tenantAndRoles;
        console.log(newUser, testUser)
        expect(_.isEqual(newUser, testUser)).to.be.true;

    });
    it("Throws error if user with same name already exists", async function () {
        this.timeout(0)
        const testUser = {
            "name": "ctuser",
            "emailId": "ctuser@test.com",
            "phone": {
                "countryCode": "+91",
                "phoneNumber": "1231231233"
            },
            "tenantAndRoles": [
                {
                    "id": "someOrg",
                    "name": "someOrg",
                    "instance":"MAB",

                    "roles": [
                             testUserRoles[0].roleName,
                             testUserRoles[1].roleName
                    ]
                }
            ]
        }
        let newUser = await HttpUtil.post("/users", testUser, testHeader);
        await TestUtils.verifyAsyncError(`401 - "Entity users with id ctuser@test.com already exists"`, async () => {

            await HttpUtil.post("/users", testUser, testHeader);
        });
    });
});

describe('User last seen api', async function () {
    beforeEach(async function () {
        this.timeout(0);
        await createTestUsers()
    });
    it('should update the users last seen time to request time', async () => {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        const usertoUpdate = users[Math.floor(Math.random() * Math.floor(users.length))]
        let response = await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/ping`, {}, testHeader);
        expect(response).to.equal('success');
    });
});

describe('User activation api', async function () {
    beforeEach(async function () {
        this.timeout(0);
        await createTestUsers()
    });
    it('Should throw error for invalid operations', async function () {
        this.timeout(0)
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;

        const usertoUpdate = users[Math.floor(Math.random() * Math.floor(users.length))]

        await TestUtils.verifyAsyncError(`401 - "Invalid operation"`, async () => {
            await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, {}, testHeader);
        });

        await TestUtils.verifyAsyncError(`401 - "Invalid operation"`, async () => {
            await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, { "status": "invalidoperation" }, testHeader);
        });

    });
    it('Should return null for invalid user', async function () {
        await TestUtils.verifyAsyncError(`404 - "Invalid userid"`, async () => {
        let response = await HttpUtil.call('PUT', `/users/abc/activation`, { "status": "deactivate", "statusRemark": "Deactivated for testing" }, testHeader);
         });
    });

    it('Should throw error for block operations if date is not specified', async function () {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        const usertoUpdate = users[Math.floor(Math.random() * Math.floor(users.length))]
        await TestUtils.verifyAsyncError(`401 - "For Blocking user endDate is mandatory"`, async () => {
            await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, { "status": "block", "statusRemark": "Blocked for testing" }, testHeader);
        });
    });
    it('Should update the user status to blocked on proper input ', async function () {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        const startDate = new Date().toISOString();
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + 2);
        let usertoUpdate = users[Math.floor(Math.random() * Math.floor(users.length))]
        let response = await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, {
            "status": "block", "endDate": endDate,
            "startDate": startDate,
            "statusRemark": "Blocked for testing"
        }, testHeader);


        usertoUpdate = {
            ...usertoUpdate,
            "blockDuration": {
                "startDate": startDate,
                "endDate": endDate.toISOString()
                
            },
            status: "blocked",
            "statusRemark": "Blocked for testing"
        }

        delete usertoUpdate.tenantAndRoles;
        delete usertoUpdate.blockDuration;
        delete response.tenantAndRoles;
        delete response.blockDuration;

        delete usertoUpdate.updatedAt;
        delete response.updatedAt;
        expect(_.isEqual(response, usertoUpdate)).to.equal(true);
    });
    it('Should update the user status to deactivated', async function () {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        let usertoUpdate = users[Math.floor(Math.random() * Math.floor(users.length))]
        let response = await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, { "status": "deactivate", "statusRemark": "Deactivated for testing" }, testHeader);
        usertoUpdate = {
            ...usertoUpdate,
            status: "deactivated",
            "statusRemark": "Deactivated for testing"
        }
        delete usertoUpdate.updatedAt;
        delete response.updatedAt;
        expect(_.isEqual(response, usertoUpdate)).to.equal(true);
    });
    it('Should update the user status to activated', async function () {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        const usertoUpdate = users[Math.floor(Math.random() * Math.floor(users.length))]
        let deactivateResponse = await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, { "status": "deactivate", "statusRemark": "Deactivated for testing" }, testHeader);

        let activateResponse = await HttpUtil.call('PUT', `/users/${usertoUpdate.id}/activation`, { "status": "activate", "statusRemark": "Activated for testing" }, testHeader);
        expect(activateResponse.status).to.equal('activated');
    });
});


describe('Get user details api', async function () {
    beforeEach(async function () {
        this.timeout(0);
        await createTestUsers()
    });
    it('Should return nothing if users are not found with the specified ID', async function () {
        //@TODO: check whether 404 should be returned for invalid users
        let response = await HttpUtil.call('GET', '/users/invalid_user_id', {}, testHeader);
        expect(isUndefined(response)).to.be.true;


    });
    it('Should return the user detail belongs to that id', async function () {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        const usertoGet = users[Math.floor(Math.random() * Math.floor(users.length))]

        let searchResult = await HttpUtil.call('GET', `/users/${usertoGet.id}`, {}, testHeader);
        delete usertoGet._id;
        expect(_.isEqual(searchResult, usertoGet)).to.be.true;
    });
});

describe('Get multiple users', async function () {
    beforeEach(async function () {
        this.timeout(0);
        await createTestUsers()
    });
    it('should return the details of list of user ids passed', async function () {
        let users = (await HttpUtil.call('GET', '/users', {}, testHeader)).data;
        const userstoGet = sorter(users.splice(2)); //[Math.floor(Math.random() * Math.floor(users.length))]
        const userIds = userstoGet.map(user => user.id);
        let searchResult = await HttpUtil.call('GET', `/users/ids/${JSON.stringify(userIds)}`, {}, testHeader);
        searchResult = sorter(searchResult);
        // delete usertoGet._id;
        expect(_.isEqual(searchResult, userstoGet)).to.be.true;
    })
});

// describe('Search users based on different parameters', async function () {
//     beforeEach(async function () {
//         this.timeout(0);
//         await createTestUsers()
//     });
// });


describe('User update Api', async function () {
    beforeEach(async function () {
        this.timeout(0);
        await createTestUsers()
    });

    it("Should return null if the userid is invalid")
    it("Should return error if the userid is invalid")
});
